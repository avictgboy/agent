import { Pool as PgPool, neonConfig } from '@neondatabase/serverless';
import { drizzle as drizzleNeon } from 'drizzle-orm/neon-serverless';
import mysql from 'mysql2/promise';
import { drizzle as drizzleMysql } from 'drizzle-orm/mysql2';
import ws from "ws";
import * as schema from "@shared/schema";

// Check database connection type from environment
const dbType = process.env.DB_TYPE || 'postgres';
const isProduction = process.env.NODE_ENV === 'production';

if (!process.env.DATABASE_URL) {
  throw new Error(
    "DATABASE_URL must be set. Did you forget to provision a database?",
  );
}

// Function to parse connection details from DATABASE_URL
function parseDbUrl(url) {
  try {
    // Simple parsing for displaying host and port
    const dbUrlRegex = /([^:]+):\/\/([^:]+)(:[^@]+)?@([^:]+)(:([0-9]+))?\/(.*)/;
    const matches = url.match(dbUrlRegex);
    
    if (matches) {
      const protocol = matches[1];
      const username = matches[2];
      const host = matches[4];
      const port = matches[6] || (protocol === 'mysql' ? '3306' : '5432');
      const database = matches[7];
      
      return { protocol, username, host, port, database };
    }
    return { error: 'Could not parse DATABASE_URL' };
  } catch (err) {
    return { error: 'Invalid DATABASE_URL format' };
  }
}

// Log connection details for diagnostics (but mask in production)
const dbDetails = parseDbUrl(process.env.DATABASE_URL);
if (!dbDetails.error) {
  console.log(`Database configuration: ${dbType}`);
  console.log(`Host: ${dbDetails.host}, Port: ${dbDetails.port}, Database: ${dbDetails.database}`);
} else {
  console.error(`Database URL parsing error: ${dbDetails.error}`);
}

// Use the appropriate database client based on the DB_TYPE
let db;
let pool;

const failoverToMemoryDb = () => {
  console.warn('Using in-memory database mode due to connection failure.');
  console.warn('This is a fallback mode with limited functionality.');
  console.warn('Please check your database configuration.');
  
  // Return a minimal implementation that won't crash the app
  return {
    select: () => ({ from: () => ({ where: () => [], orderBy: () => [] }) }),
    insert: () => ({ values: () => ({ returning: () => [] }) }),
    update: () => ({ set: () => ({ where: () => ({ returning: () => [] }) }) }),
    delete: () => ({ where: () => [] }),
    transaction: (fn) => Promise.resolve({})
  };
};

try {
  if (dbType === 'mysql') {
    // MySQL connection
    console.log('Using MySQL database connection');
    try {
      // Test connection before proceeding
      pool = mysql.createPool(process.env.DATABASE_URL);
      // Verify connection
      pool.query('SELECT 1').then(() => {
        console.log('Successfully connected to MySQL database');
      }).catch(err => {
        console.error('MySQL connection test failed:', err.message);
      });
      db = drizzleMysql(pool, { schema, mode: 'default' });
    } catch (err) {
      console.error(`MySQL connection error: ${err.message}`);
      if (isProduction) {
        db = failoverToMemoryDb();
      } else {
        throw err;
      }
    }
  } else {
    // PostgreSQL connection (default)
    console.log('Using PostgreSQL database connection');
    try {
      // Required for Neon serverless
      neonConfig.webSocketConstructor = ws;
      pool = new PgPool({ connectionString: process.env.DATABASE_URL });
      // Verify connection
      pool.query('SELECT 1').then(() => {
        console.log('Successfully connected to PostgreSQL database');
      }).catch(err => {
        console.error('PostgreSQL connection test failed:', err.message);
      });
      db = drizzleNeon(pool, { schema });
    } catch (err) {
      console.error(`PostgreSQL connection error: ${err.message}`);
      if (isProduction) {
        db = failoverToMemoryDb();
      } else {
        throw err;
      }
    }
  }
} catch (err) {
  console.error(`Database initialization error: ${err.message}`);
  if (isProduction) {
    db = failoverToMemoryDb();
  } else {
    throw new Error(
      `Database connection failed: ${err.message}\n` +
      `Please check your DATABASE_URL and make sure your database server is running.`
    );
  }
}

export { db, pool };
import { commissions, users, players } from "@shared/schema";
import { db } from "./db";
import { eq, and, isNull, lt } from "drizzle-orm";
import { WebSocket } from 'ws';

// A shared map for active WebSocket connections (agentId -> WebSocket)
// This will be populated in routes.ts and used here
export const connections = new Map<number, WebSocket>();

// Utility function to send notifications to users
export const sendNotification = (userId: number, notification: any) => {
  const connection = connections.get(userId);
  if (connection && connection.readyState === WebSocket.OPEN) {
    connection.send(JSON.stringify(notification));
    return true;
  }
  return false;
};

/**
 * Process scheduled commission payouts
 * This function will look for commissions that:
 * 1. Are not paid yet
 * 2. Have a scheduled payout date that is today or earlier
 */
export async function processScheduledCommissions() {
  const today = new Date();
  console.log(`Running scheduled commission processing on ${today.toISOString()}`);
  
  try {
    // Only process on the 4th day of month
    if (today.getDate() !== 4) {
      console.log('Not the 4th day of the month, skipping commission processing');
      return;
    }
    
    // Get all unpaid commissions scheduled for today or earlier
    const pendingCommissions = await db.select().from(commissions)
      .where(
        and(
          eq(commissions.isPaid, false),
          lt(commissions.scheduledPayout, today)
        )
      );
    
    console.log(`Found ${pendingCommissions.length} pending commissions to process`);
    
    // Process each commission
    for (const commission of pendingCommissions) {
      await db.transaction(async (tx) => {
        try {
          // Get the agent
          const [agent] = await tx.select().from(users)
            .where(eq(users.id, commission.agentId));
            
          if (!agent) {
            console.error(`Agent ${commission.agentId} not found for commission ${commission.id}`);
            return;
          }
          
          // Add commission amount to agent's balance
          const commissionAmount = Number(commission.commission);
          const newBalance = Number(agent.balance) + commissionAmount;
          
          // Get player information
          const [player] = await tx.select().from(players)
            .where(eq(players.id, parseInt(commission.playerId, 10)));
            
          const playerUsername = player ? player.username : 'Unknown Player';
          
          await tx.update(users)
            .set({ balance: newBalance.toString() })
            .where(eq(users.id, commission.agentId));
            
          // Mark commission as paid
          await tx.update(commissions)
            .set({ 
              isPaid: true,
              paidDate: today
            })
            .where(eq(commissions.id, commission.id));
            
          console.log(`Processed commission ${commission.id} for agent ${commission.agentId}: added ${commissionAmount} to balance`);
          
          // Send notification to the agent about their commission payment
          sendNotification(commission.agentId, {
            type: 'commission',
            action: 'paid',
            data: {
              commissionId: commission.id,
              amount: commissionAmount,
              commissionType: commission.type,
              playerId: commission.playerId,
              playerUsername: playerUsername,
              timestamp: today.toISOString()
            },
            message: `Your ${commission.type} commission of ৳${commissionAmount.toLocaleString()} has been paid and added to your balance.`
          });
          
          // Send notification to all admin users
          const adminUsers = await db.select().from(users).where(eq(users.role, 'admin'));
          for (const admin of adminUsers) {
            sendNotification(admin.id, {
              type: 'admin_notification',
              action: 'commission_paid',
              data: {
                agentId: commission.agentId,
                agentUsername: agent.username,
                commissionId: commission.id,
                amount: commissionAmount,
                commissionType: commission.type,
                timestamp: today.toISOString()
              },
              message: `Commission of ৳${commissionAmount.toLocaleString()} paid to agent ${agent.username}.`
            });
          }
        } catch (error) {
          console.error(`Error processing commission ${commission.id}:`, error);
          throw error;
        }
      });
    }
    
    console.log(`Successfully processed ${pendingCommissions.length} commissions`);
  } catch (error) {
    console.error('Error in processScheduledCommissions:', error);
  }
}

/**
 * Setup recurring jobs
 */
export function setupScheduledJobs() {
  // Check for current date/time
  const checkTime = () => {
    const now = new Date();
    console.log(`Current time: ${now.toISOString()}`);
    
    // Check if it's the 4th day of the month and early morning (1-2 AM)
    if (now.getDate() === 4 && now.getHours() === 1) {
      processScheduledCommissions();
    }
  };
  
  // Run check every hour
  setInterval(checkTime, 60 * 60 * 1000);
  
  // Also check immediately on startup
  checkTime();
  
  console.log('Scheduled jobs initialized');
}
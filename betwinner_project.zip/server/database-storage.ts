import { db, pool } from "./db";
import { 
  users, type User, type InsertUser,
  topupTransactions, players, playerTransactions,
  commissions, supportTickets, supportMessages
} from "@shared/schema";
import { eq, and, desc, gte, lte, count } from "drizzle-orm";
import { v4 as uuidv4 } from 'uuid';
import { IStorage } from "./storage";
import session from "express-session";
import connectPg from "connect-pg-simple";

// Interface for top-up requests
interface TopUpRequest {
  amount: number;
  currency: string;
  paymentMethod: "binance_pay" | "custom_usdt";
  walletAddress?: string;
}

export class DatabaseStorage implements IStorage {
  sessionStore: any; // Using any for better compatibility

  constructor() {
    // Set up PostgreSQL session store
    const PostgresSessionStore = connectPg(session);
    this.sessionStore = new PostgresSessionStore({
      pool,
      createTableIfMissing: true,
      tableName: 'sessions'
    });
  }
  // Users
  async getUser(id: number): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.username, username));
    return user;
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const [user] = await db.insert(users).values({
      ...insertUser,
      agentId: insertUser.agentId || uuidv4().slice(0, 8),
      promoCode: insertUser.promoCode || `BW${Math.floor(10000 + Math.random() * 90000)}`,
      balance: insertUser.balance || "0"
    }).returning();
    return user;
  }

  async updateUser(id: number, userData: Partial<User>): Promise<User | undefined> {
    // Make sure balance is a string if provided
    if (userData.balance !== undefined && typeof userData.balance === 'number') {
      userData.balance = userData.balance.toString();
    }
    
    const [updatedUser] = await db.update(users)
      .set(userData)
      .where(eq(users.id, id))
      .returning();
    
    return updatedUser;
  }

  // Top-up transactions
  async createTopupRequest(userId: number, data: TopUpRequest): Promise<any> {
    const user = await this.getUser(userId);
    if (!user) {
      throw new Error("User not found");
    }

    const conversionRate = 125.45; // In a real app, this would come from an external service
    const convertedAmount = data.amount * conversionRate;

    const [transaction] = await db.insert(topupTransactions).values({
      userId,
      transactionId: uuidv4(),
      amount: data.amount.toString(),
      currency: data.currency,
      convertedAmount: convertedAmount.toString(),
      conversionRate: conversionRate.toString(),
      paymentMethod: data.paymentMethod,
      walletAddress: data.walletAddress || null,
      status: "pending"
    }).returning();

    // Update user's balance
    const newBalance = Number(user.balance) + convertedAmount;
    await this.updateUser(userId, { balance: newBalance.toString() });

    return {
      ...transaction,
      amount: Number(transaction.amount),
      convertedAmount: Number(transaction.convertedAmount),
      conversionRate: Number(transaction.conversionRate)
    };
  }

  async getTransactionsByUserId(userId: number): Promise<any[]> {
    // Get top-up transactions
    const topupTxs = await db.select().from(topupTransactions)
      .where(eq(topupTransactions.userId, userId))
      .orderBy(desc(topupTransactions.createdAt));
    
    // Get player transactions
    const playerTxs = await db.select().from(playerTransactions)
      .where(eq(playerTransactions.agentId, userId))
      .orderBy(desc(playerTransactions.createdAt));
    
    // Format top-up transactions
    const formattedTopups = topupTxs.map(tx => ({
      id: tx.transactionId,
      type: "USDT Top-up",
      amount: Number(tx.amount),
      currency: tx.currency,
      convertedAmount: Number(tx.convertedAmount),
      date: new Date(tx.createdAt).toLocaleDateString(),
      time: new Date(tx.createdAt).toLocaleTimeString(),
      status: tx.status,
    }));
    
    // Format player transactions
    const formattedPlayerTxs = playerTxs.map(tx => ({
      id: tx.transactionId,
      type: tx.type === "deposit" ? "Player Deposit" : "Player Withdrawal",
      amount: Number(tx.amount),
      currency: "BDT",
      date: new Date(tx.createdAt).toLocaleDateString(),
      time: new Date(tx.createdAt).toLocaleTimeString(),
      status: tx.status,
    }));
    
    // Combine and sort by date (newest first)
    return [...formattedTopups, ...formattedPlayerTxs].sort((a, b) => 
      new Date(b.date + ' ' + b.time).getTime() - new Date(a.date + ' ' + a.time).getTime()
    );
  }

  async getTopupTransactionsByUserId(userId: number): Promise<any[]> {
    const txs = await db.select().from(topupTransactions)
      .where(eq(topupTransactions.userId, userId))
      .orderBy(desc(topupTransactions.createdAt));
    
    return txs.map(tx => ({
      id: tx.transactionId,
      type: "USDT Top-up",
      amount: Number(tx.amount),
      currency: tx.currency,
      convertedAmount: Number(tx.convertedAmount),
      walletAddress: tx.walletAddress,
      paymentMethod: tx.paymentMethod,
      date: new Date(tx.createdAt).toLocaleDateString(),
      time: new Date(tx.createdAt).toLocaleTimeString(),
      status: tx.status,
    }));
  }

  // Players
  async getPlayersByAgentId(agentId: number): Promise<any[]> {
    const result = await db.select().from(players)
      .where(eq(players.agentId, agentId))
      .orderBy(desc(players.createdAt));
    
    return result.map(player => ({
      id: player.playerId,
      username: player.username,
      registrationDate: new Date(player.createdAt).toLocaleDateString(),
      totalDeposits: Number(player.totalDeposits),
      totalWithdrawals: Number(player.totalWithdrawals),
    }));
  }

  // Player deposit requests
  async createPlayerDepositRequest(agentId: number, data: any): Promise<any> {
    const user = await this.getUser(agentId);
    if (!user) {
      throw new Error("User not found");
    }

    if (Number(user.balance) < data.amount) {
      throw new Error("Insufficient balance");
    }

    const transactionId = uuidv4();
    const commissionAmount = data.amount * 0.02; // 2% commission on deposits

    // Create transaction
    const [transaction] = await db.insert(playerTransactions).values({
      transactionId,
      agentId,
      playerId: data.playerId,
      type: "deposit",
      amount: data.amount.toString(),
      status: "pending",
      commissionAmount: commissionAmount.toString()
    }).returning();

    // Update user balance
    const newBalance = Number(user.balance) - data.amount;
    await this.updateUser(agentId, { balance: newBalance.toString() });

    // Create commission entry
    await db.insert(commissions).values({
      commissionId: uuidv4(),
      agentId,
      playerId: data.playerId,
      transactionId,
      type: "deposit",
      amount: data.amount.toString(),
      commission: commissionAmount.toString(),
      isPaid: false
    });

    return {
      ...transaction,
      amount: Number(transaction.amount),
      commissionAmount: Number(transaction.commissionAmount)
    };
  }

  // Player withdrawal requests
  async createPlayerWithdrawalRequest(agentId: number, data: any): Promise<any> {
    const user = await this.getUser(agentId);
    if (!user) {
      throw new Error("User not found");
    }

    const transactionId = uuidv4();
    const commissionAmount = data.amount * 0.01; // 1% commission on withdrawals

    // Create transaction
    const [transaction] = await db.insert(playerTransactions).values({
      transactionId,
      agentId,
      playerId: data.playerId,
      type: "withdrawal",
      amount: data.amount.toString(),
      paymentCode: data.paymentCode,
      status: "pending",
      commissionAmount: commissionAmount.toString()
    }).returning();

    // Create commission entry
    await db.insert(commissions).values({
      commissionId: uuidv4(),
      agentId,
      playerId: data.playerId,
      transactionId,
      type: "withdrawal",
      amount: data.amount.toString(),
      commission: commissionAmount.toString(),
      isPaid: false
    });

    return {
      ...transaction,
      amount: Number(transaction.amount),
      commissionAmount: Number(transaction.commissionAmount)
    };
  }

  // Commissions
  async getCommissionsByUserId(userId: number): Promise<any[]> {
    const result = await db.select().from(commissions)
      .where(eq(commissions.agentId, userId))
      .orderBy(desc(commissions.createdAt));
    
    // Get players info
    const playerIds = [...new Set(result.map(c => c.playerId))];
    const playerPromises = playerIds.map(id => 
      db.select().from(players).where(eq(players.playerId, id))
    );
    const playersResults = await Promise.all(playerPromises);
    const playersMap = new Map();
    
    playersResults.forEach(players => {
      if (players.length > 0) {
        playersMap.set(players[0].playerId, players[0]);
      }
    });
    
    return result.map(commission => {
      const player = playersMap.get(commission.playerId);
      return {
        id: commission.commissionId,
        type: commission.type,
        playerId: commission.playerId,
        playerUsername: player ? player.username : `Player-${commission.playerId.slice(0, 6)}`,
        amount: Number(commission.amount),
        commission: Number(commission.commission),
        date: new Date(commission.createdAt).toLocaleDateString(),
        isPaid: commission.isPaid,
        paidDate: commission.paidDate ? new Date(commission.paidDate).toLocaleDateString() : undefined,
      };
    });
  }

  async getCommissionsSummary(userId: number): Promise<any> {
    const commissions = await this.getCommissionsByUserId(userId);
    
    const pendingAmount = commissions
      .filter(c => !c.isPaid)
      .reduce((sum, c) => sum + c.commission, 0);
    
    const totalEarnings = commissions
      .reduce((sum, c) => sum + c.commission, 0);
    
    const currentMonth = new Date().getMonth();
    const currentYear = new Date().getFullYear();
    
    const currentMonthEarnings = commissions
      .filter(c => {
        const date = new Date(c.date);
        return date.getMonth() === currentMonth && date.getFullYear() === currentYear;
      })
      .reduce((sum, c) => sum + c.commission, 0);
    
    // Generate monthly data for the past 6 months
    const monthlyData = [];
    for (let i = 0; i < 6; i++) {
      const month = new Date();
      month.setMonth(month.getMonth() - i);
      const monthName = month.toLocaleString('default', { month: 'short' });
      const year = month.getFullYear();
      const monthStart = new Date(year, month.getMonth(), 1);
      const monthEnd = new Date(year, month.getMonth() + 1, 0);
      
      const depositCommissions = commissions
        .filter(c => {
          const date = new Date(c.date);
          return date >= monthStart && date <= monthEnd && c.type === 'deposit';
        })
        .reduce((sum, c) => sum + c.commission, 0);
      
      const withdrawalCommissions = commissions
        .filter(c => {
          const date = new Date(c.date);
          return date >= monthStart && date <= monthEnd && c.type === 'withdrawal';
        })
        .reduce((sum, c) => sum + c.commission, 0);
      
      monthlyData.push({
        month: `${monthName} ${year}`,
        deposit: depositCommissions,
        withdrawal: withdrawalCommissions,
      });
    }
    
    // Calculate next payout date (1st of next month)
    const nextPayoutDate = new Date();
    nextPayoutDate.setMonth(nextPayoutDate.getMonth() + 1);
    nextPayoutDate.setDate(1);
    
    return {
      pendingAmount,
      nextPayoutDate: nextPayoutDate.toLocaleDateString(),
      currentMonthEarnings,
      totalEarnings,
      depositCommissionRate: 2,
      withdrawalCommissionRate: 1,
      monthlyData: monthlyData.reverse(),
    };
  }

  // Affiliate data
  async getAffiliateData(userId: number): Promise<any> {
    const user = await this.getUser(userId);
    if (!user) {
      throw new Error("User not found");
    }
    
    const playerCount = await db.select({ count: count() }).from(players)
      .where(eq(players.agentId, userId));
    
    return {
      promoCode: user.promoCode,
      playerCount: playerCount[0]?.count || 0,
    };
  }

  async getAffiliateStats(userId: number): Promise<any> {
    const user = await this.getUser(userId);
    if (!user) {
      throw new Error("User not found");
    }
    
    const players = await this.getReferredPlayers(userId);
    
    const firstDepositTotal = players.reduce((sum, p) => sum + p.firstDepositAmount, 0);
    
    const commissions = await this.getCommissionsByUserId(userId);
    const totalEarnings = commissions.reduce((sum, c) => sum + c.commission, 0);
    
    // Calculate last month earnings
    const lastMonth = new Date();
    lastMonth.setMonth(lastMonth.getMonth() - 1);
    const lastMonthStart = new Date(lastMonth.getFullYear(), lastMonth.getMonth(), 1);
    const lastMonthEnd = new Date(lastMonth.getFullYear(), lastMonth.getMonth() + 1, 0);
    
    const lastMonthEarnings = commissions
      .filter(c => {
        const date = new Date(c.date);
        return date >= lastMonthStart && date <= lastMonthEnd;
      })
      .reduce((sum, c) => sum + c.commission, 0);
    
    return {
      promoCode: user.promoCode,
      referralLink: `https://betwinner.com/ref?code=${user.promoCode}`,
      playerCount: players.length,
      firstDepositTotal,
      lastMonthEarnings,
      totalEarnings,
    };
  }

  async getReferredPlayers(userId: number): Promise<any[]> {
    const result = await db.select().from(players)
      .where(eq(players.agentId, userId))
      .orderBy(desc(players.createdAt));
    
    return result.map(player => ({
      id: player.playerId,
      username: player.username,
      registrationDate: new Date(player.createdAt).toLocaleDateString(),
      firstDepositAmount: Number(player.firstDepositAmount || 0),
      totalDeposits: Number(player.totalDeposits),
      totalCommission: Number(player.totalDeposits) * 0.02 + Number(player.totalWithdrawals) * 0.01,
      isActive: player.isActive,
    }));
  }

  // Support tickets
  async getSupportTicketsByUserId(userId: number): Promise<any[]> {
    const tickets = await db.select().from(supportTickets)
      .where(eq(supportTickets.userId, userId))
      .orderBy(desc(supportTickets.lastActivity));
    
    const ticketPromises = tickets.map(async ticket => {
      const messages = await db.select().from(supportMessages)
        .where(eq(supportMessages.ticketId, ticket.ticketId))
        .orderBy(supportMessages.createdAt);
      
      const formattedMessages = messages.map(msg => ({
        id: msg.messageId,
        content: msg.content,
        sender: msg.sender,
        timestamp: msg.createdAt,
        read: msg.read,
      }));
      
      const unreadCount = formattedMessages.filter(msg => !msg.read && msg.sender === 'admin').length;
      
      return {
        id: ticket.ticketId,
        subject: ticket.subject,
        status: ticket.status,
        lastActivity: new Date(ticket.lastActivity).toLocaleDateString(),
        unreadCount,
        messages: formattedMessages,
      };
    });
    
    return Promise.all(ticketPromises);
  }

  async createSupportTicket(userId: number, data: any): Promise<any> {
    const user = await this.getUser(userId);
    if (!user) {
      throw new Error("User not found");
    }
    
    const ticketId = uuidv4();
    const now = new Date();
    
    // Create ticket
    const [ticket] = await db.insert(supportTickets).values({
      ticketId,
      userId,
      subject: data.subject,
      status: "open",
      lastActivity: now
    }).returning();
    
    // Add initial message
    const messageId = uuidv4();
    const [message] = await db.insert(supportMessages).values({
      messageId,
      ticketId,
      sender: "user",
      content: data.message,
      read: true
    }).returning();
    
    // Return the ticket with messages
    return {
      ...ticket,
      messages: [{
        id: message.messageId,
        content: message.content,
        sender: message.sender,
        timestamp: message.createdAt,
        read: message.read,
      }],
      unreadCount: 0,
    };
  }

  async addSupportTicketMessage(userId: number, data: any): Promise<any> {
    const user = await this.getUser(userId);
    if (!user) {
      throw new Error("User not found");
    }
    
    const [ticket] = await db.select().from(supportTickets)
      .where(eq(supportTickets.ticketId, data.ticketId));
    
    if (!ticket) {
      throw new Error("Ticket not found");
    }
    
    if (ticket.userId !== userId) {
      throw new Error("Not authorized to access this ticket");
    }
    
    const now = new Date();
    
    // Update ticket
    await db.update(supportTickets)
      .set({ 
        lastActivity: now,
        status: ticket.status === "closed" ? "open" : ticket.status
      })
      .where(eq(supportTickets.ticketId, data.ticketId));
    
    // Add message
    const messageId = uuidv4();
    const [message] = await db.insert(supportMessages).values({
      messageId,
      ticketId: data.ticketId,
      sender: "user",
      content: data.message,
      read: true
    }).returning();
    
    // Simulate admin response after a delay (for demo purposes)
    setTimeout(async () => {
      const adminMessageId = uuidv4();
      await db.insert(supportMessages).values({
        messageId: adminMessageId,
        ticketId: data.ticketId,
        sender: "admin",
        content: "Thank you for your message. Our team will get back to you shortly.",
        read: false
      });
      
      // Update ticket last activity
      await db.update(supportTickets)
        .set({ lastActivity: new Date() })
        .where(eq(supportTickets.ticketId, data.ticketId));
    }, 10000);
    
    return {
      id: message.messageId,
      content: message.content,
      sender: message.sender,
      timestamp: message.createdAt,
      read: message.read,
    };
  }

  async markSupportTicketAsRead(userId: number, ticketId: string): Promise<void> {
    const user = await this.getUser(userId);
    if (!user) {
      throw new Error("User not found");
    }
    
    const [ticket] = await db.select().from(supportTickets)
      .where(eq(supportTickets.ticketId, ticketId));
    
    if (!ticket) {
      throw new Error("Ticket not found");
    }
    
    if (ticket.userId !== userId) {
      throw new Error("Not authorized to access this ticket");
    }
    
    // Mark all admin messages as read
    await db.update(supportMessages)
      .set({ read: true })
      .where(
        and(
          eq(supportMessages.ticketId, ticketId),
          eq(supportMessages.sender, "admin"),
          eq(supportMessages.read, false)
        )
      );
  }
}
import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { setupAuth } from "./auth";
import { z } from "zod";

export async function registerRoutes(app: Express): Promise<Server> {
  // Setup authentication routes
  setupAuth(app);

  const httpServer = createServer(app);

  // Middleware to check authentication
  const requireAuth = (req: any, res: any, next: any) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ message: "Unauthorized" });
    }
    next();
  };

  // Currency rates endpoint
  app.get("/api/rates", requireAuth, (req, res) => {
    // In a real app, this would connect to an external service or database
    res.json({
      usdtToBdt: 125.45,
      lastUpdated: new Date().toISOString(),
    });
  });

  // Top-up requests
  app.post("/api/topup", requireAuth, async (req, res) => {
    try {
      console.log("Processing top-up request:", req.body);
      
      const schema = z.object({
        amount: z.number().positive(),
        currency: z.literal("USDT"),
        paymentMethod: z.enum(["binance_pay", "custom_usdt"]),
        walletAddress: z.string().optional(),
      });

      const data = schema.parse(req.body);
      console.log("Validated data:", data);

      // Process top-up request
      const topupTransaction = await storage.createTopupRequest(req.user!.id, data);
      console.log("Created transaction:", topupTransaction);
      
      // Update user's balance
      const user = await storage.getUser(req.user!.id);
      if (user) {
        const newBalance = Number(user.balance || 0) + (topupTransaction.convertedAmount || 0);
        user.balance = newBalance;
        await storage.updateUser(req.user!.id, { balance: newBalance });
        console.log(`Updated user balance to ${newBalance}`);
      }
      
      res.status(201).json(topupTransaction);
    } catch (error) {
      console.error("Top-up request error:", error);
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid input data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to process top-up request" });
    }
  });

  // Get transactions
  app.get("/api/transactions", requireAuth, async (req, res) => {
    try {
      const transactions = await storage.getTransactionsByUserId(req.user!.id);
      res.json(transactions);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch transactions" });
    }
  });

  // Get top-up transactions
  app.get("/api/transactions/topup", requireAuth, async (req, res) => {
    try {
      const transactions = await storage.getTopupTransactionsByUserId(req.user!.id);
      res.json(transactions);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch top-up transactions" });
    }
  });

  // Get players
  app.get("/api/players", requireAuth, async (req, res) => {
    try {
      const players = await storage.getPlayersByAgentId(req.user!.id);
      res.json(players);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch players" });
    }
  });

  // Player deposit request
  app.post("/api/players/deposit", requireAuth, async (req, res) => {
    try {
      const schema = z.object({
        playerId: z.string(),
        amount: z.number().positive(),
      });

      const data = schema.parse(req.body);
      
      // Check if user has enough balance
      if (Number(req.user!.balance) < data.amount) {
        return res.status(400).json({ message: "Insufficient balance" });
      }

      // Create deposit request
      const depositRequest = await storage.createPlayerDepositRequest(req.user!.id, data);
      
      res.status(201).json(depositRequest);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid input data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to process deposit request" });
    }
  });

  // Player withdrawal request
  app.post("/api/players/withdrawal", requireAuth, async (req, res) => {
    try {
      const schema = z.object({
        playerId: z.string(),
        amount: z.number().positive(),
        paymentCode: z.string(),
      });

      const data = schema.parse(req.body);

      // Create withdrawal request
      const withdrawalRequest = await storage.createPlayerWithdrawalRequest(req.user!.id, data);
      
      res.status(201).json(withdrawalRequest);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid input data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to process withdrawal request" });
    }
  });

  // Get commissions history
  app.get("/api/commissions/history", requireAuth, async (req, res) => {
    try {
      const commissions = await storage.getCommissionsByUserId(req.user!.id);
      res.json(commissions);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch commission history" });
    }
  });

  // Get commissions summary
  app.get("/api/commissions/summary", requireAuth, async (req, res) => {
    try {
      const summary = await storage.getCommissionsSummary(req.user!.id);
      res.json(summary);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch commission summary" });
    }
  });

  // Get affiliate data
  app.get("/api/affiliate", requireAuth, async (req, res) => {
    try {
      const affiliate = await storage.getAffiliateData(req.user!.id);
      res.json(affiliate);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch affiliate data" });
    }
  });

  // Get affiliate stats
  app.get("/api/affiliate/stats", requireAuth, async (req, res) => {
    try {
      const stats = await storage.getAffiliateStats(req.user!.id);
      res.json(stats);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch affiliate stats" });
    }
  });

  // Get referred players
  app.get("/api/affiliate/players", requireAuth, async (req, res) => {
    try {
      const players = await storage.getReferredPlayers(req.user!.id);
      res.json(players);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch referred players" });
    }
  });

  // Get support tickets
  app.get("/api/support/tickets", requireAuth, async (req, res) => {
    try {
      const tickets = await storage.getSupportTicketsByUserId(req.user!.id);
      res.json(tickets);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch support tickets" });
    }
  });

  // Create support ticket
  app.post("/api/support/tickets", requireAuth, async (req, res) => {
    try {
      const schema = z.object({
        subject: z.string().min(1),
        message: z.string().min(1),
      });

      const data = schema.parse(req.body);

      // Create ticket
      const ticket = await storage.createSupportTicket(req.user!.id, data);
      
      res.status(201).json(ticket);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid input data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to create support ticket" });
    }
  });

  // Send message to support ticket
  app.post("/api/support/messages", requireAuth, async (req, res) => {
    try {
      const schema = z.object({
        ticketId: z.string(),
        message: z.string().min(1),
      });

      const data = schema.parse(req.body);

      // Send message
      const message = await storage.addSupportTicketMessage(req.user!.id, data);
      
      res.status(201).json(message);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid input data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to send message" });
    }
  });

  // Mark ticket as read
  app.post("/api/support/tickets/:ticketId/read", requireAuth, async (req, res) => {
    try {
      const ticketId = req.params.ticketId;
      
      // Mark as read
      await storage.markSupportTicketAsRead(req.user!.id, ticketId);
      
      res.status(200).json({ success: true });
    } catch (error) {
      res.status(500).json({ message: "Failed to mark ticket as read" });
    }
  });

  return httpServer;
}

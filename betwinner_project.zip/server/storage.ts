import { users, type User, type InsertUser, topupTransactions, type TopupTransaction } from "@shared/schema";
import { v4 as uuidv4 } from 'uuid';

// modify the interface with any CRUD methods
// you might need

import session from "express-session";
import { v4 as uuidv4 } from 'uuid';
import { User, InsertUser } from "@shared/schema";

interface TopUpRequest {
  amount: number;
  currency: string;
  paymentMethod: "binance_pay" | "custom_usdt";
  walletAddress?: string;
}

export interface IStorage {
  sessionStore: any; // Using 'any' for session store type to avoid TypeScript issues
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUser(id: number, userData: Partial<User>): Promise<User | undefined>;
  createTopupRequest(userId: number, data: TopUpRequest): Promise<any>;
  getTransactionsByUserId(userId: number): Promise<any[]>;
  getTopupTransactionsByUserId(userId: number): Promise<any[]>;
  getPlayersByAgentId(agentId: number): Promise<any[]>;
  createPlayerDepositRequest(agentId: number, data: any): Promise<any>;
  createPlayerWithdrawalRequest(agentId: number, data: any): Promise<any>;
  getCommissionsByUserId(userId: number): Promise<any[]>;
  getCommissionsSummary(userId: number): Promise<any>;
  getAffiliateData(userId: number): Promise<any>;
  getAffiliateStats(userId: number): Promise<any>;
  getReferredPlayers(userId: number): Promise<any[]>;
  getSupportTicketsByUserId(userId: number): Promise<any[]>;
  createSupportTicket(userId: number, data: any): Promise<any>;
  addSupportTicketMessage(userId: number, data: any): Promise<any>;
  markSupportTicketAsRead(userId: number, ticketId: string): Promise<void>;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private topupTransactions: any[];
  private playerTransactions: any[];
  private players: any[];
  private commissions: any[];
  private supportTickets: any[];
  private supportMessages: any[];
  currentId: number;
  sessionStore: any; // Using any for better compatibility

  constructor() {
    this.users = new Map();
    this.topupTransactions = [];
    this.playerTransactions = [];
    this.players = [];
    this.commissions = [];
    this.supportTickets = [];
    this.supportMessages = [];
    this.currentId = 1;
    
    // Create in-memory session store
    const MemoryStore = require('memorystore')(session);
    this.sessionStore = new MemoryStore({
      checkPeriod: 86400000 // prune expired entries every 24h
    });
  }

  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.currentId++;
    // Make sure createdAt is properly set
    const user: User = { 
      ...insertUser, 
      id,
      balance: insertUser.balance?.toString() || "0",
      createdAt: new Date(),
      fullName: insertUser.fullName || null,
      email: insertUser.email || null,
      phone: insertUser.phone || null
    };
    this.users.set(id, user);
    return user;
  }

  async updateUser(id: number, userData: Partial<User>): Promise<User | undefined> {
    const user = await this.getUser(id);
    if (!user) {
      return undefined;
    }

    // Update the user
    const updatedUser = { ...user, ...userData };
    
    // Make sure balance is a string
    if (typeof updatedUser.balance === 'number') {
      updatedUser.balance = updatedUser.balance.toString();
    }
    
    this.users.set(id, updatedUser);
    return updatedUser;
  }

  async createTopupRequest(userId: number, data: TopUpRequest): Promise<any> {
    const user = await this.getUser(userId);
    if (!user) {
      throw new Error("User not found");
    }

    const transaction = {
      id: uuidv4(),
      userId,
      amount: data.amount,
      currency: data.currency,
      convertedAmount: data.amount * 125.45, // Using fixed rate for demo
      conversionRate: 125.45,
      paymentMethod: data.paymentMethod,
      walletAddress: data.walletAddress || null,
      status: "pending",
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };

    this.topupTransactions.push(transaction);
    return transaction;
  }

  async getTransactionsByUserId(userId: number): Promise<any[]> {
    // Combine top-up and player transactions
    const topupTxs = this.topupTransactions
      .filter(tx => tx.userId === userId)
      .map(tx => ({
        id: tx.id,
        type: "USDT Top-up",
        amount: tx.amount,
        currency: tx.currency,
        convertedAmount: tx.convertedAmount,
        date: new Date(tx.createdAt).toLocaleDateString(),
        time: new Date(tx.createdAt).toLocaleTimeString(),
        status: tx.status,
      }));

    const playerTxs = this.playerTransactions
      .filter(tx => tx.agentId === userId)
      .map(tx => ({
        id: tx.id,
        type: tx.type === "deposit" ? "Player Deposit" : "Player Withdrawal",
        amount: tx.amount,
        currency: "BDT",
        date: new Date(tx.createdAt).toLocaleDateString(),
        time: new Date(tx.createdAt).toLocaleTimeString(),
        status: tx.status,
      }));

    return [...topupTxs, ...playerTxs].sort((a, b) => 
      new Date(b.date + ' ' + b.time).getTime() - new Date(a.date + ' ' + a.time).getTime()
    );
  }

  async getTopupTransactionsByUserId(userId: number): Promise<any[]> {
    return this.topupTransactions
      .filter(tx => tx.userId === userId)
      .map(tx => ({
        id: tx.id,
        type: "USDT Top-up",
        amount: tx.amount,
        currency: tx.currency,
        convertedAmount: tx.convertedAmount,
        walletAddress: tx.walletAddress,
        paymentMethod: tx.paymentMethod,
        date: new Date(tx.createdAt).toLocaleDateString(),
        time: new Date(tx.createdAt).toLocaleTimeString(),
        status: tx.status,
      }))
      .sort((a, b) => 
        new Date(b.date + ' ' + b.time).getTime() - new Date(a.date + ' ' + a.time).getTime()
      );
  }

  async getPlayersByAgentId(agentId: number): Promise<any[]> {
    return this.players
      .filter(player => player.agentId === agentId)
      .map(player => ({
        id: player.id,
        username: player.username,
        registrationDate: new Date(player.registrationDate).toLocaleDateString(),
        totalDeposits: player.totalDeposits,
        totalWithdrawals: player.totalWithdrawals,
      }));
  }

  async createPlayerDepositRequest(agentId: number, data: any): Promise<any> {
    const user = await this.getUser(agentId);
    if (!user) {
      throw new Error("User not found");
    }

    if (Number(user.balance) < data.amount) {
      throw new Error("Insufficient balance");
    }

    const transaction = {
      id: uuidv4(),
      agentId,
      playerId: data.playerId,
      type: "deposit",
      amount: data.amount,
      status: "pending",
      commissionAmount: data.amount * 0.02, // 2% commission on deposits
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };

    this.playerTransactions.push(transaction);

    // Update user balance
    user.balance = (Number(user.balance) - data.amount).toString();
    this.users.set(agentId, user);

    // Create commission entry
    const commission = {
      id: uuidv4(),
      agentId,
      playerId: data.playerId,
      transactionId: transaction.id,
      type: "deposit",
      amount: data.amount,
      commission: transaction.commissionAmount,
      isPaid: false,
      createdAt: new Date().toISOString(),
    };

    this.commissions.push(commission);

    return transaction;
  }

  async createPlayerWithdrawalRequest(agentId: number, data: any): Promise<any> {
    const user = await this.getUser(agentId);
    if (!user) {
      throw new Error("User not found");
    }

    const transaction = {
      id: uuidv4(),
      agentId,
      playerId: data.playerId,
      type: "withdrawal",
      amount: data.amount,
      paymentCode: data.paymentCode,
      status: "pending",
      commissionAmount: data.amount * 0.01, // 1% commission on withdrawals
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };

    this.playerTransactions.push(transaction);

    // Create commission entry
    const commission = {
      id: uuidv4(),
      agentId,
      playerId: data.playerId,
      transactionId: transaction.id,
      type: "withdrawal",
      amount: data.amount,
      commission: transaction.commissionAmount,
      isPaid: false,
      createdAt: new Date().toISOString(),
    };

    this.commissions.push(commission);

    return transaction;
  }

  async getCommissionsByUserId(userId: number): Promise<any[]> {
    return this.commissions
      .filter(commission => commission.agentId === userId)
      .map(commission => {
        const player = this.players.find(p => p.id === commission.playerId);
        return {
          id: commission.id,
          type: commission.type,
          playerId: commission.playerId,
          playerUsername: player ? player.username : `Player-${commission.playerId}`,
          amount: commission.amount,
          commission: commission.commission,
          date: new Date(commission.createdAt).toLocaleDateString(),
          isPaid: commission.isPaid,
          paidDate: commission.paidDate ? new Date(commission.paidDate).toLocaleDateString() : undefined,
        };
      })
      .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());
  }

  async getCommissionsSummary(userId: number): Promise<any> {
    const commissions = await this.getCommissionsByUserId(userId);
    
    const pendingAmount = commissions
      .filter(c => !c.isPaid)
      .reduce((sum, c) => sum + c.commission, 0);
    
    const totalEarnings = commissions
      .reduce((sum, c) => sum + c.commission, 0);
    
    const currentMonth = new Date().getMonth();
    const currentYear = new Date().getFullYear();
    
    const currentMonthEarnings = commissions
      .filter(c => {
        const date = new Date(c.date);
        return date.getMonth() === currentMonth && date.getFullYear() === currentYear;
      })
      .reduce((sum, c) => sum + c.commission, 0);
    
    // Generate monthly data for the past 6 months
    const monthlyData = [];
    for (let i = 0; i < 6; i++) {
      const month = new Date();
      month.setMonth(month.getMonth() - i);
      const monthName = month.toLocaleString('default', { month: 'short' });
      const year = month.getFullYear();
      const monthStart = new Date(year, month.getMonth(), 1);
      const monthEnd = new Date(year, month.getMonth() + 1, 0);
      
      const depositCommissions = commissions
        .filter(c => {
          const date = new Date(c.date);
          return date >= monthStart && date <= monthEnd && c.type === 'deposit';
        })
        .reduce((sum, c) => sum + c.commission, 0);
      
      const withdrawalCommissions = commissions
        .filter(c => {
          const date = new Date(c.date);
          return date >= monthStart && date <= monthEnd && c.type === 'withdrawal';
        })
        .reduce((sum, c) => sum + c.commission, 0);
      
      monthlyData.push({
        month: `${monthName} ${year}`,
        deposit: depositCommissions,
        withdrawal: withdrawalCommissions,
      });
    }
    
    // Calculate next payout date (1st of next month)
    const nextPayoutDate = new Date();
    nextPayoutDate.setMonth(nextPayoutDate.getMonth() + 1);
    nextPayoutDate.setDate(1);
    
    return {
      pendingAmount,
      nextPayoutDate: nextPayoutDate.toLocaleDateString(),
      currentMonthEarnings,
      totalEarnings,
      depositCommissionRate: 2,
      withdrawalCommissionRate: 1,
      monthlyData: monthlyData.reverse(),
    };
  }

  async getAffiliateData(userId: number): Promise<any> {
    const user = await this.getUser(userId);
    if (!user) {
      throw new Error("User not found");
    }
    
    const players = await this.getPlayersByAgentId(userId);
    
    return {
      promoCode: user.promoCode,
      playerCount: players.length,
    };
  }

  async getAffiliateStats(userId: number): Promise<any> {
    const user = await this.getUser(userId);
    if (!user) {
      throw new Error("User not found");
    }
    
    const players = await this.getReferredPlayers(userId);
    
    const firstDepositTotal = players.reduce((sum, p) => sum + p.firstDepositAmount, 0);
    
    const commissions = await this.getCommissionsByUserId(userId);
    const totalEarnings = commissions.reduce((sum, c) => sum + c.commission, 0);
    
    // Calculate last month earnings
    const lastMonth = new Date();
    lastMonth.setMonth(lastMonth.getMonth() - 1);
    const lastMonthStart = new Date(lastMonth.getFullYear(), lastMonth.getMonth(), 1);
    const lastMonthEnd = new Date(lastMonth.getFullYear(), lastMonth.getMonth() + 1, 0);
    
    const lastMonthEarnings = commissions
      .filter(c => {
        const date = new Date(c.date);
        return date >= lastMonthStart && date <= lastMonthEnd;
      })
      .reduce((sum, c) => sum + c.commission, 0);
    
    return {
      promoCode: user.promoCode,
      referralLink: `https://betwinner.com/ref?code=${user.promoCode}`,
      playerCount: players.length,
      firstDepositTotal,
      lastMonthEarnings,
      totalEarnings,
    };
  }

  async getReferredPlayers(userId: number): Promise<any[]> {
    // In a real app, this would fetch players referred by this agent
    // Here we'll create some mock data based on our pattern
    return this.players
      .filter(player => player.agentId === userId)
      .map(player => ({
        id: player.id,
        username: player.username,
        registrationDate: new Date(player.registrationDate).toLocaleDateString(),
        firstDepositAmount: player.firstDepositAmount,
        totalDeposits: player.totalDeposits,
        totalCommission: player.totalDeposits * 0.02 + player.totalWithdrawals * 0.01,
        isActive: player.isActive,
      }));
  }

  async getSupportTicketsByUserId(userId: number): Promise<any[]> {
    return this.supportTickets
      .filter(ticket => ticket.userId === userId)
      .map(ticket => {
        const messages = this.supportMessages
          .filter(msg => msg.ticketId === ticket.id)
          .map(msg => ({
            id: msg.id,
            content: msg.content,
            sender: msg.sender,
            timestamp: msg.createdAt,
            read: msg.read,
          }));
        
        const unreadCount = messages.filter(msg => !msg.read && msg.sender === 'admin').length;
        
        return {
          id: ticket.id,
          subject: ticket.subject,
          status: ticket.status,
          lastActivity: new Date(ticket.lastActivity).toLocaleDateString(),
          unreadCount,
          messages,
        };
      });
  }

  async createSupportTicket(userId: number, data: any): Promise<any> {
    const user = await this.getUser(userId);
    if (!user) {
      throw new Error("User not found");
    }
    
    const now = new Date().toISOString();
    const ticketId = uuidv4();
    
    const ticket = {
      id: ticketId,
      userId,
      subject: data.subject,
      status: "open",
      lastActivity: now,
      createdAt: now,
    };
    
    this.supportTickets.push(ticket);
    
    // Add initial message
    const message = {
      id: uuidv4(),
      ticketId: ticketId,
      sender: "user",
      content: data.message,
      read: true,
      createdAt: now,
    };
    
    this.supportMessages.push(message);
    
    // Return the ticket with messages
    return {
      ...ticket,
      messages: [message],
      unreadCount: 0,
    };
  }

  async addSupportTicketMessage(userId: number, data: any): Promise<any> {
    const user = await this.getUser(userId);
    if (!user) {
      throw new Error("User not found");
    }
    
    const ticket = this.supportTickets.find(t => t.id === data.ticketId);
    if (!ticket) {
      throw new Error("Ticket not found");
    }
    
    if (ticket.userId !== userId) {
      throw new Error("Not authorized to access this ticket");
    }
    
    const now = new Date().toISOString();
    
    // Update ticket
    ticket.lastActivity = now;
    if (ticket.status === "closed") {
      ticket.status = "open";
    }
    
    // Add message
    const message = {
      id: uuidv4(),
      ticketId: data.ticketId,
      sender: "user",
      content: data.message,
      read: true,
      createdAt: now,
    };
    
    this.supportMessages.push(message);
    
    // Add admin response after a delay (for demo purposes)
    setTimeout(() => {
      const adminMessage = {
        id: uuidv4(),
        ticketId: data.ticketId,
        sender: "admin",
        content: "Thank you for your message. Our team will get back to you shortly.",
        read: false,
        createdAt: new Date().toISOString(),
      };
      
      this.supportMessages.push(adminMessage);
      
      // Update ticket
      const ticket = this.supportTickets.find(t => t.id === data.ticketId);
      if (ticket) {
        ticket.lastActivity = adminMessage.createdAt;
      }
    }, 10000);
    
    return message;
  }

  async markSupportTicketAsRead(userId: number, ticketId: string): Promise<void> {
    const user = await this.getUser(userId);
    if (!user) {
      throw new Error("User not found");
    }
    
    const ticket = this.supportTickets.find(t => t.id === ticketId);
    if (!ticket) {
      throw new Error("Ticket not found");
    }
    
    if (ticket.userId !== userId) {
      throw new Error("Not authorized to access this ticket");
    }
    
    // Mark all admin messages as read
    this.supportMessages.forEach(msg => {
      if (msg.ticketId === ticketId && msg.sender === 'admin' && !msg.read) {
        msg.read = true;
      }
    });
  }
}

// Import the database storage implementation
import { DatabaseStorage } from "./database-storage";

// Use DatabaseStorage instead of MemStorage for persistence
export const storage = new DatabaseStorage();

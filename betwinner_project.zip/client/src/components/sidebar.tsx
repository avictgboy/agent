import { Link, useLocation } from "wouter";
import { useAuth } from "@/hooks/use-auth";
import { 
  Home, 
  Wallet, 
  Users, 
  ClipboardCheck, 
  UsersRound, 
  MessageSquare,
  LogOut
} from "lucide-react";
import { Button } from "@/components/ui/button";

interface SidebarProps {
  isOpen: boolean;
}

export function Sidebar({ isOpen }: SidebarProps) {
  const [location] = useLocation();
  const { user, logoutMutation } = useAuth();

  const isActive = (path: string) => location === path;

  const navItems = [
    {
      path: "/",
      label: "Dashboard",
      icon: Home,
    },
    {
      path: "/add-funds",
      label: "Add Funds",
      icon: Wallet,
    },
    {
      path: "/player-management",
      label: "Player Management",
      icon: Users,
    },
    {
      path: "/commissions",
      label: "Commissions",
      icon: ClipboardCheck,
    },
    {
      path: "/affiliate",
      label: "Affiliate Program",
      icon: UsersRound,
    },
    {
      path: "/support",
      label: "Support Chat",
      icon: MessageSquare,
    },
  ];

  const handleLogout = () => {
    logoutMutation.mutate();
  };

  return (
    <aside className={`fixed left-0 top-0 w-60 h-full bg-white shadow-lg pt-16 z-20 transform ${isOpen ? 'translate-x-0' : '-translate-x-full'} lg:translate-x-0 transition-transform duration-300`}>
      <div className="px-4 py-6">
        <div className="pb-4 border-b border-gray-200">
          <p className="text-sm text-gray-500">Sub-Agent ID:</p>
          <p className="font-mono text-sm font-medium">
            {user?.agentId || 'N/A'}
          </p>
        </div>
        
        <nav className="mt-6 space-y-1">
          {navItems.map((item) => (
            <Link
              key={item.path}
              href={item.path}
              className={`flex items-center px-4 py-3 text-sm rounded-lg ${
                isActive(item.path)
                  ? "text-primary-600 bg-primary-50 font-medium"
                  : "text-gray-700 hover:bg-gray-100"
              }`}
            >
              <item.icon className="h-5 w-5 mr-3" />
              {item.label}
            </Link>
          ))}
        </nav>
      </div>
      
      <div className="absolute bottom-0 w-full px-4 py-6 border-t border-gray-200">
        <Button 
          variant="ghost" 
          className="flex items-center w-full justify-start text-gray-700 hover:text-primary-600"
          onClick={handleLogout}
          disabled={logoutMutation.isPending}
        >
          <LogOut className="h-5 w-5 mr-3" />
          <span className="text-sm">Logout</span>
        </Button>
      </div>
    </aside>
  );
}

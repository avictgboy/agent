import { useState, useEffect } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import {
  RadioGroup,
  RadioGroupItem,
} from "@/components/ui/radio-group";
import { Label } from "@/components/ui/label";
import { useCurrency } from "@/hooks/use-currency";

interface AddFundsModalProps {
  isOpen: boolean;
  onClose: () => void;
}

const formSchema = z.object({
  amount: z.string().refine(val => !isNaN(Number(val)) && Number(val) > 0, {
    message: "Please enter a valid amount greater than zero",
  }),
  paymentMethod: z.enum(["binance_pay", "custom_usdt"]),
  walletAddress: z.string().optional(),
});

type FormValues = z.infer<typeof formSchema>;

export function AddFundsModal({ isOpen, onClose }: AddFundsModalProps) {
  const { rates, topUpMutation, convertUsdtToBdt } = useCurrency();
  const [calculatedAmount, setCalculatedAmount] = useState("0.00");
  
  const form = useForm<FormValues>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      amount: "",
      paymentMethod: "binance_pay",
      walletAddress: "",
    },
  });

  const { watch, setValue, reset } = form;
  const amount = watch("amount");
  const paymentMethod = watch("paymentMethod");

  useEffect(() => {
    if (amount && !isNaN(Number(amount))) {
      const bdt = convertUsdtToBdt(Number(amount)).toFixed(2);
      setCalculatedAmount(bdt.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ","));
    } else {
      setCalculatedAmount("0.00");
    }
  }, [amount, convertUsdtToBdt]);

  useEffect(() => {
    if (!isOpen) {
      reset();
    }
  }, [isOpen, reset]);

  const onSubmit = (values: FormValues) => {
    topUpMutation.mutate({
      amount: Number(values.amount),
      currency: "USDT",
      paymentMethod: values.paymentMethod as "binance_pay" | "custom_usdt",
      walletAddress: values.paymentMethod === "custom_usdt" ? values.walletAddress : undefined,
    }, {
      onSuccess: () => {
        onClose();
      }
    });
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>Add Funds to Your Account</DialogTitle>
          <DialogDescription>
            Top up your balance with USDT to increase your BDT balance.
          </DialogDescription>
        </DialogHeader>
        
        <div className="mb-4">
          <p className="text-sm text-gray-500 mb-2">Current Exchange Rate</p>
          <div className="bg-gray-50 p-3 rounded-lg">
            <div className="flex justify-between items-center">
              <span className="text-sm font-medium">1 USDT</span>
              <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-gray-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M14 5l7 7m0 0l-7 7m7-7H3" />
              </svg>
              <span className="text-sm font-medium font-mono">
                ৳ {rates.usdtToBdt.toFixed(2)} BDT
              </span>
            </div>
          </div>
        </div>
        
        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
            <FormField
              control={form.control}
              name="amount"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Amount (USDT)</FormLabel>
                  <FormControl>
                    <div className="relative">
                      <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                        <span className="text-gray-500 sm:text-sm">$</span>
                      </div>
                      <Input
                        placeholder="0.00"
                        className="pl-7"
                        {...field}
                      />
                    </div>
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            <div className="bg-gray-50 p-3 rounded-lg">
              <div className="flex justify-between">
                <span className="text-sm text-gray-500">You'll receive:</span>
                <span className="text-sm font-medium font-mono">
                  ৳ {calculatedAmount} BDT
                </span>
              </div>
            </div>
            
            <FormField
              control={form.control}
              name="paymentMethod"
              render={({ field }) => (
                <FormItem className="space-y-2">
                  <FormLabel>Payment Method</FormLabel>
                  <FormControl>
                    <RadioGroup
                      onValueChange={field.onChange}
                      defaultValue={field.value}
                      className="space-y-2"
                    >
                      <div className="relative bg-white border rounded-lg border-gray-300 p-4">
                        <RadioGroupItem
                          value="binance_pay"
                          id="binance-pay"
                          className="absolute left-4 top-4"
                        />
                        <Label
                          htmlFor="binance-pay"
                          className="block ml-8 flex items-center cursor-pointer"
                        >
                          <span className="block text-sm font-medium text-gray-700">Binance Pay</span>
                          <span className="ml-auto text-xs bg-green-100 text-green-800 px-2 py-0.5 rounded-full">Recommended</span>
                        </Label>
                      </div>
                      
                      <div className="relative bg-white border rounded-lg border-gray-300 p-4">
                        <RadioGroupItem
                          value="custom_usdt"
                          id="custom-usdt"
                          className="absolute left-4 top-4"
                        />
                        <Label
                          htmlFor="custom-usdt"
                          className="block ml-8 text-sm font-medium text-gray-700 cursor-pointer"
                        >
                          Custom USDT Address
                        </Label>
                      </div>
                    </RadioGroup>
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            {paymentMethod === "custom_usdt" && (
              <FormField
                control={form.control}
                name="walletAddress"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>USDT Wallet Address</FormLabel>
                    <FormControl>
                      <Input
                        placeholder="Enter USDT wallet address"
                        {...field}
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
            )}
            
            <DialogFooter className="sm:flex-row-reverse sm:justify-start">
              <Button 
                type="submit" 
                disabled={topUpMutation.isPending}
                className="w-full sm:w-auto"
              >
                {topUpMutation.isPending ? "Processing..." : "Continue to Payment"}
              </Button>
              <Button
                type="button"
                variant="outline"
                onClick={onClose}
                className="w-full sm:w-auto mt-2 sm:mt-0"
              >
                Cancel
              </Button>
            </DialogFooter>
          </form>
        </Form>
      </DialogContent>
    </Dialog>
  );
}

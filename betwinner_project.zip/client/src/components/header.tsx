import { useState } from "react";
import { Menu } from "lucide-react";
import { Logo } from "./logo";
import { Notifications } from "./notifications";
import { UserAvatar } from "./user-avatar";
import { UserMenu } from "./user-menu";

interface HeaderProps {
  onToggleSidebar: () => void;
}

export function Header({ onToggleSidebar }: HeaderProps) {
  const [userMenuOpen, setUserMenuOpen] = useState(false);

  const toggleUserMenu = () => {
    setUserMenuOpen(!userMenuOpen);
  };

  return (
    <header className="bg-primary-600 text-white shadow-md fixed top-0 w-full z-30">
      <div className="container mx-auto px-4 py-3 flex justify-between items-center">
        <div className="flex items-center">
          {/* Mobile Menu Button - Only visible on mobile */}
          <button
            type="button"
            className="lg:hidden mr-2"
            onClick={onToggleSidebar}
          >
            <Menu className="h-6 w-6" />
          </button>

          <Logo />
        </div>

        <div className="flex items-center space-x-4">
          <Notifications />
          <UserAvatar onClick={toggleUserMenu} />
          {userMenuOpen && <UserMenu onClose={() => setUserMenuOpen(false)} />}
        </div>
      </div>
    </header>
  );
}

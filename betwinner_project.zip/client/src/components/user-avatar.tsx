import { useAuth } from "@/hooks/use-auth";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";

interface UserAvatarProps {
  onClick?: () => void;
}

export function UserAvatar({ onClick }: UserAvatarProps) {
  const { user } = useAuth();

  const getInitials = () => {
    if (!user) return "?";
    if (user.fullName) {
      return user.fullName
        .split(" ")
        .map(name => name[0])
        .join("")
        .toUpperCase()
        .substring(0, 2);
    }
    return user.username.substring(0, 2).toUpperCase();
  };

  return (
    <button 
      type="button" 
      className="h-8 w-8 rounded-full bg-primary-700 flex items-center justify-center"
      onClick={onClick}
    >
      <Avatar className="h-8 w-8 border-2 border-white">
        <AvatarFallback className="text-sm font-medium bg-primary-700 text-white">
          {getInitials()}
        </AvatarFallback>
      </Avatar>
    </button>
  );
}

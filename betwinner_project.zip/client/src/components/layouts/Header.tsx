import { useAuth } from "@/hooks/use-auth";
import { useToast } from "@/hooks/use-toast";
import { Bell, Menu } from "lucide-react";
import { useState } from "react";
import { useLocation } from "wouter";
import { 
  DropdownMenu, 
  DropdownMenuContent, 
  DropdownMenuItem, 
  DropdownMenuLabel, 
  DropdownMenuSeparator, 
  DropdownMenuTrigger 
} from "@/components/ui/dropdown-menu";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";

type HeaderProps = {
  title?: string;
};

export default function Header({ title }: HeaderProps) {
  const { user, logoutMutation } = useAuth();
  const { toast } = useToast();
  const [, setLocation] = useLocation();
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [notificationCount, setNotificationCount] = useState(3); // Would come from Firebase in production

  const toggleSidebar = () => {
    const sidebar = document.getElementById('sidebar');
    if (sidebar) {
      sidebar.classList.toggle('-translate-x-full');
      setSidebarOpen(!sidebarOpen);
    }
  };

  const handleLogout = () => {
    logoutMutation.mutate();
    setLocation('/auth');
  };

  const showNotifications = () => {
    toast({
      title: "Notifications",
      description: "You have new transaction approvals and messages.",
    });
    setNotificationCount(0);
  };

  if (!user) return null;

  return (
    <header className="bg-primary-600 text-white shadow-md fixed top-0 w-full z-30">
      <div className="container mx-auto px-4 py-3 flex justify-between items-center">
        <div className="flex items-center">
          <Button 
            variant="ghost" 
            size="icon" 
            className="lg:hidden mr-2 text-white hover:bg-primary-700"
            onClick={toggleSidebar}
          >
            <Menu className="h-6 w-6" />
          </Button>
          
          <div className="flex items-center">
            <span className="font-bold text-xl">BetWinner</span>
            <span className="text-sm ml-1">Sub-Agent</span>
          </div>
        </div>
        
        <div className="flex items-center space-x-4">
          <Button 
            variant="ghost" 
            size="icon"
            className="relative text-white hover:bg-primary-700"
            onClick={showNotifications}
          >
            <Bell className="h-6 w-6" />
            {notificationCount > 0 && (
              <Badge 
                variant="destructive" 
                className="absolute -top-1 -right-1 h-5 w-5 flex items-center justify-center p-0 text-xs"
              >
                {notificationCount}
              </Badge>
            )}
          </Button>
          
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button 
                variant="ghost" 
                size="icon" 
                className="h-8 w-8 rounded-full bg-primary-700 flex items-center justify-center hover:bg-primary-800"
              >
                <span className="text-sm font-medium">
                  {user.username.substring(0, 2).toUpperCase()}
                </span>
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end">
              <DropdownMenuLabel>
                <div className="flex flex-col">
                  <span>{user.username}</span>
                  <span className="text-xs text-muted-foreground">{user.agentId}</span>
                </div>
              </DropdownMenuLabel>
              <DropdownMenuSeparator />
              <DropdownMenuItem onSelect={() => setLocation('/profile')}>
                Profile
              </DropdownMenuItem>
              <DropdownMenuItem onSelect={() => setLocation('/settings')}>
                Settings
              </DropdownMenuItem>
              <DropdownMenuSeparator />
              <DropdownMenuItem onSelect={handleLogout}>
                Logout
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
      </div>
    </header>
  );
}

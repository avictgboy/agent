import { Link } from "wouter";

export function Logo() {
  return (
    <Link href="/">
      <a className="flex items-center">
        <span className="font-bold text-xl">BetWinner</span>
        <span className="text-sm ml-1">Sub-Agent</span>
      </a>
    </Link>
  );
}

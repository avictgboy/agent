import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { getQueryFn } from "@/lib/queryClient";
import { useCurrency } from "@/hooks/use-currency";
import { AddFundsModal } from "@/components/add-funds-modal";
import { AppLayout } from "@/layouts/app-layout";

interface Transaction {
  id: string;
  type: string;
  amount: number;
  currency: string;
  convertedAmount?: number;
  walletAddress?: string;
  paymentMethod: string;
  date: string;
  time: string;
  status: "pending" | "completed" | "failed";
}

export default function AddFundsPage() {
  const [isAddFundsModalOpen, setIsAddFundsModalOpen] = useState(false);
  const { rates } = useCurrency();

  // Fetch transactions
  const { data: transactions = [] } = useQuery<Transaction[]>({
    queryKey: ["/api/transactions/topup"],
    queryFn: getQueryFn({ on401: "throw" }),
  });

  const pendingTransactions = transactions.filter(t => t.status === "pending");
  const completedTransactions = transactions.filter(t => t.status === "completed");
  const failedTransactions = transactions.filter(t => t.status === "failed");

  return (
    <AppLayout>
      <div className="mb-6">
        <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center mb-6">
          <div>
            <h1 className="text-2xl font-bold text-gray-900">Add Funds</h1>
            <p className="text-gray-500">Top up your account balance with USDT</p>
          </div>
          <Button 
            onClick={() => setIsAddFundsModalOpen(true)}
            className="mt-4 sm:mt-0"
          >
            Add New Funds
          </Button>
        </div>

        <Card className="mb-6">
          <CardHeader className="pb-3">
            <CardTitle>Current Exchange Rate</CardTitle>
            <CardDescription>
              The current rate for converting USDT to BDT.
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              <div className="flex flex-col">
                <Label className="text-sm text-gray-500 mb-1">1 USDT</Label>
                <div className="flex items-center justify-center bg-gray-50 py-3 px-4 rounded-lg">
                  <span className="text-xl font-bold font-mono">
                    ৳ {rates.usdtToBdt.toFixed(2)}
                  </span>
                  <span className="text-sm text-gray-500 ml-1">BDT</span>
                </div>
              </div>
              <div className="flex flex-col">
                <Label className="text-sm text-gray-500 mb-1">Payment Methods</Label>
                <div className="flex items-center bg-gray-50 py-3 px-4 rounded-lg">
                  <div className="space-x-2">
                    <Badge variant="outline" className="bg-white">Binance Pay</Badge>
                    <Badge variant="outline" className="bg-white">USDT TRC20</Badge>
                  </div>
                </div>
              </div>
              <div className="flex flex-col">
                <Label className="text-sm text-gray-500 mb-1">Processing Time</Label>
                <div className="flex items-center bg-gray-50 py-3 px-4 rounded-lg">
                  <span className="text-sm">Usually within 30 minutes</span>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        <Tabs defaultValue="all" className="w-full">
          <TabsList className="grid grid-cols-4 mb-4 w-full sm:w-auto">
            <TabsTrigger value="all">All</TabsTrigger>
            <TabsTrigger value="pending">
              Pending
              {pendingTransactions.length > 0 && (
                <Badge variant="secondary" className="ml-2">{pendingTransactions.length}</Badge>
              )}
            </TabsTrigger>
            <TabsTrigger value="completed">Completed</TabsTrigger>
            <TabsTrigger value="failed">Failed</TabsTrigger>
          </TabsList>

          <Card>
            <CardHeader className="pb-0">
              <div className="flex justify-between items-center">
                <CardTitle>Transaction History</CardTitle>
                <div className="flex items-center space-x-2">
                  <Input
                    placeholder="Search transactions..."
                    className="max-w-xs"
                  />
                </div>
              </div>
            </CardHeader>
            <CardContent>
              <div className="overflow-x-auto">
                <table className="min-w-full divide-y divide-gray-200 mt-4">
                  <thead className="bg-gray-50">
                    <tr>
                      <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Transaction ID</th>
                      <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Amount</th>
                      <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Payment Method</th>
                      <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Date</th>
                      <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Status</th>
                    </tr>
                  </thead>
                  <tbody className="bg-white divide-y divide-gray-200">
                    {transactions.length === 0 ? (
                      <tr>
                        <td colSpan={5} className="px-6 py-4 text-center text-sm text-gray-500">
                          No transactions found
                        </td>
                      </tr>
                    ) : (
                      <TabsContent value="all">
                        {transactions.map((transaction) => (
                          <tr key={transaction.id}>
                            <td className="px-6 py-4 whitespace-nowrap text-sm font-mono text-gray-900">
                              {transaction.id}
                            </td>
                            <td className="px-6 py-4 whitespace-nowrap">
                              <div className="text-sm font-medium font-mono text-gray-900">
                                {transaction.amount} {transaction.currency}
                              </div>
                              {transaction.convertedAmount && (
                                <div className="text-xs text-gray-500">
                                  ৳ {transaction.convertedAmount.toLocaleString()}
                                </div>
                              )}
                            </td>
                            <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                              {transaction.paymentMethod === "binance_pay" 
                                ? "Binance Pay"
                                : "Custom USDT Address"}
                            </td>
                            <td className="px-6 py-4 whitespace-nowrap">
                              <div className="text-sm text-gray-900">{transaction.date}</div>
                              <div className="text-xs text-gray-500">{transaction.time}</div>
                            </td>
                            <td className="px-6 py-4 whitespace-nowrap">
                              <span className={`px-2 py-1 text-xs font-medium rounded-full ${
                                transaction.status === "completed"
                                  ? "bg-green-100 text-green-800"
                                  : transaction.status === "pending"
                                  ? "bg-yellow-100 text-yellow-800"
                                  : "bg-red-100 text-red-800"
                              }`}>
                                {transaction.status.charAt(0).toUpperCase() + transaction.status.slice(1)}
                              </span>
                            </td>
                          </tr>
                        ))}
                      </TabsContent>
                    )}

                    <TabsContent value="pending">
                      {pendingTransactions.length === 0 ? (
                        <tr>
                          <td colSpan={5} className="px-6 py-4 text-center text-sm text-gray-500">
                            No pending transactions
                          </td>
                        </tr>
                      ) : (
                        pendingTransactions.map((transaction) => (
                          <tr key={transaction.id}>
                            <td className="px-6 py-4 whitespace-nowrap text-sm font-mono text-gray-900">
                              {transaction.id}
                            </td>
                            <td className="px-6 py-4 whitespace-nowrap">
                              <div className="text-sm font-medium font-mono text-gray-900">
                                {transaction.amount} {transaction.currency}
                              </div>
                              {transaction.convertedAmount && (
                                <div className="text-xs text-gray-500">
                                  ৳ {transaction.convertedAmount.toLocaleString()}
                                </div>
                              )}
                            </td>
                            <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                              {transaction.paymentMethod === "binance_pay" 
                                ? "Binance Pay"
                                : "Custom USDT Address"}
                            </td>
                            <td className="px-6 py-4 whitespace-nowrap">
                              <div className="text-sm text-gray-900">{transaction.date}</div>
                              <div className="text-xs text-gray-500">{transaction.time}</div>
                            </td>
                            <td className="px-6 py-4 whitespace-nowrap">
                              <span className="px-2 py-1 text-xs font-medium rounded-full bg-yellow-100 text-yellow-800">
                                Pending
                              </span>
                            </td>
                          </tr>
                        ))
                      )}
                    </TabsContent>

                    <TabsContent value="completed">
                      {completedTransactions.length === 0 ? (
                        <tr>
                          <td colSpan={5} className="px-6 py-4 text-center text-sm text-gray-500">
                            No completed transactions
                          </td>
                        </tr>
                      ) : (
                        completedTransactions.map((transaction) => (
                          <tr key={transaction.id}>
                            <td className="px-6 py-4 whitespace-nowrap text-sm font-mono text-gray-900">
                              {transaction.id}
                            </td>
                            <td className="px-6 py-4 whitespace-nowrap">
                              <div className="text-sm font-medium font-mono text-gray-900">
                                {transaction.amount} {transaction.currency}
                              </div>
                              {transaction.convertedAmount && (
                                <div className="text-xs text-gray-500">
                                  ৳ {transaction.convertedAmount.toLocaleString()}
                                </div>
                              )}
                            </td>
                            <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                              {transaction.paymentMethod === "binance_pay" 
                                ? "Binance Pay"
                                : "Custom USDT Address"}
                            </td>
                            <td className="px-6 py-4 whitespace-nowrap">
                              <div className="text-sm text-gray-900">{transaction.date}</div>
                              <div className="text-xs text-gray-500">{transaction.time}</div>
                            </td>
                            <td className="px-6 py-4 whitespace-nowrap">
                              <span className="px-2 py-1 text-xs font-medium rounded-full bg-green-100 text-green-800">
                                Completed
                              </span>
                            </td>
                          </tr>
                        ))
                      )}
                    </TabsContent>

                    <TabsContent value="failed">
                      {failedTransactions.length === 0 ? (
                        <tr>
                          <td colSpan={5} className="px-6 py-4 text-center text-sm text-gray-500">
                            No failed transactions
                          </td>
                        </tr>
                      ) : (
                        failedTransactions.map((transaction) => (
                          <tr key={transaction.id}>
                            <td className="px-6 py-4 whitespace-nowrap text-sm font-mono text-gray-900">
                              {transaction.id}
                            </td>
                            <td className="px-6 py-4 whitespace-nowrap">
                              <div className="text-sm font-medium font-mono text-gray-900">
                                {transaction.amount} {transaction.currency}
                              </div>
                              {transaction.convertedAmount && (
                                <div className="text-xs text-gray-500">
                                  ৳ {transaction.convertedAmount.toLocaleString()}
                                </div>
                              )}
                            </td>
                            <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                              {transaction.paymentMethod === "binance_pay" 
                                ? "Binance Pay"
                                : "Custom USDT Address"}
                            </td>
                            <td className="px-6 py-4 whitespace-nowrap">
                              <div className="text-sm text-gray-900">{transaction.date}</div>
                              <div className="text-xs text-gray-500">{transaction.time}</div>
                            </td>
                            <td className="px-6 py-4 whitespace-nowrap">
                              <span className="px-2 py-1 text-xs font-medium rounded-full bg-red-100 text-red-800">
                                Failed
                              </span>
                            </td>
                          </tr>
                        ))
                      )}
                    </TabsContent>
                  </tbody>
                </table>
              </div>
            </CardContent>
          </Card>
        </Tabs>
      </div>

      {/* Add Funds Modal */}
      <AddFundsModal 
        isOpen={isAddFundsModalOpen} 
        onClose={() => setIsAddFundsModalOpen(false)} 
      />
    </AppLayout>
  );
}

import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { useLocation } from "wouter";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { getQueryFn, apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/hooks/use-auth";
import { AppLayout } from "@/layouts/app-layout";

interface Player {
  id: string;
  username: string;
  registrationDate: string;
  totalDeposits: number;
  totalWithdrawals: number;
}

interface PlayerDepositRequest {
  playerId: string;
  amount: number;
}

interface PlayerWithdrawalRequest {
  playerId: string;
  amount: number;
  paymentCode: string;
}

const depositFormSchema = z.object({
  playerId: z.string().min(1, { message: "Player ID is required" }),
  amount: z.string().refine(val => !isNaN(Number(val)) && Number(val) > 0, {
    message: "Please enter a valid amount greater than zero",
  }),
});

const withdrawalFormSchema = z.object({
  playerId: z.string().min(1, { message: "Player ID is required" }),
  amount: z.string().refine(val => !isNaN(Number(val)) && Number(val) > 0, {
    message: "Please enter a valid amount greater than zero",
  }),
  paymentCode: z.string().min(1, { message: "Payment code is required" }),
});

type DepositFormValues = z.infer<typeof depositFormSchema>;
type WithdrawalFormValues = z.infer<typeof withdrawalFormSchema>;

export default function PlayerManagementPage() {
  const [location, setLocation] = useLocation();
  const { toast } = useToast();
  const { user } = useAuth();
  const [activeTab, setActiveTab] = useState(() => {
    const params = new URLSearchParams(location.split("?")[1]);
    return params.get("tab") || "deposit";
  });

  // Fetch players
  const { data: players = [] } = useQuery<Player[]>({
    queryKey: ["/api/players"],
    queryFn: getQueryFn({ on401: "throw" }),
  });

  // Deposit form
  const depositForm = useForm<DepositFormValues>({
    resolver: zodResolver(depositFormSchema),
    defaultValues: {
      playerId: "",
      amount: "",
    },
  });

  // Withdrawal form
  const withdrawalForm = useForm<WithdrawalFormValues>({
    resolver: zodResolver(withdrawalFormSchema),
    defaultValues: {
      playerId: "",
      amount: "",
      paymentCode: "",
    },
  });

  // Deposit mutation
  const depositMutation = useMutation({
    mutationFn: async (data: PlayerDepositRequest) => {
      const res = await apiRequest("POST", "/api/players/deposit", data);
      return await res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/players"] });
      queryClient.invalidateQueries({ queryKey: ["/api/user"] });
      toast({
        title: "Deposit request submitted",
        description: "Your deposit request has been submitted and is pending approval.",
      });
      depositForm.reset();
    },
    onError: (error: Error) => {
      toast({
        title: "Deposit request failed",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  // Withdrawal mutation
  const withdrawalMutation = useMutation({
    mutationFn: async (data: PlayerWithdrawalRequest) => {
      const res = await apiRequest("POST", "/api/players/withdrawal", data);
      return await res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/players"] });
      queryClient.invalidateQueries({ queryKey: ["/api/user"] });
      toast({
        title: "Withdrawal request submitted",
        description: "Your withdrawal request has been submitted and is pending approval.",
      });
      withdrawalForm.reset();
    },
    onError: (error: Error) => {
      toast({
        title: "Withdrawal request failed",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const onDepositSubmit = (values: DepositFormValues) => {
    depositMutation.mutate({
      playerId: values.playerId,
      amount: Number(values.amount),
    });
  };

  const onWithdrawalSubmit = (values: WithdrawalFormValues) => {
    withdrawalMutation.mutate({
      playerId: values.playerId,
      amount: Number(values.amount),
      paymentCode: values.paymentCode,
    });
  };

  const handleTabChange = (value: string) => {
    setActiveTab(value);
    setLocation(`/player-management${value !== "deposit" ? `?tab=${value}` : ""}`);
  };

  return (
    <AppLayout>
      <div className="mb-6">
        <h1 className="text-2xl font-bold text-gray-900 mb-2">Player Management</h1>
        <p className="text-gray-500">Manage player deposits and withdrawals</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2">
          <Card>
            <CardHeader>
              <CardTitle>Player Actions</CardTitle>
              <CardDescription>
                Process player deposits and withdrawals. Your current balance: 
                <span className="font-mono font-medium ml-1">৳ {user?.balance?.toLocaleString() || "0"}</span>
              </CardDescription>
            </CardHeader>
            <CardContent>
              <Tabs value={activeTab} onValueChange={handleTabChange}>
                <TabsList className="grid w-full grid-cols-2">
                  <TabsTrigger value="deposit">Deposit</TabsTrigger>
                  <TabsTrigger value="withdrawal">Withdrawal</TabsTrigger>
                </TabsList>
                <TabsContent value="deposit" className="pt-4">
                  <p className="text-sm text-gray-500 mb-4">
                    Process a deposit for a player. Your balance will be used to fund this transaction.
                  </p>
                  <Form {...depositForm}>
                    <form onSubmit={depositForm.handleSubmit(onDepositSubmit)} className="space-y-4">
                      <FormField
                        control={depositForm.control}
                        name="playerId"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Player ID</FormLabel>
                            <FormControl>
                              <Input placeholder="Enter player ID" {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      <FormField
                        control={depositForm.control}
                        name="amount"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Amount (BDT)</FormLabel>
                            <FormControl>
                              <div className="relative">
                                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                                  <span className="text-gray-500 sm:text-sm">৳</span>
                                </div>
                                <Input placeholder="0" className="pl-7" {...field} />
                              </div>
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      <div className="bg-yellow-50 p-3 rounded-lg text-sm text-yellow-800 mb-4">
                        Note: Deposit requests require your account to have sufficient balance and admin approval.
                      </div>
                      <Button 
                        type="submit" 
                        disabled={depositMutation.isPending || (user?.balance || 0) <= 0}
                      >
                        {depositMutation.isPending ? "Processing..." : "Submit Deposit Request"}
                      </Button>
                    </form>
                  </Form>
                </TabsContent>
                <TabsContent value="withdrawal" className="pt-4">
                  <p className="text-sm text-gray-500 mb-4">
                    Process a withdrawal for a player. You'll need both player ID and payment code.
                  </p>
                  <Form {...withdrawalForm}>
                    <form onSubmit={withdrawalForm.handleSubmit(onWithdrawalSubmit)} className="space-y-4">
                      <FormField
                        control={withdrawalForm.control}
                        name="playerId"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Player ID</FormLabel>
                            <FormControl>
                              <Input placeholder="Enter player ID" {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      <FormField
                        control={withdrawalForm.control}
                        name="paymentCode"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Payment Code</FormLabel>
                            <FormControl>
                              <Input placeholder="Enter payment code" {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      <FormField
                        control={withdrawalForm.control}
                        name="amount"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Amount (BDT)</FormLabel>
                            <FormControl>
                              <div className="relative">
                                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                                  <span className="text-gray-500 sm:text-sm">৳</span>
                                </div>
                                <Input placeholder="0" className="pl-7" {...field} />
                              </div>
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      <div className="bg-gray-50 p-3 rounded-lg text-sm text-gray-800 mb-4">
                        <p>Address: <span className="font-medium">Chittagong, Biponi Bitan</span></p>
                      </div>
                      <Button 
                        type="submit" 
                        disabled={withdrawalMutation.isPending}
                      >
                        {withdrawalMutation.isPending ? "Processing..." : "Submit Withdrawal Request"}
                      </Button>
                    </form>
                  </Form>
                </TabsContent>
              </Tabs>
            </CardContent>
          </Card>
        </div>

        <div>
          <Card>
            <CardHeader>
              <CardTitle>Player List</CardTitle>
              <CardDescription>
                Players who registered using your affiliate code
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="mb-4">
                <Input placeholder="Search players..." />
              </div>
              <div className="space-y-3">
                {players.length === 0 ? (
                  <p className="text-center text-sm text-gray-500 py-6">
                    No players found. Share your affiliate code to get started.
                  </p>
                ) : (
                  players.map((player) => (
                    <div key={player.id} className="bg-gray-50 p-3 rounded-lg">
                      <div className="flex justify-between items-start">
                        <div>
                          <p className="font-medium text-sm">{player.username}</p>
                          <p className="text-xs text-gray-500">ID: {player.id}</p>
                          <p className="text-xs text-gray-500">Joined: {player.registrationDate}</p>
                        </div>
                        <div className="text-right">
                          <p className="text-xs text-gray-500">Deposits</p>
                          <p className="text-sm font-mono font-medium">
                            ৳ {player.totalDeposits.toLocaleString()}
                          </p>
                          <p className="text-xs text-gray-500 mt-1">Withdrawals</p>
                          <p className="text-sm font-mono font-medium">
                            ৳ {player.totalWithdrawals.toLocaleString()}
                          </p>
                        </div>
                      </div>
                    </div>
                  ))
                )}
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </AppLayout>
  );
}

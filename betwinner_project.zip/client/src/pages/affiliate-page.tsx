import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { 
  Card, 
  CardContent, 
  CardDescription, 
  CardHeader, 
  CardTitle 
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { Copy, Share2, BarChart3, Users } from "lucide-react";
import { getQueryFn } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { AppLayout } from "@/layouts/app-layout";

interface AffiliateStats {
  promoCode: string;
  referralLink: string;
  playerCount: number;
  firstDepositTotal: number;
  lastMonthEarnings: number;
  totalEarnings: number;
}

interface ReferredPlayer {
  id: string;
  username: string;
  registrationDate: string;
  firstDepositAmount: number;
  totalDeposits: number;
  totalCommission: number;
  isActive: boolean;
}

export default function AffiliatePage() {
  const { toast } = useToast();
  const [searchQuery, setSearchQuery] = useState("");

  // Fetch affiliate stats
  const { data: stats } = useQuery<AffiliateStats>({
    queryKey: ["/api/affiliate/stats"],
    queryFn: getQueryFn({ on401: "throw" }),
  });

  // Fetch referred players
  const { data: players = [] } = useQuery<ReferredPlayer[]>({
    queryKey: ["/api/affiliate/players"],
    queryFn: getQueryFn({ on401: "throw" }),
  });

  const copyToClipboard = (text: string, message: string) => {
    navigator.clipboard.writeText(text);
    toast({
      title: "Copied!",
      description: message,
    });
  };

  const copyPromoCode = () => {
    if (stats?.promoCode) {
      copyToClipboard(stats.promoCode, "Promo code copied to clipboard");
    }
  };

  const copyReferralLink = () => {
    if (stats?.referralLink) {
      copyToClipboard(stats.referralLink, "Referral link copied to clipboard");
    }
  };

  const shareReferralLink = async () => {
    if (stats?.referralLink && navigator.share) {
      try {
        await navigator.share({
          title: 'Join BetWinner via my referral link',
          text: 'Register on BetWinner using my referral link and get special bonuses!',
          url: stats.referralLink,
        });
      } catch (error) {
        console.error('Error sharing:', error);
      }
    } else {
      copyReferralLink();
    }
  };

  const filteredPlayers = searchQuery
    ? players.filter(player => 
        player.username.toLowerCase().includes(searchQuery.toLowerCase()) || 
        player.id.includes(searchQuery)
      )
    : players;

  const activePlayers = players.filter(player => player.isActive);
  const inactivePlayers = players.filter(player => !player.isActive);

  return (
    <AppLayout>
      <div className="mb-6">
        <h1 className="text-2xl font-bold text-gray-900 mb-2">Affiliate Program</h1>
        <p className="text-gray-500">Track your referrals and commissions from referred players</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
        <Card>
          <CardContent className="pt-6">
            <div className="flex flex-col items-center">
              <div className="rounded-full bg-primary-100 p-3 mb-2">
                <Users className="h-6 w-6 text-primary-600" />
              </div>
              <h3 className="text-sm text-gray-500">Referred Players</h3>
              <p className="text-2xl font-bold mt-1">{stats?.playerCount || 0}</p>
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="pt-6">
            <div className="flex flex-col items-center">
              <div className="rounded-full bg-green-100 p-3 mb-2">
                <BarChart3 className="h-6 w-6 text-green-600" />
              </div>
              <h3 className="text-sm text-gray-500">First Deposit Total</h3>
              <p className="text-2xl font-bold font-mono mt-1">
                ৳ {stats?.firstDepositTotal?.toLocaleString() || "0"}
              </p>
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="pt-6">
            <div className="flex flex-col items-center">
              <div className="rounded-full bg-amber-100 p-3 mb-2">
                <BarChart3 className="h-6 w-6 text-amber-600" />
              </div>
              <h3 className="text-sm text-gray-500">Last Month Earnings</h3>
              <p className="text-2xl font-bold font-mono mt-1">
                ৳ {stats?.lastMonthEarnings?.toLocaleString() || "0"}
              </p>
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="pt-6">
            <div className="flex flex-col items-center">
              <div className="rounded-full bg-blue-100 p-3 mb-2">
                <BarChart3 className="h-6 w-6 text-blue-600" />
              </div>
              <h3 className="text-sm text-gray-500">Total Earnings</h3>
              <p className="text-2xl font-bold font-mono mt-1">
                ৳ {stats?.totalEarnings?.toLocaleString() || "0"}
              </p>
            </div>
          </CardContent>
        </Card>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-1">
          <Card>
            <CardHeader>
              <CardTitle>Promotion Tools</CardTitle>
              <CardDescription>
                Share these with potential players to earn commissions
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <h3 className="text-sm font-medium text-gray-700 mb-2">Your Promo Code</h3>
                <div className="bg-gray-100 p-3 rounded-lg flex items-center justify-between">
                  <span className="font-mono font-medium text-gray-700">
                    {stats?.promoCode || "LOADING..."}
                  </span>
                  <Button variant="ghost" size="sm" onClick={copyPromoCode}>
                    <Copy className="h-4 w-4" />
                  </Button>
                </div>
                <p className="text-xs text-gray-500 mt-1">
                  Players can enter this code during registration
                </p>
              </div>
              
              <div>
                <h3 className="text-sm font-medium text-gray-700 mb-2">Your Referral Link</h3>
                <div className="bg-gray-100 p-3 rounded-lg flex items-center justify-between">
                  <span className="font-mono text-sm text-gray-700 truncate max-w-[200px]">
                    {stats?.referralLink || "Loading..."}
                  </span>
                  <div className="flex space-x-1">
                    <Button variant="ghost" size="sm" onClick={copyReferralLink}>
                      <Copy className="h-4 w-4" />
                    </Button>
                    <Button variant="ghost" size="sm" onClick={shareReferralLink}>
                      <Share2 className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
                <p className="text-xs text-gray-500 mt-1">
                  Share this link with potential players
                </p>
              </div>
              
              <div className="bg-primary-50 p-4 rounded-lg border border-primary-100">
                <h3 className="text-sm font-medium text-primary-900 mb-2">Commission Rates</h3>
                <ul className="text-sm space-y-2">
                  <li className="flex justify-between">
                    <span>Player Deposits:</span>
                    <span className="font-medium">2%</span>
                  </li>
                  <li className="flex justify-between">
                    <span>Player Withdrawals:</span>
                    <span className="font-medium">1%</span>
                  </li>
                  <li className="flex justify-between">
                    <span>First Deposit Bonus:</span>
                    <span className="font-medium">Variable (Set by admin)</span>
                  </li>
                </ul>
              </div>
            </CardContent>
          </Card>
        </div>

        <div className="lg:col-span-2">
          <Card>
            <CardHeader>
              <CardTitle>Referred Players</CardTitle>
              <div className="flex items-center justify-between mt-2">
                <CardDescription>
                  Players who registered using your promo code
                </CardDescription>
                <Input 
                  placeholder="Search players..." 
                  className="max-w-[220px]"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                />
              </div>
            </CardHeader>
            <CardContent>
              <Tabs defaultValue="all">
                <TabsList className="mb-4">
                  <TabsTrigger value="all">All ({players.length})</TabsTrigger>
                  <TabsTrigger value="active">Active ({activePlayers.length})</TabsTrigger>
                  <TabsTrigger value="inactive">Inactive ({inactivePlayers.length})</TabsTrigger>
                </TabsList>
                
                <div className="overflow-x-auto">
                  <table className="min-w-full divide-y divide-gray-200">
                    <thead className="bg-gray-50">
                      <tr>
                        <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Player</th>
                        <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Registration</th>
                        <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">First Deposit</th>
                        <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Total Deposits</th>
                        <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Status</th>
                      </tr>
                    </thead>
                    <tbody className="bg-white divide-y divide-gray-200">
                      <TabsContent value="all">
                        {filteredPlayers.length === 0 ? (
                          <tr>
                            <td colSpan={5} className="px-6 py-4 text-center text-sm text-gray-500">
                              {searchQuery ? "No players matching your search" : "No referred players yet"}
                            </td>
                          </tr>
                        ) : (
                          filteredPlayers.map((player) => (
                            <tr key={player.id}>
                              <td className="px-6 py-4 whitespace-nowrap">
                                <div className="text-sm font-medium text-gray-900">{player.username}</div>
                                <div className="text-xs text-gray-500">ID: {player.id}</div>
                              </td>
                              <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                                {player.registrationDate}
                              </td>
                              <td className="px-6 py-4 whitespace-nowrap">
                                <div className="text-sm font-mono font-medium text-gray-900">
                                  ৳ {player.firstDepositAmount.toLocaleString()}
                                </div>
                              </td>
                              <td className="px-6 py-4 whitespace-nowrap">
                                <div className="text-sm font-mono font-medium text-gray-900">
                                  ৳ {player.totalDeposits.toLocaleString()}
                                </div>
                                <div className="text-xs text-gray-500">
                                  Commission: ৳ {player.totalCommission.toLocaleString()}
                                </div>
                              </td>
                              <td className="px-6 py-4 whitespace-nowrap">
                                <Badge variant={player.isActive ? "default" : "secondary"}>
                                  {player.isActive ? "Active" : "Inactive"}
                                </Badge>
                              </td>
                            </tr>
                          ))
                        )}
                      </TabsContent>
                      
                      <TabsContent value="active">
                        {activePlayers.length === 0 ? (
                          <tr>
                            <td colSpan={5} className="px-6 py-4 text-center text-sm text-gray-500">
                              No active players
                            </td>
                          </tr>
                        ) : (
                          activePlayers.map((player) => (
                            <tr key={player.id}>
                              <td className="px-6 py-4 whitespace-nowrap">
                                <div className="text-sm font-medium text-gray-900">{player.username}</div>
                                <div className="text-xs text-gray-500">ID: {player.id}</div>
                              </td>
                              <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                                {player.registrationDate}
                              </td>
                              <td className="px-6 py-4 whitespace-nowrap">
                                <div className="text-sm font-mono font-medium text-gray-900">
                                  ৳ {player.firstDepositAmount.toLocaleString()}
                                </div>
                              </td>
                              <td className="px-6 py-4 whitespace-nowrap">
                                <div className="text-sm font-mono font-medium text-gray-900">
                                  ৳ {player.totalDeposits.toLocaleString()}
                                </div>
                                <div className="text-xs text-gray-500">
                                  Commission: ৳ {player.totalCommission.toLocaleString()}
                                </div>
                              </td>
                              <td className="px-6 py-4 whitespace-nowrap">
                                <Badge>Active</Badge>
                              </td>
                            </tr>
                          ))
                        )}
                      </TabsContent>
                      
                      <TabsContent value="inactive">
                        {inactivePlayers.length === 0 ? (
                          <tr>
                            <td colSpan={5} className="px-6 py-4 text-center text-sm text-gray-500">
                              No inactive players
                            </td>
                          </tr>
                        ) : (
                          inactivePlayers.map((player) => (
                            <tr key={player.id}>
                              <td className="px-6 py-4 whitespace-nowrap">
                                <div className="text-sm font-medium text-gray-900">{player.username}</div>
                                <div className="text-xs text-gray-500">ID: {player.id}</div>
                              </td>
                              <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                                {player.registrationDate}
                              </td>
                              <td className="px-6 py-4 whitespace-nowrap">
                                <div className="text-sm font-mono font-medium text-gray-900">
                                  ৳ {player.firstDepositAmount.toLocaleString()}
                                </div>
                              </td>
                              <td className="px-6 py-4 whitespace-nowrap">
                                <div className="text-sm font-mono font-medium text-gray-900">
                                  ৳ {player.totalDeposits.toLocaleString()}
                                </div>
                                <div className="text-xs text-gray-500">
                                  Commission: ৳ {player.totalCommission.toLocaleString()}
                                </div>
                              </td>
                              <td className="px-6 py-4 whitespace-nowrap">
                                <Badge variant="secondary">Inactive</Badge>
                              </td>
                            </tr>
                          ))
                        )}
                      </TabsContent>
                    </tbody>
                  </table>
                </div>
              </Tabs>
            </CardContent>
          </Card>
        </div>
      </div>
    </AppLayout>
  );
}

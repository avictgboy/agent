import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Link } from "wouter";
import { 
  User, 
  Wallet, 
  Share2, 
  MessageSquare,
  Copy, 
  Eye, 
  ChevronRight, 
  Plus,
  ArrowUp,
  ArrowDown
} from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";
import { getQueryFn } from "@/lib/queryClient";
import { useAuth } from "@/hooks/use-auth";
import { useCurrency } from "@/hooks/use-currency";
import { AddFundsModal } from "@/components/add-funds-modal";
import { AppLayout } from "@/layouts/app-layout";

interface Transaction {
  id: string;
  type: string;
  amount: number;
  currency: string;
  convertedAmount?: number;
  date: string;
  time: string;
  status: "pending" | "completed" | "failed";
}

export default function DashboardPage() {
  const [isAddFundsModalOpen, setIsAddFundsModalOpen] = useState(false);
  const { user } = useAuth();
  const { rates } = useCurrency();
  const { toast } = useToast();

  // Fetch transactions
  const { data: transactions = [] } = useQuery<Transaction[]>({
    queryKey: ["/api/transactions"],
    queryFn: getQueryFn({ on401: "throw" }),
  });

  // Fetch commissions
  const { data: commissions } = useQuery({
    queryKey: ["/api/commissions"],
    queryFn: getQueryFn({ on401: "throw" }),
  });

  // Fetch affiliate data
  const { data: affiliate } = useQuery({
    queryKey: ["/api/affiliate"],
    queryFn: getQueryFn({ on401: "throw" }),
  });

  const copyPromoCode = () => {
    if (affiliate?.promoCode) {
      navigator.clipboard.writeText(affiliate.promoCode);
      toast({
        title: "Promo Code Copied!",
        description: "Your affiliate promo code has been copied to clipboard.",
      });
    }
  };

  return (
    <AppLayout>
      {/* Balance Cards Section */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4 mb-6">
        {/* BDT Balance Card */}
        <Card className="relative overflow-hidden">
          <div className="absolute top-0 right-0 w-16 h-16 bg-primary-500 opacity-10 rounded-bl-full"></div>
          <CardContent className="p-5">
            <h3 className="text-gray-500 text-sm font-medium mb-1">Available Balance</h3>
            <div className="flex items-baseline">
              <span className="text-2xl font-bold font-mono">
                ৳ {user?.balance?.toLocaleString() || "0"}
              </span>
              <span className="text-sm text-gray-500 ml-1">BDT</span>
            </div>
            <div className="mt-4 flex">
              <Button
                size="sm"
                className="flex items-center"
                onClick={() => setIsAddFundsModalOpen(true)}
              >
                <Plus className="h-4 w-4 mr-1" />
                Add Funds
              </Button>
              <div className="text-xs text-gray-500 flex items-center ml-3">
                <span className="mr-1">USDT/BDT:</span>
                <span className="font-semibold font-mono">{rates.usdtToBdt.toFixed(2)}</span>
              </div>
            </div>
          </CardContent>
        </Card>
        
        {/* Commissions Card */}
        <Card className="relative overflow-hidden">
          <div className="absolute top-0 right-0 w-16 h-16 bg-green-500 opacity-10 rounded-bl-full"></div>
          <CardContent className="p-5">
            <h3 className="text-gray-500 text-sm font-medium mb-1">Commissions</h3>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <p className="text-xs text-gray-500">Pending</p>
                <p className="text-lg font-bold font-mono text-gray-700">
                  ৳ {commissions?.pending?.toLocaleString() || "0"}
                </p>
              </div>
              <div>
                <p className="text-xs text-gray-500">Next Payout</p>
                <p className="text-sm font-medium text-gray-700">
                  {commissions?.nextPayout || "N/A"}
                </p>
              </div>
            </div>
            <div className="mt-4">
              <Link href="/commissions">
                <a className="text-primary-600 hover:text-primary-700 text-sm font-medium flex items-center">
                  View Commission History
                  <ChevronRight className="h-4 w-4 ml-1" />
                </a>
              </Link>
            </div>
          </CardContent>
        </Card>
        
        {/* Affiliate Promo Card */}
        <Card className="relative overflow-hidden">
          <div className="absolute top-0 right-0 w-16 h-16 bg-amber-500 opacity-10 rounded-bl-full"></div>
          <CardContent className="p-5">
            <h3 className="text-gray-500 text-sm font-medium mb-1">Affiliate Promo Code</h3>
            <div className="bg-gray-100 p-2 rounded-lg flex items-center justify-between">
              <span className="font-mono font-medium text-gray-700">
                {affiliate?.promoCode || "N/A"}
              </span>
              <Button variant="ghost" size="sm" onClick={copyPromoCode}>
                <Copy className="h-4 w-4" />
              </Button>
            </div>
            <div className="mt-4 grid grid-cols-2 gap-2">
              <div>
                <p className="text-xs text-gray-500">Referred Players</p>
                <p className="text-lg font-bold text-gray-700">
                  {affiliate?.playerCount || "0"}
                </p>
              </div>
              <div>
                <p className="text-xs text-gray-500">First Deposit</p>
                <p className="text-lg font-bold font-mono text-gray-700">
                  ৳ {affiliate?.firstDepositTotal?.toLocaleString() || "0"}
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
      
      {/* Quick Actions */}
      <div className="mb-8">
        <h2 className="text-lg font-semibold text-gray-800 mb-4">Quick Actions</h2>
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
          <Link href="/player-management">
            <a className="bg-white hover:bg-gray-50 rounded-xl shadow-sm p-4 flex flex-col items-center justify-center text-center">
              <User className="h-8 w-8 text-primary-500 mb-2" />
              <span className="text-sm font-medium text-gray-800">Player Deposit</span>
            </a>
          </Link>
          
          <Link href="/player-management?tab=withdrawal">
            <a className="bg-white hover:bg-gray-50 rounded-xl shadow-sm p-4 flex flex-col items-center justify-center text-center">
              <Wallet className="h-8 w-8 text-primary-500 mb-2" />
              <span className="text-sm font-medium text-gray-800">Player Withdrawal</span>
            </a>
          </Link>
          
          <Link href="/affiliate">
            <a className="bg-white hover:bg-gray-50 rounded-xl shadow-sm p-4 flex flex-col items-center justify-center text-center">
              <Share2 className="h-8 w-8 text-primary-500 mb-2" />
              <span className="text-sm font-medium text-gray-800">Share Affiliate Link</span>
            </a>
          </Link>
          
          <Link href="/support">
            <a className="bg-white hover:bg-gray-50 rounded-xl shadow-sm p-4 flex flex-col items-center justify-center text-center">
              <MessageSquare className="h-8 w-8 text-primary-500 mb-2" />
              <span className="text-sm font-medium text-gray-800">Contact Support</span>
            </a>
          </Link>
        </div>
      </div>
      
      {/* Recent Transactions */}
      <div className="mb-8">
        <div className="flex justify-between items-center mb-4">
          <h2 className="text-lg font-semibold text-gray-800">Recent Transactions</h2>
          <Link href="/transactions">
            <a className="text-primary-600 hover:text-primary-700 text-sm font-medium">View All</a>
          </Link>
        </div>
        
        <Card>
          <div className="overflow-x-auto">
            <table className="min-w-full divide-y divide-gray-200">
              <thead className="bg-gray-50">
                <tr>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Type</th>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Amount</th>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Date</th>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Status</th>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Details</th>
                </tr>
              </thead>
              <tbody className="bg-white divide-y divide-gray-200">
                {transactions.length === 0 ? (
                  <tr>
                    <td colSpan={5} className="px-6 py-4 text-center text-sm text-gray-500">
                      No transactions found
                    </td>
                  </tr>
                ) : (
                  transactions.map((transaction) => (
                    <tr key={transaction.id}>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <div className="flex items-center">
                          <div className={`p-1.5 rounded-lg mr-3 ${
                            transaction.type === "USDT Top-up" 
                              ? "bg-primary-100 text-primary-600"
                              : transaction.type === "Player Deposit"
                              ? "bg-red-100 text-red-600"
                              : "bg-green-100 text-green-600"
                          }`}>
                            {transaction.type === "USDT Top-up" && <Plus className="h-5 w-5" />}
                            {transaction.type === "Player Deposit" && <ArrowUp className="h-5 w-5" />}
                            {transaction.type === "Player Withdrawal" && <ArrowDown className="h-5 w-5" />}
                          </div>
                          <span className="text-sm font-medium text-gray-900">{transaction.type}</span>
                        </div>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <div className="text-sm font-medium font-mono text-gray-900">
                          <span>{transaction.currency}</span> {transaction.amount.toLocaleString()}
                        </div>
                        {transaction.convertedAmount && (
                          <div className="text-xs text-gray-500">
                            ৳ {transaction.convertedAmount.toLocaleString()}
                          </div>
                        )}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <div className="text-sm text-gray-900">{transaction.date}</div>
                        <div className="text-xs text-gray-500">{transaction.time}</div>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <span className={`px-2 py-1 text-xs font-medium rounded-full ${
                          transaction.status === "completed"
                            ? "bg-green-100 text-green-800"
                            : transaction.status === "pending"
                            ? "bg-yellow-100 text-yellow-800"
                            : "bg-red-100 text-red-800"
                        }`}>
                          {transaction.status.charAt(0).toUpperCase() + transaction.status.slice(1)}
                        </span>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                        <Button variant="ghost" size="sm" className="text-primary-600 hover:text-primary-700">
                          <Eye className="h-5 w-5" />
                        </Button>
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </Card>
      </div>

      {/* Add Funds Modal */}
      <AddFundsModal 
        isOpen={isAddFundsModalOpen} 
        onClose={() => setIsAddFundsModalOpen(false)} 
      />
    </AppLayout>
  );
}

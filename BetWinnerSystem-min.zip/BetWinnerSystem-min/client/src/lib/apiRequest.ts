type HttpMethod = 'GET' | 'POST' | 'PUT' | 'DELETE' | 'PATCH';

export async function apiRequest<T>(
  endpoint: string,
  method: HttpMethod = 'GET',
  data?: any
): Promise<T> {
  const headers: HeadersInit = {
    'Content-Type': 'application/json',
  };

  const config: RequestInit = {
    method,
    headers,
    credentials: 'include',
  };

  if (data) {
    config.body = JSON.stringify(data);
  }

  const response = await fetch(endpoint, config);

  if (!response.ok) {
    const errorData = await response.json().catch(() => ({
      message: 'An unknown error occurred',
    }));
    
    throw new Error(
      errorData.message || `API error: ${response.status}`
    );
  }

  // Handle both JSON responses and empty responses (like for DELETE operations)
  if (response.status === 204) {
    return {} as T;
  }

  return await response.json();
}
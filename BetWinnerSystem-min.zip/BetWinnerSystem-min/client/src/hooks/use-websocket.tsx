import { useState, useEffect, useCallback, createContext, useContext, ReactNode } from "react";
import { useAuth } from "./use-auth";
import { useToast } from "./use-toast";
import { queryClient } from "@/lib/queryClient";

type WebSocketMessage = {
  type: string;
  action?: string;
  data?: any;
  message?: string;
};

interface WebSocketContextType {
  isConnected: boolean;
  lastMessage: WebSocketMessage | null;
}

const WebSocketContext = createContext<WebSocketContextType | null>(null);

export function WebSocketProvider({ children }: { children: ReactNode }) {
  const [socket, setSocket] = useState<WebSocket | null>(null);
  const [isConnected, setIsConnected] = useState(false);
  const [lastMessage, setLastMessage] = useState<WebSocketMessage | null>(null);
  const { user } = useAuth();
  const { toast } = useToast();

  // Initialize WebSocket connection
  useEffect(() => {
    if (!user) return;

    // Close any existing connection
    if (socket) {
      socket.close();
    }

    // Create WebSocket connection
    const protocol = window.location.protocol === "https:" ? "wss:" : "ws:";
    const wsUrl = `${protocol}//${window.location.host}/ws`;
    const newSocket = new WebSocket(wsUrl);

    newSocket.addEventListener("open", () => {
      console.log("WebSocket connection established");
      setIsConnected(true);
      
      // Authenticate the WebSocket connection
      newSocket.send(JSON.stringify({
        type: "auth",
        userId: user.id
      }));
    });

    newSocket.addEventListener("message", (event) => {
      try {
        const message = JSON.parse(event.data) as WebSocketMessage;
        console.log("WebSocket message received:", message);
        setLastMessage(message);
        
        // Handle different message types
        if (message.type === "transaction") {
          // Show toast notification
          toast({
            title: "Transaction Update",
            description: message.message || "Transaction status updated",
            variant: "default",
          });
          
          // Invalidate relevant queries
          queryClient.invalidateQueries({ queryKey: ["/api/transactions"] });
        } 
        else if (message.type === "admin_notification") {
          // Admin-specific notifications
          toast({
            title: "Admin Notification",
            description: message.message || "New admin notification",
            variant: "default",
          });
          
          // Invalidate relevant queries based on the notification type
          if (message.action === "transaction") {
            queryClient.invalidateQueries({ queryKey: ["/api/admin/transactions"] });
          }
        }
      } catch (error) {
        console.error("Error parsing WebSocket message:", error);
      }
    });

    newSocket.addEventListener("close", () => {
      console.log("WebSocket connection closed");
      setIsConnected(false);
    });

    newSocket.addEventListener("error", (error) => {
      console.error("WebSocket error:", error);
      setIsConnected(false);
    });

    setSocket(newSocket);

    // Cleanup on unmount
    return () => {
      newSocket.close();
    };
  }, [user, toast]);

  // Reconnect on network status change
  useEffect(() => {
    const handleOnline = () => {
      console.log("Network is online, attempting to reconnect WebSocket");
      if (socket) {
        socket.close();
        setSocket(null);
      }
    };

    window.addEventListener("online", handleOnline);

    return () => {
      window.removeEventListener("online", handleOnline);
    };
  }, [socket]);

  return (
    <WebSocketContext.Provider value={{ isConnected, lastMessage }}>
      {children}
    </WebSocketContext.Provider>
  );
}

export function useWebSocket() {
  const context = useContext(WebSocketContext);
  if (!context) {
    throw new Error("useWebSocket must be used within a WebSocketProvider");
  }
  return context;
}
import { useState, ReactNode } from "react";
import { Header } from "@/components/header";
import { Sidebar } from "@/components/sidebar";
import { MobileNav } from "@/components/mobile-nav";
import { NotificationsListener } from "@/components/notifications-listener";

interface AppLayoutProps {
  children: ReactNode;
}

export function AppLayout({ children }: AppLayoutProps) {
  const [sidebarOpen, setSidebarOpen] = useState(false);

  const toggleSidebar = () => {
    setSidebarOpen(!sidebarOpen);
  };

  return (
    <div className="app-shell min-h-screen bg-gray-100 dark:bg-gray-950">
      <Header onToggleSidebar={toggleSidebar} />
      <Sidebar isOpen={sidebarOpen} />
      
      <main className="content-area pt-16 lg:pl-64">
        <div className="container mx-auto px-4 py-6">
          {children}
        </div>
      </main>
      
      <MobileNav />
      
      {/* Invisible component that listens for real-time notifications */}
      <NotificationsListener />
    </div>
  );
}

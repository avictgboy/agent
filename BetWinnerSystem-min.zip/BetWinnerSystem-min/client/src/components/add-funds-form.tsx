import { useState, useEffect } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import {
  RadioGroup,
  RadioGroupItem,
} from "@/components/ui/radio-group";
import { Label } from "@/components/ui/label";
import { useCurrency } from "@/hooks/use-currency";
import { useToast } from "@/hooks/use-toast";
import { AlertTriangle, CreditCard, Phone, ArrowDownCircle } from "lucide-react";
import { apiRequest } from "@/lib/queryClient";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { getQueryFn } from "@/lib/queryClient";

interface AddFundsFormProps {
  onSuccess: () => void;
}

// Define the form schema
const addFundsSchema = z.object({
  amount: z.string().refine(val => !isNaN(Number(val)) && Number(val) > 0, {
    message: "Please enter a valid amount greater than zero",
  }),
  paymentMethod: z.string().min(1, { message: "Please select a payment method" }),
  accountNumber: z.string().optional(),
  transactionId: z.string().optional(),
  walletAddress: z.string().optional(),
  bankDetails: z.string().optional(),
}).refine(data => {
  // Account number is required for mobile payment methods
  if (['bkash', 'nagad', 'rocket'].includes(data.paymentMethod) && !data.accountNumber) {
    return false;
  }
  // Bank details are required for bank transfer
  if (data.paymentMethod === 'bank_transfer' && !data.bankDetails) {
    return false;
  }
  // For custom_usdt, wallet address is required
  if (data.paymentMethod === 'custom_usdt' && !data.walletAddress) {
    return false; 
  }
  return true;
}, {
  message: "Please fill in all required fields for the selected payment method",
  path: ['paymentMethod']
});

type AddFundsFormValues = z.infer<typeof addFundsSchema>;

// Interface for payment methods from API
interface PaymentMethod {
  id: number;
  type: string;
  name: string;
  details?: {
    walletAddress?: string;
    accountNumber?: string;
    bankDetails?: string;
    instructions?: string;
    [key: string]: any;
  };
  purpose: string;
  active: boolean;
  createdAt: string;
  updatedAt: string;
}

export function AddFundsForm({ onSuccess }: AddFundsFormProps) {
  const { rates, convertUsdtToBdt } = useCurrency();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [calculatedAmount, setCalculatedAmount] = useState("0.00");

  // Fetch active payment methods
  const { data: paymentMethods = [] } = useQuery<PaymentMethod[]>({
    queryKey: ["/api/payment-methods"],
    queryFn: getQueryFn({ on401: "throw" }),
  });
  
  // Get active payment methods
  const activePaymentMethods = paymentMethods.filter(method => method.active && method.purpose === "agent_topup");
  
  // Form setup
  const form = useForm<AddFundsFormValues>({
    resolver: zodResolver(addFundsSchema),
    defaultValues: {
      amount: "",
      paymentMethod: activePaymentMethods.length > 0 ? activePaymentMethods[0]?.type : "",
      accountNumber: "",
      transactionId: "",
      walletAddress: "",
      bankDetails: "",
    },
  });

  const { watch } = form;
  
  const amount = watch("amount");
  const paymentMethod = watch("paymentMethod");

  // Calculate BDT amount based on USDT input
  useEffect(() => {
    if (amount && !isNaN(Number(amount))) {
      // Always USDT to BDT conversion
      const bdt = convertUsdtToBdt(Number(amount)).toFixed(2);
      setCalculatedAmount(bdt.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ","));
    } else {
      setCalculatedAmount("0.00");
    }
  }, [amount, convertUsdtToBdt]);

  const onSubmit = async (values: AddFundsFormValues) => {
    try {
      // Process payment based on selected method
      const paymentData: any = {
        amount: Number(values.amount),
        currency: ["binance_pay", "custom_usdt"].includes(values.paymentMethod) ? "USDT" : "BDT",
        paymentMethod: values.paymentMethod,
      };
      
      // Add method-specific details
      if (values.paymentMethod === "binance_pay") {
        paymentData.walletAddress = values.walletAddress || "";
        if (values.transactionId) paymentData.transactionId = values.transactionId;
      } else if (values.paymentMethod === "custom_usdt" && values.walletAddress) {
        paymentData.walletAddress = values.walletAddress;
      } else if (["bkash", "nagad", "rocket"].includes(values.paymentMethod) && values.accountNumber) {
        paymentData.accountNumber = values.accountNumber;
        if (values.transactionId) paymentData.transactionId = values.transactionId;
      } else if (values.paymentMethod === "bank_transfer" && values.bankDetails) {
        paymentData.bankDetails = values.bankDetails;
        if (values.transactionId) paymentData.transactionId = values.transactionId;
      }
      
      // Submit the topup request
      const response = await apiRequest("POST", "/api/topup", paymentData);
      
      if (response.ok) {
        toast({
          title: "Payment request submitted",
          description: "Your fund request has been submitted successfully.",
        });
        
        // Invalidate queries to refresh data
        queryClient.invalidateQueries({ queryKey: ["/api/transactions"] });
        queryClient.invalidateQueries({ queryKey: ["/api/transactions/topup"] });
        queryClient.invalidateQueries({ queryKey: ["/api/user"] });
        
        // Call the success callback
        onSuccess();
      } else {
        const errorData = await response.json();
        throw new Error(errorData.message || "Failed to process payment request");
      }
    } catch (error: any) {
      toast({
        variant: "destructive",
        title: "Error",
        description: error.message || "Failed to process your payment request.",
      });
    }
  };

  return (
    <Form {...form}>
      <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
        <FormField
          control={form.control}
          name="amount"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Amount</FormLabel>
              <FormControl>
                <div className="relative">
                  <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                    <span className="text-gray-500 sm:text-sm">$</span>
                  </div>
                  <Input
                    placeholder="0.00"
                    className="pl-7"
                    {...field}
                  />
                </div>
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />
        
        {/* Always show the conversion to BDT */}
        <div className="bg-gray-50 p-3 rounded-lg">
          <div className="flex justify-between">
            <span className="text-sm text-gray-500">You'll receive:</span>
            <span className="text-sm font-medium font-mono">
              ৳ {calculatedAmount} BDT
            </span>
          </div>
        </div>
        
        {/* Payment method selection */}
        <FormField
          control={form.control}
          name="paymentMethod"
          render={({ field }) => (
            <FormItem className="space-y-2">
              <FormLabel>Payment Method</FormLabel>
              <FormControl>
                <RadioGroup
                  onValueChange={field.onChange}
                  defaultValue={field.value}
                  className="space-y-2"
                >
                  {activePaymentMethods.map(method => (
                    <div key={method.id} className="relative bg-white border rounded-lg border-gray-300 p-4">
                      <RadioGroupItem
                        value={method.type}
                        id={`payment-${method.id}`}
                        className="absolute left-4 top-4"
                      />
                      <Label
                        htmlFor={`payment-${method.id}`}
                        className="block ml-8 flex items-center cursor-pointer"
                      >
                        {method.type === 'bkash' && <div className="h-5 w-5 mr-2 text-pink-500 rounded-full bg-pink-500" />}
                        {method.type === 'nagad' && <div className="h-5 w-5 mr-2 text-orange-500 rounded-full bg-orange-500" />}
                        {method.type === 'rocket' && <div className="h-5 w-5 mr-2 text-purple-500 rounded-full bg-purple-500" />}
                        {method.type === 'binance_pay' && <div className="h-5 w-5 mr-2 text-yellow-500 rounded-full bg-yellow-500" />}
                        {method.type === 'custom_usdt' && <div className="h-5 w-5 mr-2 text-blue-500 rounded-full bg-blue-500" />}
                        {method.type === 'bank_transfer' && <div className="h-5 w-5 mr-2 text-green-500 rounded-full bg-green-500" />}
                        
                        <span className="text-sm font-medium text-gray-700">{method.name}</span>
                        
                        {method.type === 'binance_pay' && 
                          <span className="ml-auto text-xs bg-green-100 text-green-800 px-2 py-0.5 rounded-full">Recommended</span>
                        }
                      </Label>
                    </div>
                  ))}
                  
                  {activePaymentMethods.length === 0 && (
                    <div className="p-4 bg-yellow-50 border border-yellow-200 rounded-lg">
                      <div className="text-sm text-yellow-700">
                        <p>No payment methods are currently available. Please try again later.</p>
                      </div>
                    </div>
                  )}
                </RadioGroup>
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />
        
        {/* Conditional fields based on payment method */}
        {paymentMethod === "binance_pay" && (
          <>
            {/* Find the selected payment method */}
            {(() => {
              const selectedMethod = activePaymentMethods.find(m => m.type === paymentMethod);
              return (
                <div className="p-4 bg-yellow-50 border border-yellow-200 rounded-lg mb-4">
                  <div className="flex">
                    <div className="text-sm text-yellow-700">
                      <p className="font-medium">Binance Pay Instructions</p>
                      <p className="mt-1">Send USDT to this wallet address (TRC-20 network): <strong>{selectedMethod?.details?.walletAddress || "TGbTPbHySdZai4Yyy2KkMiM2daCEW65AVu"}</strong></p>
                      {selectedMethod?.details?.instructions && (
                        <p className="mt-1 whitespace-pre-line">{selectedMethod.details.instructions}</p>
                      )}
                    </div>
                  </div>
                </div>
              );
            })()}
            
            <FormField
              control={form.control}
              name="walletAddress"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Your USDT Wallet Address</FormLabel>
                  <FormControl>
                    <Input
                      placeholder="Enter your USDT wallet address"
                      {...field}
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            <FormField
              control={form.control}
              name="transactionId"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Transaction ID (if available)</FormLabel>
                  <FormControl>
                    <Input
                      placeholder="Enter transaction ID or hash"
                      {...field}
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
          </>
        )}
        
        {paymentMethod === "custom_usdt" && (
          <FormField
            control={form.control}
            name="walletAddress"
            render={({ field }) => (
              <FormItem>
                <FormLabel>USDT Wallet Address</FormLabel>
                <FormControl>
                  <Input
                    placeholder="Enter your USDT wallet address"
                    {...field}
                  />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
        )}
        
        {["bkash", "nagad", "rocket"].includes(paymentMethod) && (
          <>
            {/* Find the selected payment method */}
            {(() => {
              const selectedMethod = activePaymentMethods.find(m => m.type === paymentMethod);
              return (
                <div className="p-4 bg-yellow-50 border border-yellow-200 rounded-lg mb-4">
                  <div className="flex">
                    <div className="text-sm text-yellow-700">
                      <p className="font-medium">Payment Instructions</p>
                      <p className="mt-1">Send the amount to this {selectedMethod?.name} number: <strong>{selectedMethod?.details?.accountNumber}</strong></p>
                      {selectedMethod?.details?.instructions && (
                        <p className="mt-1">{selectedMethod.details.instructions}</p>
                      )}
                    </div>
                  </div>
                </div>
              );
            })()}
            
            <FormField
              control={form.control}
              name="accountNumber"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Your Account Number</FormLabel>
                  <FormControl>
                    <Input
                      placeholder="Enter your account number"
                      {...field}
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            <FormField
              control={form.control}
              name="transactionId"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Transaction ID</FormLabel>
                  <FormControl>
                    <Input
                      placeholder="Enter the transaction ID"
                      {...field}
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
          </>
        )}
        
        {paymentMethod === "bank_transfer" && (
          <>
            {/* Find the selected payment method */}
            {(() => {
              const selectedMethod = activePaymentMethods.find(m => m.type === paymentMethod);
              return (
                <div className="p-4 bg-yellow-50 border border-yellow-200 rounded-lg mb-4">
                  <div className="flex">
                    <div className="text-sm text-yellow-700">
                      <p className="font-medium">Bank Details</p>
                      <div className="mt-1 whitespace-pre-wrap">
                        {selectedMethod?.details?.bankDetails || "Account Name: BetWinner Ltd\nAccount Number: 1234-5678-9012\nBank Name: Bangladesh Bank\nBranch: Dhaka Main Branch\nRouting Number: 45678"}
                      </div>
                      {selectedMethod?.details?.instructions && (
                        <p className="mt-1">{selectedMethod.details.instructions}</p>
                      )}
                    </div>
                  </div>
                </div>
              );
            })()}
            
            <FormField
              control={form.control}
              name="bankDetails"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Your Bank Details</FormLabel>
                  <FormControl>
                    <Input
                      placeholder="Enter your bank account details"
                      {...field}
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            <FormField
              control={form.control}
              name="transactionId"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Transaction Reference</FormLabel>
                  <FormControl>
                    <Input
                      placeholder="Enter transaction reference number"
                      {...field}
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
          </>
        )}
        
        <div className="flex justify-end space-x-3">
          <Button 
            type="button" 
            variant="outline" 
            onClick={onSuccess}
          >
            Cancel
          </Button>
          <Button 
            type="submit"
            disabled={form.formState.isSubmitting}
            className="gap-2"
          >
            <ArrowDownCircle className="h-4 w-4" />
            Submit Payment Request
          </Button>
        </div>
      </form>
    </Form>
  );
}
import { useEffect } from "react";
import { useWebSocket } from "@/hooks/use-websocket";
import { useToast } from "@/hooks/use-toast";
import { queryClient } from "@/lib/queryClient";
import { Bell } from "lucide-react";

export function NotificationsListener() {
  const { lastMessage } = useWebSocket();
  const { toast } = useToast();

  // Listen for new notifications and show toasts
  useEffect(() => {
    if (!lastMessage) return;

    // Invalidate relevant queries based on notification type
    if (lastMessage.type === "transaction") {
      // Transaction-related notifications
      queryClient.invalidateQueries({ queryKey: ["/api/transactions"] });
      
      if (lastMessage.action === "admin_funds") {
        // Admin added funds
        queryClient.invalidateQueries({ queryKey: ["/api/user"] });
      }
    } 
    else if (lastMessage.type === "commission") {
      // Commission-related notifications
      queryClient.invalidateQueries({ queryKey: ["/api/commissions"] });
      queryClient.invalidateQueries({ queryKey: ["/api/commissions/history"] });
      queryClient.invalidateQueries({ queryKey: ["/api/commissions/summary"] });
      queryClient.invalidateQueries({ queryKey: ["/api/user"] }); // To update user balance
    }
    else if (lastMessage.type === "admin_notification") {
      // Admin-specific notifications
      if (lastMessage.action === "transaction") {
        queryClient.invalidateQueries({ queryKey: ["/api/admin/transactions"] });
      }
      else if (lastMessage.action === "commission_paid") {
        queryClient.invalidateQueries({ queryKey: ["/api/admin/commissions"] });
      }
    }

    // Show toast notification
    toast({
      title: getNotificationTitle(lastMessage.type, lastMessage.action),
      description: lastMessage.message || "New notification received",
      variant: "default"
    });
  }, [lastMessage, toast]);

  // No visible UI, this component just listens for notifications
  return null;
}

// Helper function to get notification title based on type and action
function getNotificationTitle(type: string, action?: string): string {
  if (type === "transaction") {
    if (action === "created") return "Transaction Created";
    if (action === "status_update") return "Transaction Status Updated";
    if (action === "admin_funds") return "Funds Added";
    return "Transaction Notification";
  }
  
  if (type === "commission") {
    if (action === "paid") return "Commission Paid";
    if (action === "scheduled") return "Commission Scheduled";
    return "Commission Notification";
  }
  
  if (type === "admin_notification") {
    if (action === "transaction") return "New Transaction";
    if (action === "admin_funds") return "Funds Added";
    if (action === "transaction_status_update") return "Transaction Updated";
    if (action === "commission_paid") return "Commission Paid";
    return "Admin Notification";
  }
  
  return "Notification";
}
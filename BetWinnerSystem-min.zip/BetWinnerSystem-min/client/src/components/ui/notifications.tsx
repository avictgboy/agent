import { Bell } from "lucide-react";
import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { useEffect, useState } from "react";
import { Button } from "./button";
import { Badge } from "./badge";

export interface Notification {
  id: string;
  title: string;
  message: string;
  type: 'transaction' | 'system' | 'player';
  read: boolean;
  timestamp: Date;
}

interface NotificationPanelProps {
  notifications: Notification[];
  onMarkAsRead: (id: string) => void;
  onMarkAllAsRead: () => void;
}

export function NotificationPanel({ 
  notifications,
  onMarkAsRead,
  onMarkAllAsRead
}: NotificationPanelProps) {
  return (
    <Card className="w-[350px] max-h-[450px] overflow-hidden">
      <CardHeader className="flex flex-row items-center justify-between py-4">
        <div className="flex items-center">
          <Bell className="h-5 w-5 mr-2" />
          <h3 className="font-medium">Notifications</h3>
        </div>
        <Button variant="ghost" size="sm" onClick={onMarkAllAsRead}>
          Mark all as read
        </Button>
      </CardHeader>
      <CardContent className="overflow-y-auto max-h-[350px] p-0">
        {notifications.length === 0 ? (
          <div className="py-6 text-center text-sm text-muted-foreground">
            No notifications
          </div>
        ) : (
          <div className="divide-y">
            {notifications.map((notification) => (
              <div 
                key={notification.id} 
                className={`p-4 ${notification.read ? 'bg-white' : 'bg-primary-50'}`}
                onClick={() => onMarkAsRead(notification.id)}
              >
                <div className="flex justify-between items-start">
                  <div>
                    <h4 className="text-sm font-medium">{notification.title}</h4>
                    <p className="text-sm text-gray-500 mt-1">{notification.message}</p>
                  </div>
                  {!notification.read && (
                    <Badge variant="default" className="bg-primary-500">New</Badge>
                  )}
                </div>
                <p className="text-xs text-gray-400 mt-2">
                  {new Date(notification.timestamp).toLocaleString()}
                </p>
              </div>
            ))}
          </div>
        )}
      </CardContent>
    </Card>
  );
}

export function NotificationBell() {
  const [notificationCount, setNotificationCount] = useState(0);
  const [showNotifications, setShowNotifications] = useState(false);
  const [notifications, setNotifications] = useState<Notification[]>([]);

  // In a real app, this would come from Firebase or a WebSocket
  useEffect(() => {
    // Mock data for demonstration
    const mockNotifications: Notification[] = [
      {
        id: '1',
        title: 'Transaction Approved',
        message: 'Your USDT top-up of $100 has been approved.',
        type: 'transaction',
        read: false,
        timestamp: new Date(Date.now() - 1000 * 60 * 30) // 30 minutes ago
      },
      {
        id: '2',
        title: 'Player Deposit Request',
        message: 'New player deposit request of ৳5,000 pending approval.',
        type: 'player',
        read: false,
        timestamp: new Date(Date.now() - 1000 * 60 * 120) // 2 hours ago
      },
      {
        id: '3',
        title: 'Commission Payout',
        message: 'Your commission of ৳3,245 has been processed.',
        type: 'system',
        read: true,
        timestamp: new Date(Date.now() - 1000 * 60 * 60 * 24) // 1 day ago
      }
    ];
    
    setNotifications(mockNotifications);
    setNotificationCount(mockNotifications.filter(n => !n.read).length);
  }, []);

  const handleMarkAsRead = (id: string) => {
    setNotifications(prev => 
      prev.map(notification => 
        notification.id === id 
          ? { ...notification, read: true } 
          : notification
      )
    );
    setNotificationCount(prev => Math.max(0, prev - 1));
  };

  const handleMarkAllAsRead = () => {
    setNotifications(prev => 
      prev.map(notification => ({ ...notification, read: true }))
    );
    setNotificationCount(0);
  };

  return (
    <div className="relative">
      <Button 
        variant="ghost" 
        size="icon"
        className="relative text-white hover:bg-primary-700"
        onClick={() => setShowNotifications(!showNotifications)}
      >
        <Bell className="h-6 w-6" />
        {notificationCount > 0 && (
          <Badge 
            variant="destructive" 
            className="absolute -top-1 -right-1 h-5 w-5 flex items-center justify-center p-0 text-xs"
          >
            {notificationCount}
          </Badge>
        )}
      </Button>
      
      {showNotifications && (
        <div className="absolute right-0 mt-2 z-50">
          <NotificationPanel 
            notifications={notifications}
            onMarkAsRead={handleMarkAsRead}
            onMarkAllAsRead={handleMarkAllAsRead}
          />
        </div>
      )}
    </div>
  );
}

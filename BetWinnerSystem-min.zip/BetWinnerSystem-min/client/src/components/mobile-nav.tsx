import { Link, useLocation } from "wouter";
import { Home, Wallet, Users, ClipboardCheck, BarChart } from "lucide-react";

export function MobileNav() {
  const [location] = useLocation();

  const isActive = (path: string) => location === path;

  const navItems = [
    {
      path: "/",
      label: "Home",
      icon: Home,
    },
    {
      path: "/add-funds",
      label: "Add Funds",
      icon: Wallet,
    },
    {
      path: "/player-management",
      label: "Players",
      icon: Users,
    },
    {
      path: "/commissions",
      label: "Commissions",
      icon: ClipboardCheck,
    },
  ];

  return (
    <nav className="fixed bottom-0 left-0 w-full bg-white shadow-lg border-t border-gray-200 z-30 lg:hidden">
      <div className="flex justify-around">
        {navItems.map((item) => (
          <Link
            key={item.path}
            href={item.path}
            className={`flex flex-col items-center justify-center py-3 ${
              isActive(item.path) ? "text-primary" : "text-gray-500"
            }`}
          >
            <item.icon className="h-6 w-6" />
            <span className="text-xs mt-1">{item.label}</span>
          </Link>
        ))}
      </div>
    </nav>
  );
}

import { ReactNode } from "react";
import Header from "./Header";
import Sidebar from "./Sidebar";
import MobileNav from "./MobileNav";
import { useAuth } from "@/hooks/use-auth";

type AppShellProps = {
  children: ReactNode;
  title?: string;
};

export default function AppShell({ children, title }: AppShellProps) {
  const { user } = useAuth();
  
  if (!user) return null;

  return (
    <div className="app-shell min-h-screen bg-gray-50">
      <Header title={title} />
      <Sidebar />
      
      <main className="content-area pt-16">
        <div className="container mx-auto px-4 py-6">
          {children}
        </div>
      </main>
      
      <MobileNav />
    </div>
  );
}

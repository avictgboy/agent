import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { useMutation } from "@tanstack/react-query";
import { AppLayout } from "@/layouts/app-layout";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Form, FormControl, FormDescription, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { Switch } from "@/components/ui/switch";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";

// Form schema
const formSchema = z.object({
  depositCommissionRate: z.coerce.number()
    .min(0, "Minimum rate is 0%")
    .max(10, "Maximum rate is 10%"),
  withdrawalCommissionRate: z.coerce.number()
    .min(0, "Minimum rate is 0%")
    .max(10, "Maximum rate is 10%"),
  isActive: z.boolean().default(true)
});

type FormValues = z.infer<typeof formSchema>;

export default function CommissionSettingsPage() {
  const { toast } = useToast();
  const [activeTab, setActiveTab] = useState("deposit");

  // Initialize form
  const form = useForm<FormValues>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      depositCommissionRate: 2, // Default 2%
      withdrawalCommissionRate: 1, // Default 1%
      isActive: true
    }
  });

  // Save commission settings
  const mutation = useMutation({
    mutationFn: async (data: FormValues) => {
      await apiRequest("POST", "/api/admin/commission-settings", data);
    },
    onSuccess: () => {
      toast({
        title: "Settings Saved",
        description: "Commission settings have been updated successfully."
      });
      queryClient.invalidateQueries({ queryKey: ['/api/admin/commission-settings'] });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: `Failed to save settings: ${(error as Error).message}`,
        variant: "destructive"
      });
    }
  });

  const onSubmit = (values: FormValues) => {
    mutation.mutate(values);
  };

  return (
    <AppLayout>
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-3xl font-bold tracking-tight">Commission Settings</h2>
            <p className="text-muted-foreground">
              Configure commission rates for deposits and withdrawals
            </p>
          </div>
        </div>

        <Card>
          <CardHeader>
            <CardTitle>Configure Commission Rates</CardTitle>
            <CardDescription>
              Set the percentage rates for agent commissions on player transactions
            </CardDescription>
          </CardHeader>
          <CardContent>
            <Tabs defaultValue="deposit" value={activeTab} onValueChange={setActiveTab}>
              <TabsList className="mb-4">
                <TabsTrigger value="deposit">Deposit Commission</TabsTrigger>
                <TabsTrigger value="withdrawal">Withdrawal Commission</TabsTrigger>
                <TabsTrigger value="settings">General Settings</TabsTrigger>
              </TabsList>

              <Form {...form}>
                <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
                  <TabsContent value="deposit">
                    <div className="space-y-4">
                      <FormField
                        control={form.control}
                        name="depositCommissionRate"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Deposit Commission Rate (%)</FormLabel>
                            <FormControl>
                              <Input
                                type="number"
                                step="0.1"
                                min="0"
                                max="10"
                                {...field}
                              />
                            </FormControl>
                            <FormDescription>
                              The percentage agents earn from player deposits
                            </FormDescription>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </div>
                  </TabsContent>

                  <TabsContent value="withdrawal">
                    <div className="space-y-4">
                      <FormField
                        control={form.control}
                        name="withdrawalCommissionRate"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Withdrawal Commission Rate (%)</FormLabel>
                            <FormControl>
                              <Input
                                type="number"
                                step="0.1"
                                min="0"
                                max="10"
                                {...field}
                              />
                            </FormControl>
                            <FormDescription>
                              The percentage agents earn from player withdrawals
                            </FormDescription>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </div>
                  </TabsContent>

                  <TabsContent value="settings">
                    <div className="space-y-4">
                      <FormField
                        control={form.control}
                        name="isActive"
                        render={({ field }) => (
                          <FormItem className="flex flex-row items-center justify-between rounded-lg border p-4">
                            <div className="space-y-0.5">
                              <FormLabel className="text-base">
                                Enable Commission System
                              </FormLabel>
                              <FormDescription>
                                When enabled, agents will earn commissions based on the rates above
                              </FormDescription>
                            </div>
                            <FormControl>
                              <Switch
                                checked={field.value}
                                onCheckedChange={field.onChange}
                              />
                            </FormControl>
                          </FormItem>
                        )}
                      />
                    </div>
                  </TabsContent>

                  <CardFooter className="flex justify-end border-t pt-4 mt-4">
                    <Button
                      type="submit"
                      disabled={mutation.isPending}
                    >
                      {mutation.isPending ? "Saving..." : "Save Settings"}
                    </Button>
                  </CardFooter>
                </form>
              </Form>
            </Tabs>
          </CardContent>
        </Card>
      </div>
    </AppLayout>
  );
}
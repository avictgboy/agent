import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";
import { queryClient } from "@/lib/queryClient";
import { apiRequest } from "../lib/apiRequest";
import { z } from "zod";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { AppLayout } from "@/layouts/app-layout";
import { RecipientAdditionalInfo } from "@shared/schema";

import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import {
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  Table,
  TableBody,
  TableCaption,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { ScrollArea } from "@/components/ui/scroll-area";
import {
  ArrowRightLeft,
  ExternalLink,
  FileCheck,
  FileX,
  CircleDollarSign,
  Clock,
  CheckCircle,
  XCircle
} from "lucide-react";

// Schema for remittance form
const remittanceSchema = z.object({
  recipientChannel: z.enum(["npsb_bank", "bkash", "nagad", "rocket"], {
    required_error: "Please select a payment method",
  }),
  recipientName: z.string().min(3, {
    message: "Recipient name must be at least 3 characters",
  }).optional(),
  recipientAccount: z.string().min(5, {
    message: "Valid account/phone number is required",
  }),
  recipientAdditionalInfo: z.union([
    z.string(),
    z.object({
      bankName: z.string().min(2, "Bank name is required for bank transfers").optional(),
      branchName: z.string().min(2, "Branch name is required for bank transfers").optional(),
      routingNumber: z.string().optional(),
      accountType: z.string().optional(),
    }).passthrough()
  ]).optional(),
  amount: z.coerce.number().positive({
    message: "Amount must be greater than 0",
  }),
  notes: z.string().optional(),
}).refine(
  (data) => {
    // If bank transfer is selected, ensure bank name and branch are provided
    if (data.recipientChannel === "npsb_bank") {
      const additionalInfo = data.recipientAdditionalInfo;
      if (typeof additionalInfo === 'object') {
        return !!additionalInfo.bankName && !!additionalInfo.branchName;
      }
      return false;
    }
    return true;
  },
  {
    message: "Bank name and branch name are required for bank transfers",
    path: ["recipientAdditionalInfo"]
  }
);

type RemittanceFormValues = z.infer<typeof remittanceSchema>;

function RemittancePage() {
  const { toast } = useToast();
  const [selectedChannel, setSelectedChannel] = useState<string | null>(null);
  const [activeTab, setActiveTab] = useState("send");

  // Form setup
  const form = useForm<RemittanceFormValues>({
    resolver: zodResolver(remittanceSchema),
    defaultValues: {
      recipientName: "",
      recipientAccount: "",
      recipientAdditionalInfo: "",
      amount: undefined,
      notes: "",
    },
  });

  // Fetch applicable remittance fees for selected channel
  const { data: channelFees } = useQuery({
    queryKey: ["remittance-fees", selectedChannel],
    queryFn: async () => {
      if (!selectedChannel) return [];
      const response = await apiRequest<any[]>(`/api/remittance-fees/${selectedChannel}`);
      return response;
    },
    enabled: !!selectedChannel,
  });

  // Fetch current user info for balance check
  const { data: user } = useQuery({
    queryKey: ["user"],
    queryFn: async () => {
      const response = await apiRequest<any>("/api/user");
      return response;
    },
  });

  // Fetch remittance transactions
  const { data: transactions = [], refetch: refetchTransactions } = useQuery({
    queryKey: ["remittance-transactions"],
    queryFn: async () => {
      const response = await apiRequest<any[]>("/api/remittance/transactions");
      return response;
    },
  });

  // Calculate estimated fee based on selected channel and amount
  const calculateFee = (amount: number): { fee: number; calculationDetails: string } => {
    // Ensure amount is a proper number
    amount = Number(amount);
    
    // Debug information
    console.log("Calculating fee with:", { 
      selectedChannel, 
      amount, 
      channelFeesAvailable: !!channelFees,
      channelFeesCount: channelFees?.length
    });
    
    if (!channelFees || !selectedChannel || !amount || isNaN(amount)) {
      return { fee: 0, calculationDetails: "Select a channel and enter amount to calculate fee" };
    }

    // Log available fees for debugging
    console.log("Available fees:", channelFees);

    // Define a type for the fee objects
    interface RemittanceFee {
      id: number;
      name: string;
      channel: string;
      feeType: "flat" | "percentage" | "hybrid";
      flatFee: string | null;
      percentageFee: string | null;
      minAmount: string | null;
      maxAmount: string | null;
      active: boolean;
    }
    
    // Find the appropriate fee for the amount
    const applicableFee = channelFees.find(
      (fee: RemittanceFee) => 
        (fee.minAmount === null || Number(fee.minAmount) <= amount) && 
        (fee.maxAmount === null || Number(fee.maxAmount) >= amount)
    );

    console.log("Found applicable fee:", applicableFee);

    if (!applicableFee) {
      return { fee: 0, calculationDetails: "No applicable fee found for this amount" };
    }

    let fee = 0;
    let details = "";

    if (applicableFee.feeType === "flat") {
      fee = Number(applicableFee.flatFee);
      details = `Flat fee: ${fee} BDT`;
    } else if (applicableFee.feeType === "percentage") {
      fee = (Number(applicableFee.percentageFee) / 100) * amount;
      details = `${Number(applicableFee.percentageFee)}% of ${amount} BDT = ${fee.toFixed(2)} BDT`;
    } else if (applicableFee.feeType === "hybrid") {
      const flatComponent = Number(applicableFee.flatFee);
      const percentageComponent = (Number(applicableFee.percentageFee) / 100) * amount;
      fee = flatComponent + percentageComponent;
      details = `Base fee: ${flatComponent} BDT + ${Number(applicableFee.percentageFee)}% of ${amount} BDT (${percentageComponent.toFixed(2)} BDT) = ${fee.toFixed(2)} BDT`;
    }

    return { fee, calculationDetails: details };
  };

  // Submit remittance request
  const remittanceMutation = useMutation({
    mutationFn: async (values: RemittanceFormValues) => {
      return await apiRequest("/api/remittance", "POST", values);
    },
    onSuccess: () => {
      toast({
        title: "Remittance Request Submitted",
        description: "Your remittance request has been submitted and is pending approval.",
      });
      form.reset();
      setSelectedChannel(null);
      refetchTransactions();
      setActiveTab("history");
    },
    onError: (error: any) => {
      toast({
        title: "Failed to submit remittance request",
        description: error.message || "Please try again later",
        variant: "destructive",
      });
    },
  });

  const onSubmit = (values: RemittanceFormValues) => {
    // Check if user has enough balance
    if (user && Number(user.balance) < totalAmount) {
      toast({
        title: "Insufficient Balance",
        description: `You need ৳${totalAmount.toFixed(2)} for this transaction but your current balance is ৳${Number(user.balance).toFixed(2)}`,
        variant: "destructive",
      });
      return;
    }
    
    // Set default values for mobile channels
    const submitValues = {...values};
    
    // Keep the user-provided name if any, otherwise don't set a default
    // This will ensure API properly handles it based on the updated interface
    
    remittanceMutation.mutate(submitValues);
  };

  // Handle channel selection
  const handleChannelChange = (value: string) => {
    setSelectedChannel(value);
    form.setValue("recipientChannel", value as any);
    
    // Reset recipient name field when selecting mobile payment methods
    if (value !== "npsb_bank") {
      form.setValue("recipientName", undefined);
      form.clearErrors("recipientName");
      
      // Reset bank-related fields for mobile payments
      form.setValue("recipientAdditionalInfo", undefined);
    } else {
      // For bank transfers, reset to empty string so it's required
      form.setValue("recipientName", "");
      
      // Initialize bank-related fields with empty object
      form.setValue("recipientAdditionalInfo", {
        bankName: "",
        branchName: "",
        routingNumber: ""
      });
    }
  };

  // Fee estimation based on current form values
  const amount = form.watch("amount");
  const { fee, calculationDetails } = calculateFee(amount ? Number(amount) : 0);
  // Calculate total amount and ensure proper precision
  const amountNumber = amount ? Number(amount) : 0;
  const totalAmount = parseFloat((amountNumber + fee).toFixed(2));

  // Status badge component
  const StatusBadge = ({ status }: { status: string }) => {
    switch (status) {
      case "pending":
        return <Badge variant="outline" className="bg-yellow-100 text-yellow-800 border-yellow-300"><Clock className="h-3 w-3 mr-1" /> Pending</Badge>;
      case "approved":
        return <Badge variant="outline" className="bg-green-100 text-green-800 border-green-300"><CheckCircle className="h-3 w-3 mr-1" /> Approved</Badge>;
      case "rejected":
        return <Badge variant="outline" className="bg-red-100 text-red-800 border-red-300"><XCircle className="h-3 w-3 mr-1" /> Rejected</Badge>;
      default:
        return <Badge variant="outline">{status}</Badge>;
    }
  };

  // Format date
  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString() + " " + date.toLocaleTimeString();
  };

  // Channel name mapping
  const getChannelName = (channel: string) => {
    switch (channel) {
      case "npsb_bank": return "NPSB Bank";
      case "bkash": return "bKash";
      case "nagad": return "Nagad";
      case "rocket": return "Rocket";
      default: return channel;
    }
  };

  return (
    <AppLayout>
      <div className="flex items-center justify-between mb-6">
        <h1 className="text-3xl font-bold">Remittance Service</h1>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
        <TabsList className="grid w-full grid-cols-2">
          <TabsTrigger value="send">
            <ArrowRightLeft className="h-4 w-4 mr-2" />
            Send Remittance
          </TabsTrigger>
          <TabsTrigger value="history">
            <FileCheck className="h-4 w-4 mr-2" />
            Transaction History
          </TabsTrigger>
        </TabsList>

        <TabsContent value="send" className="space-y-6 mt-6">
          <Card className="w-full">
            <CardHeader>
              <CardTitle>Send Money to Bangladesh</CardTitle>
              <CardDescription>
                Fast and secure money transfers to any bank or mobile wallet
              </CardDescription>
            </CardHeader>
            <CardContent>
              <Form {...form}>
                <form
                  onSubmit={form.handleSubmit(onSubmit)}
                  className="space-y-6"
                >
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div className="space-y-4">
                      <FormField
                        control={form.control}
                        name="recipientChannel"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Payment Method</FormLabel>
                            <Select
                              onValueChange={(value) => handleChannelChange(value)}
                              defaultValue={field.value}
                            >
                              <FormControl>
                                <SelectTrigger>
                                  <SelectValue placeholder="Select payment method" />
                                </SelectTrigger>
                              </FormControl>
                              <SelectContent>
                                <SelectItem value="npsb_bank">NPSB Bank Transfer</SelectItem>
                                <SelectItem value="bkash">bKash</SelectItem>
                                <SelectItem value="nagad">Nagad</SelectItem>
                                <SelectItem value="rocket">Rocket</SelectItem>
                              </SelectContent>
                            </Select>
                            <FormDescription>
                              Choose how you want to send the money
                            </FormDescription>
                            <FormMessage />
                          </FormItem>
                        )}
                      />

                      <FormField
                          control={form.control}
                          name="recipientName"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>
                                Recipient Name
                                {selectedChannel !== "npsb_bank" && " (Optional)"}
                              </FormLabel>
                              <FormControl>
                                <Input placeholder="Full name of recipient" {...field} />
                              </FormControl>
                              {selectedChannel !== "npsb_bank" && (
                                <FormDescription>
                                  Optional for mobile payment methods
                                </FormDescription>
                              )}
                              <FormMessage />
                            </FormItem>
                          )}
                        />

                      <FormField
                        control={form.control}
                        name="recipientAccount"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>
                              {selectedChannel === "npsb_bank"
                                ? "Bank Account Number"
                                : "Mobile Number"}
                            </FormLabel>
                            <FormControl>
                              <Input
                                type={selectedChannel !== "npsb_bank" ? "tel" : "text"}
                                inputMode={selectedChannel !== "npsb_bank" ? "numeric" : "text"}
                                pattern={selectedChannel !== "npsb_bank" ? "[0-9]*" : undefined}
                                placeholder={
                                  selectedChannel === "npsb_bank"
                                    ? "Enter account number"
                                    : "Enter mobile number (e.g., 01XXXXXXXXX)"
                                }
                                className={selectedChannel !== "npsb_bank" ? "font-mono" : ""}
                                {...field}
                              />
                            </FormControl>
                            {selectedChannel !== "npsb_bank" && (
                              <FormDescription>
                                Enter the 11-digit mobile number without spaces or dashes
                              </FormDescription>
                            )}
                            <FormMessage />
                          </FormItem>
                        )}
                      />

                      {selectedChannel === "npsb_bank" && (
                        <>
                          <FormField
                            control={form.control}
                            name="recipientAdditionalInfo.bankName"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>Bank Name</FormLabel>
                                <FormControl>
                                  <Input placeholder="Enter bank name" {...field} />
                                </FormControl>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                          <FormField
                            control={form.control}
                            name="recipientAdditionalInfo.branchName"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>Branch Name</FormLabel>
                                <FormControl>
                                  <Input placeholder="Enter branch name" {...field} />
                                </FormControl>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                          <FormField
                            control={form.control}
                            name="recipientAdditionalInfo.routingNumber"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>Routing Number (Optional)</FormLabel>
                                <FormControl>
                                  <Input placeholder="Enter routing number if available" {...field} />
                                </FormControl>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                        </>
                      )}
                    </div>

                    <div className="space-y-4">
                      <FormField
                        control={form.control}
                        name="amount"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Transfer Amount (BDT)</FormLabel>
                            <FormControl>
                              <div className="relative">
                                <span className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-500">
                                  ৳
                                </span>
                                <Input
                                  type="number"
                                  min="0"
                                  step="0.01"
                                  placeholder="0.00"
                                  className="pl-8"
                                  {...field}
                                />
                              </div>
                            </FormControl>
                            <FormDescription>
                              Enter the amount in Bangladeshi Taka (BDT)
                            </FormDescription>
                            <FormMessage />
                          </FormItem>
                        )}
                      />

                      <div className="bg-gray-50 p-4 rounded-md space-y-2 mt-6">
                        <h3 className="font-medium">Fee Summary</h3>
                        <div className="grid grid-cols-2 gap-1 text-sm">
                          <span className="text-gray-600">Transfer amount:</span>
                          <span className="font-medium text-right">
                            ৳ {amountNumber.toFixed(2)}
                          </span>
                          <span className="text-gray-600">Service fee:</span>
                          <span className="font-medium text-right">
                            ৳ {fee.toFixed(2)}
                          </span>
                          <div className="col-span-2 border-t my-1"></div>
                          <span className="text-gray-600">Total amount:</span>
                          <span className="font-bold text-right">
                            ৳ {totalAmount.toFixed(2)}
                          </span>
                        </div>
                        <div className="text-xs text-gray-500 mt-2">
                          {calculationDetails}
                        </div>
                      </div>

                      <FormField
                        control={form.control}
                        name="notes"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Notes (Optional)</FormLabel>
                            <FormControl>
                              <Textarea
                                placeholder="Add any notes or instructions for this transfer"
                                {...field}
                              />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />

                      <div className="pt-4">
                        <Button
                          type="submit"
                          className="w-full"
                          disabled={remittanceMutation.isPending || !selectedChannel}
                        >
                          {remittanceMutation.isPending ? (
                            <>
                              <div className="animate-spin mr-2 h-4 w-4 border-2 border-b-transparent rounded-full"></div>
                              Processing...
                            </>
                          ) : (
                            <>
                              <CircleDollarSign className="mr-2 h-4 w-4" />
                              Send Remittance
                            </>
                          )}
                        </Button>
                      </div>
                    </div>
                  </div>
                </form>
              </Form>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="history" className="mt-6">
          <Card>
            <CardHeader>
              <CardTitle>Remittance History</CardTitle>
              <CardDescription>
                View all your remittance transactions and their status
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="overflow-auto rounded-md border">
                {/* Mobile-friendly cards view for small screens */}
                <div className="block md:hidden">
                  {transactions.length === 0 ? (
                    <div className="text-center py-8 text-gray-500">
                      No transactions found
                    </div>
                  ) : (
                    <div className="space-y-4 p-4">
                      {transactions.map((tx: any) => (
                        <div key={tx.id} className="border rounded-lg p-3 space-y-2 bg-white">
                          <div className="flex justify-between items-center">
                            <div className="text-sm text-gray-500">{formatDate(tx.createdAt)}</div>
                            <StatusBadge status={tx.status} />
                          </div>
                          
                          <div className="py-1">
                            <div className="font-semibold text-sm">
                              {getChannelName(tx.recipientChannel)}
                            </div>
                            
                            <div className="text-sm">
                              {tx.recipientChannel === "npsb_bank" ? (
                                <>
                                  {tx.recipientName && (
                                    <div>Name: {tx.recipientName}</div>
                                  )}
                                  <div>Account: {tx.recipientAccount}</div>
                                  {tx.recipientAdditionalInfo && typeof tx.recipientAdditionalInfo === "object" && (
                                    <>
                                      {tx.recipientAdditionalInfo.bankName && (
                                        <div>Bank: {tx.recipientAdditionalInfo.bankName}</div>
                                      )}
                                      {tx.recipientAdditionalInfo.branchName && (
                                        <div>Branch: {tx.recipientAdditionalInfo.branchName}</div>
                                      )}
                                    </>
                                  )}
                                </>
                              ) : (
                                <div>Number: {tx.recipientAccount}</div>
                              )}
                            </div>
                          </div>
                          
                          <div className="flex justify-between items-center text-sm pt-1 border-t">
                            <div>
                              <span className="font-medium">Amount:</span> {Number(tx.amount).toFixed(2)} BDT
                            </div>
                            <div>
                              <span className="font-medium">Fee:</span> {Number(tx.feeAmount).toFixed(2)} BDT
                            </div>
                          </div>
                          
                          {tx.transactionNumber && (
                            <div className="text-xs text-gray-500 pt-1">
                              <span className="font-medium">Txn ID:</span> {tx.transactionNumber}
                            </div>
                          )}
                          
                          {tx.statusReason && (
                            <div className="text-xs text-gray-500 pt-1">
                              <span className="font-medium">Reason:</span> {tx.statusReason}
                            </div>
                          )}
                        </div>
                      ))}
                    </div>
                  )}
                </div>
                
                {/* Desktop table view for larger screens */}
                <div className="hidden md:block">
                  <ScrollArea className="h-[400px]">
                    <Table>
                      <TableCaption>A list of your recent remittance transactions</TableCaption>
                      <TableHeader>
                        <TableRow>
                          <TableHead>Date</TableHead>
                          <TableHead>Recipient</TableHead>
                          <TableHead>Method</TableHead>
                          <TableHead>Amount</TableHead>
                          <TableHead>Fee</TableHead>
                          <TableHead>Status</TableHead>
                          <TableHead>Transaction ID</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {transactions.length === 0 ? (
                          <TableRow>
                            <TableCell colSpan={7} className="text-center py-8 text-gray-500">
                              No transactions found
                            </TableCell>
                          </TableRow>
                        ) : (
                          transactions.map((tx: {
                            id: number;
                            createdAt: string;
                            recipientName: string | null;
                            recipientAccount: string;
                            recipientChannel: string;
                            recipientAdditionalInfo?: any;
                            amount: string | number;
                            feeAmount: string | number;
                            status: string;
                            statusReason?: string;
                            transactionNumber?: string;
                          }) => (
                            <TableRow key={tx.id}>
                              <TableCell className="whitespace-nowrap">
                                {formatDate(tx.createdAt)}
                              </TableCell>
                              <TableCell>
                                {tx.recipientChannel === "npsb_bank" ? (
                                  <>
                                    {tx.recipientName ? (
                                      <div className="font-medium">{tx.recipientName}</div>
                                    ) : (
                                      <div className="font-medium">Bank User</div>
                                    )}
                                    <div className="text-sm text-gray-500">
                                      <span className="font-medium">Account:</span> {tx.recipientAccount}
                                    </div>
                                    {tx.recipientAdditionalInfo && (
                                      <>
                                        {typeof tx.recipientAdditionalInfo === "string" ? (
                                          <div className="text-xs text-gray-500">
                                            <span className="font-medium">Bank:</span> {tx.recipientAdditionalInfo}
                                          </div>
                                        ) : (
                                          <>
                                            {tx.recipientAdditionalInfo.bankName && (
                                              <div className="text-xs text-gray-500">
                                                <span className="font-medium">Bank:</span> {tx.recipientAdditionalInfo.bankName}
                                              </div>
                                            )}
                                            {tx.recipientAdditionalInfo.branchName && (
                                              <div className="text-xs text-gray-500">
                                                <span className="font-medium">Branch:</span> {tx.recipientAdditionalInfo.branchName}
                                              </div>
                                            )}
                                            {tx.recipientAdditionalInfo.routingNumber && (
                                              <div className="text-xs text-gray-500">
                                                <span className="font-medium">Routing #:</span> {tx.recipientAdditionalInfo.routingNumber}
                                              </div>
                                            )}
                                          </>
                                        )}
                                      </>
                                    )}
                                  </>
                                ) : (
                                  <>
                                    <div className="font-medium">{getChannelName(tx.recipientChannel)}</div>
                                    <div className="text-sm text-gray-500">
                                      <span className="font-medium">Number:</span> {tx.recipientAccount}
                                    </div>
                                  </>
                                )}
                              </TableCell>
                              <TableCell>{getChannelName(tx.recipientChannel)}</TableCell>
                              <TableCell>{Number(tx.amount).toFixed(2)} BDT</TableCell>
                              <TableCell>{Number(tx.feeAmount).toFixed(2)} BDT</TableCell>
                              <TableCell>
                                <StatusBadge status={tx.status} />
                                {tx.statusReason && (
                                  <div className="text-xs text-gray-500 mt-1">
                                    {tx.statusReason}
                                  </div>
                                )}
                              </TableCell>
                              <TableCell>
                                {tx.transactionNumber || "-"}
                              </TableCell>
                            </TableRow>
                          ))
                        )}
                      </TableBody>
                    </Table>
                  </ScrollArea>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </AppLayout>
  );
}

export default RemittancePage;
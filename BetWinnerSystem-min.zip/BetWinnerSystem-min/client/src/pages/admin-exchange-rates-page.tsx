import { useState, useEffect } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { AppLayout } from "@/layouts/app-layout";
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import {
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Save, RefreshCcw, Loader2 } from "lucide-react";

const exchangeRateSchema = z.object({
  usdtToBdt: z.coerce.number().min(1, "Exchange rate must be positive"),
});

type ExchangeRateValues = z.infer<typeof exchangeRateSchema>;

export default function AdminExchangeRatesPage() {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [lastUpdated, setLastUpdated] = useState<string | null>(null);
  
  // Initialize form with default values first
  const form = useForm<ExchangeRateValues>({
    resolver: zodResolver(exchangeRateSchema),
    defaultValues: {
      usdtToBdt: 0,
    },
  });

  // Fetch current exchange rates
  const { data: exchangeRate, isLoading, isError } = useQuery({
    queryKey: ["/api/admin/exchange-rates"],
    staleTime: 30000, // 30 seconds
  });
  
  // Show error toast when query fails
  useEffect(() => {
    if (isError) {
      toast({
        title: "Error",
        description: "Failed to load exchange rates. Please try again.",
        variant: "destructive",
      });
    }
  }, [isError, toast]);
  
  // Update form and last updated when data changes
  useEffect(() => {
    if (exchangeRate) {
      // TypeScript casting to avoid type errors
      const data = exchangeRate as any;
      
      if (data.lastUpdated) {
        setLastUpdated(new Date(data.lastUpdated).toLocaleString());
      }
      
      if (data.usdtToBdt) {
        form.reset({
          usdtToBdt: data.usdtToBdt
        });
      }
    }
  }, [exchangeRate, form]);

  // Update exchange rate mutation
  const updateExchangeRateMutation = useMutation({
    mutationFn: async (data: ExchangeRateValues) => {
      return apiRequest("POST", "/api/admin/exchange-rate", {
        fromCurrency: "USDT",
        toCurrency: "BDT",
        rate: data.usdtToBdt,
        source: "Admin Update"
      });
    },
    onSuccess: () => {
      toast({
        title: "Success",
        description: "Exchange rate updated successfully",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/admin/exchange-rates"] });
      queryClient.invalidateQueries({ queryKey: ["/api/rates"] });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to update exchange rate. Please try again.",
        variant: "destructive",
      });
    },
  });

  // Handle form submission
  const onSubmit = (values: ExchangeRateValues) => {
    updateExchangeRateMutation.mutate(values);
  };

  // Handle manual refresh
  const handleRefresh = () => {
    queryClient.invalidateQueries({ queryKey: ["/api/admin/exchange-rates"] });
  };

  return (
    <AppLayout>
      <div className="container mx-auto py-6">
        <h1 className="text-3xl font-bold mb-6">Exchange Rate Configuration</h1>

        <Card className="mb-8">
          <CardHeader>
            <CardTitle>USDT to BDT Exchange Rate</CardTitle>
            <CardDescription>
              Set the exchange rate for USDT to BDT conversions for the agent topup system
            </CardDescription>
          </CardHeader>
          <CardContent>
            <Form {...form}>
              <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
                <FormField
                  control={form.control}
                  name="usdtToBdt"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>USDT to BDT Rate</FormLabel>
                      <FormControl>
                        <div className="flex items-center gap-2">
                          <span className="text-sm text-muted-foreground">1 USDT =</span>
                          <Input
                            {...field}
                            type="number"
                            step="0.01"
                            min="1"
                            className="max-w-[200px]"
                          />
                          <span className="text-sm text-muted-foreground">BDT</span>
                        </div>
                      </FormControl>
                      <FormDescription>
                        This rate will be used for all USDT to BDT conversions in the system.
                      </FormDescription>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <div className="flex justify-between items-center pt-4">
                  <div className="text-sm text-muted-foreground">
                    {lastUpdated ? `Last updated: ${lastUpdated}` : ""}
                  </div>
                  <div className="flex gap-2">
                    <Button
                      type="button"
                      variant="outline"
                      onClick={handleRefresh}
                      disabled={isLoading}
                    >
                      {isLoading ? (
                        <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                      ) : (
                        <RefreshCcw className="h-4 w-4 mr-2" />
                      )}
                      Refresh
                    </Button>
                    <Button
                      type="submit"
                      disabled={updateExchangeRateMutation.isPending || !form.formState.isDirty}
                    >
                      {updateExchangeRateMutation.isPending ? (
                        <>
                          <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                          Updating...
                        </>
                      ) : (
                        <>
                          <Save className="h-4 w-4 mr-2" />
                          Save Changes
                        </>
                      )}
                    </Button>
                  </div>
                </div>
              </form>
            </Form>
          </CardContent>
          <CardFooter className="bg-muted/20 border-t flex justify-between text-sm text-muted-foreground">
            <span>
              Rate fluctuations can affect agent topup calculations.
            </span>
          </CardFooter>
        </Card>
      </div>
    </AppLayout>
  );
}
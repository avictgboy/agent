import { useState, useEffect } from 'react';
import { useQuery } from '@tanstack/react-query';
import { useAuth } from '@/hooks/use-auth';
import { AppLayout } from '@/layouts/app-layout';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Button } from '@/components/ui/button';
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Input } from '@/components/ui/input';
import { Calendar } from '@/components/ui/calendar';
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover";
import { CalendarIcon, Download, Search, Filter, PieChart, BarChart3, FileText } from 'lucide-react';
import { format } from 'date-fns';
import { Badge } from '@/components/ui/badge';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Separator } from '@/components/ui/separator';
import { Loader2 } from 'lucide-react';
import jsPDF from 'jspdf';
import 'jspdf-autotable';
import { apiRequest } from '@/lib/apiRequest';
import {
  Tabs,
  TabsContent,
  TabsList,
  TabsTrigger,
} from "@/components/ui/tabs";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";

export interface Transaction {
  id: string;
  originalId: number;
  type: string;
  transactionType: string;
  amount: number;
  currency: string;
  date: string;
  time: string;
  timestamp: string;
  status: string;
  statusReason?: string;
  
  // User/Agent data
  userId?: number;
  agentId?: number;
  username?: string;
  fullName?: string;
  email?: string;
  phone?: string;
  
  // Common fields that may be in different transaction types
  convertedAmount?: number;
  paymentMethod?: string;
  walletAddress?: string;
  accountNumber?: string;
  bankDetails?: string;
  transactionId?: string;
  withdrawalMethod?: string;
  reference?: string;
  playerId?: string;
  paymentCode?: string;
  commissionAmount?: number;
  recipientChannel?: string;
  recipientName?: string;
  recipientAccount?: string;
  transactionNumber?: string;
  notes?: string;
  feeAmount?: number;
  totalAmount?: number;
  
  // Processing info
  processedById?: number;
  processedAt?: string;
}

interface TransactionSummary {
  totalTransactions: number;
  totalTopups: number;
  totalWithdrawals: number;
  totalPlayerDeposits: number;
  totalPlayerWithdrawals: number;
  totalRemittances: number;
  totalAmount: number;
  totalFees: number;
  pendingTransactions: number;
  approvedTransactions: number;
  rejectedTransactions: number;
}

export default function AdminTransactionsHistoryPage() {
  const { user } = useAuth();
  const [search, setSearch] = useState('');
  const [filteredTransactions, setFilteredTransactions] = useState<Transaction[]>([]);
  const [typeFilter, setTypeFilter] = useState<string[]>([]);
  const [statusFilter, setStatusFilter] = useState<string[]>([]);
  const [startDate, setStartDate] = useState<Date | undefined>(undefined);
  const [endDate, setEndDate] = useState<Date | undefined>(undefined);
  const [isStartDateOpen, setIsStartDateOpen] = useState(false);
  const [isEndDateOpen, setIsEndDateOpen] = useState(false);
  const [agentFilter, setAgentFilter] = useState<string>('');
  const [playerFilter, setPlayerFilter] = useState<string>('');
  const [activeTab, setActiveTab] = useState<string>('all');

  // Calculate summary data from transactions
  const calculateSummary = (transactions: Transaction[]): TransactionSummary => {
    if (!transactions || transactions.length === 0) {
      return {
        totalTransactions: 0,
        totalTopups: 0,
        totalWithdrawals: 0,
        totalPlayerDeposits: 0,
        totalPlayerWithdrawals: 0,
        totalRemittances: 0,
        totalAmount: 0,
        totalFees: 0,
        pendingTransactions: 0,
        approvedTransactions: 0,
        rejectedTransactions: 0
      };
    }

    return transactions.reduce((summary, tx) => {
      // Count by type
      if (tx.transactionType === 'topup') summary.totalTopups++;
      else if (tx.transactionType === 'withdrawal') summary.totalWithdrawals++;
      else if (tx.transactionType === 'player_deposit') summary.totalPlayerDeposits++;
      else if (tx.transactionType === 'player_withdrawal') summary.totalPlayerWithdrawals++;
      else if (tx.transactionType === 'remittance') summary.totalRemittances++;

      // Count by status
      if (tx.status === 'pending') summary.pendingTransactions++;
      else if (tx.status === 'completed' || tx.status === 'approved') summary.approvedTransactions++;
      else if (tx.status === 'rejected' || tx.status === 'failed') summary.rejectedTransactions++;

      // Sum amounts - convert string to number first
      summary.totalAmount += typeof tx.amount === 'string' ? parseFloat(tx.amount) : (tx.amount || 0);
      
      // Sum fees if available
      if (tx.feeAmount) {
        summary.totalFees += typeof tx.feeAmount === 'string' ? parseFloat(tx.feeAmount) : (tx.feeAmount || 0);
      }

      return summary;
    }, {
      totalTransactions: transactions.length,
      totalTopups: 0,
      totalWithdrawals: 0,
      totalPlayerDeposits: 0,
      totalPlayerWithdrawals: 0,
      totalRemittances: 0,
      totalAmount: 0,
      totalFees: 0,
      pendingTransactions: 0,
      approvedTransactions: 0,
      rejectedTransactions: 0
    });
  };

  // Prepare query parameters based on filters
  const getQueryParams = () => {
    const params = new URLSearchParams();
    
    if (startDate) {
      params.append('startDate', startDate.toISOString());
    }
    
    if (endDate) {
      params.append('endDate', endDate.toISOString());
    }
    
    typeFilter.forEach(type => {
      params.append('type', type);
    });
    
    statusFilter.forEach(status => {
      params.append('status', status);
    });
    
    if (search) {
      params.append('search', search);
    }
    
    if (agentFilter) {
      params.append('agentId', agentFilter);
    }
    
    if (playerFilter) {
      params.append('playerId', playerFilter);
    }
    
    return params.toString();
  };

  // Define agent interface for better type safety
  interface Agent {
    id: number;
    username: string;
    role: string;
  }

  // Fetch all agents for the dropdown
  const { data: agents = [] } = useQuery<Agent[]>({
    queryKey: ['/api/admin/users'],
    queryFn: async () => {
      const response = await apiRequest<Agent[]>('/api/admin/users');
      return Array.isArray(response) ? response : [];
    }
  });

  // Fetch transactions with filters
  const { data: transactions, isLoading, refetch } = useQuery<Transaction[]>({
    queryKey: ['/api/admin/all-transactions', getQueryParams()],
    queryFn: async () => {
      const queryString = getQueryParams();
      const url = `/api/admin/all-transactions${queryString ? `?${queryString}` : ''}`;
      return apiRequest<Transaction[]>(url);
    }
  });

  // Apply client-side filtering for UI state
  useEffect(() => {
    if (!transactions) return;
    
    // For "All" tab, use all transactions
    if (activeTab === 'all') {
      setFilteredTransactions(transactions);
      return;
    }
    
    // Filter based on active tab
    const filtered = transactions.filter(tx => {
      if (activeTab === 'pending') return tx.status === 'pending';
      if (activeTab === 'approved') return tx.status === 'completed' || tx.status === 'approved';
      if (activeTab === 'rejected') return tx.status === 'rejected' || tx.status === 'failed';
      
      // Filter by transaction type
      if (activeTab === 'topups') return tx.transactionType === 'topup';
      if (activeTab === 'withdrawals') return tx.transactionType === 'withdrawal';
      if (activeTab === 'player') return tx.transactionType === 'player_deposit' || tx.transactionType === 'player_withdrawal';
      if (activeTab === 'remittance') return tx.transactionType === 'remittance';
      
      return true;
    });
    
    setFilteredTransactions(filtered);
  }, [transactions, activeTab]);

  // Handle filter changes
  const handleTypeFilterChange = (value: string) => {
    if (value === "all") {
      setTypeFilter([]);
    } else {
      setTypeFilter(prev => {
        if (prev.includes(value)) {
          return prev.filter(t => t !== value);
        } else {
          return [...prev, value];
        }
      });
    }
  };

  const handleStatusFilterChange = (value: string) => {
    if (value === "all") {
      setStatusFilter([]);
    } else {
      setStatusFilter(prev => {
        if (prev.includes(value)) {
          return prev.filter(s => s !== value);
        } else {
          return [...prev, value];
        }
      });
    }
  };

  const handleSearch = () => {
    refetch();
  };

  const handleClearFilters = () => {
    setSearch('');
    setTypeFilter([]);
    setStatusFilter([]);
    setStartDate(undefined);
    setEndDate(undefined);
    setAgentFilter('');
    setPlayerFilter('');
    refetch();
  };

  // Export transactions to CSV
  const exportToCSV = () => {
    if (!filteredTransactions.length) return;

    const headers = [
      'Transaction ID', 
      'Type', 
      'Amount', 
      'Currency', 
      'Date', 
      'Time', 
      'Status',
      'Agent/User',
      'Email',
      'Phone'
    ];

    const rows = filteredTransactions.map(tx => [
      tx.id,
      tx.type,
      typeof tx.amount === 'string' ? tx.amount : String(tx.amount),
      tx.currency,
      tx.date,
      tx.time,
      tx.status,
      tx.username || '',
      tx.email || '',
      tx.phone || ''
    ]);

    const csvContent = [
      headers.join(','),
      ...rows.map(row => row.join(','))
    ].join('\\n');

    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.setAttribute('href', url);
    link.setAttribute('download', `transactions_${format(new Date(), 'yyyy-MM-dd')}.csv`);
    link.style.visibility = 'hidden';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };
  
  // Export transactions to PDF
  const exportToPDF = () => {
    if (!filteredTransactions.length) return;

    const doc = new jsPDF();
    
    // Add title
    doc.setFontSize(18);
    doc.text('Transaction History Report', 14, 22);
    
    // Add date and admin info
    doc.setFontSize(11);
    doc.text(`Generated on: ${format(new Date(), 'PPP')}`, 14, 30);
    
    if (user) {
      doc.text(`Generated by: ${user.username} (Admin)`, 14, 38);
    }
    
    // Add summary information
    doc.setFontSize(12);
    doc.text('Summary:', 14, 46);
    doc.setFontSize(10);
    doc.text(`Total Transactions: ${summary.totalTransactions}`, 20, 54);
    doc.text(`Total Amount: ${summary.totalAmount.toFixed(2)} BDT`, 20, 60);
    doc.text(`Pending: ${summary.pendingTransactions} | Approved: ${summary.approvedTransactions} | Rejected: ${summary.rejectedTransactions}`, 20, 66);
    
    // Add table
    const headers = [
      'ID', 
      'Type', 
      'Amount',  
      'Date', 
      'Status',
      'Agent'
    ];

    const rows = filteredTransactions.map(tx => [
      tx.id,
      tx.transactionType,
      `${tx.currency} ${typeof tx.amount === 'string' ? tx.amount : String(tx.amount)}`,
      tx.date,
      tx.status,
      tx.username || '-'
    ]);

    // @ts-ignore - jspdf-autotable types
    doc.autoTable({
      head: [headers],
      body: rows,
      startY: 75,
      styles: { fontSize: 8 },
      headStyles: { fillColor: [66, 139, 202] },
      alternateRowStyles: { fillColor: [241, 245, 249] },
      margin: { top: 75 }
    });
    
    doc.save(`transaction_report_${format(new Date(), 'yyyy-MM-dd')}.pdf`);
  };

  // Helper to render status badge with appropriate color
  const getStatusBadge = (status: string) => {
    switch (status.toLowerCase()) {
      case 'pending':
        return <Badge variant="outline" className="bg-yellow-100 text-yellow-800 border-yellow-300">Pending</Badge>;
      case 'completed':
      case 'approved':
        return <Badge variant="outline" className="bg-green-100 text-green-800 border-green-300">Approved</Badge>;
      case 'failed':
      case 'rejected':
        return <Badge variant="outline" className="bg-red-100 text-red-800 border-red-300">Rejected</Badge>;
      default:
        return <Badge variant="outline">{status}</Badge>;
    }
  };

  // Helper to get user/agent details
  const getUserDetails = (transaction: Transaction) => {
    if (!transaction.username) return null;
    
    return (
      <>
        <div className="font-medium">{transaction.username}</div>
        {transaction.fullName && <div className="text-sm text-gray-500">{transaction.fullName}</div>}
        {transaction.email && <div className="text-sm text-gray-500">{transaction.email}</div>}
      </>
    );
  };

  // Get transaction details based on type
  const getTransactionDetails = (transaction: Transaction) => {
    switch (transaction.transactionType) {
      case 'topup':
        return (
          <>
            <p className="text-sm text-gray-500">Payment Method: {transaction.paymentMethod}</p>
            {transaction.transactionId && <p className="text-sm text-gray-500">Transaction ID: {transaction.transactionId}</p>}
            {transaction.convertedAmount && <p className="text-sm text-gray-500">Converted: {transaction.convertedAmount} BDT</p>}
          </>
        );
      case 'withdrawal':
        return (
          <>
            <p className="text-sm text-gray-500">Method: {transaction.withdrawalMethod}</p>
            {transaction.reference && <p className="text-sm text-gray-500">Reference: {transaction.reference}</p>}
          </>
        );
      case 'player_deposit':
      case 'player_withdrawal':
        return (
          <>
            <p className="text-sm text-gray-500">Player ID: {transaction.playerId}</p>
            {transaction.paymentCode && <p className="text-sm text-gray-500">Payment Code: {transaction.paymentCode}</p>}
            {transaction.commissionAmount && <p className="text-sm text-gray-500">Commission: {transaction.commissionAmount} BDT</p>}
          </>
        );
      case 'remittance':
        return (
          <>
            <p className="text-sm text-gray-500">Channel: {transaction.recipientChannel}</p>
            <p className="text-sm text-gray-500">Recipient: {transaction.recipientName}</p>
            <p className="text-sm text-gray-500">Account: {transaction.recipientAccount}</p>
            {transaction.feeAmount && <p className="text-sm text-gray-500">Fee: {transaction.feeAmount} BDT</p>}
            {transaction.transactionNumber && <p className="text-sm text-gray-500">Transaction #: {transaction.transactionNumber}</p>}
          </>
        );
      default:
        return null;
    }
  };

  // Calculate summary statistics
  const summary = calculateSummary(transactions || []);

  return (
    <AppLayout>
      <div className="container mx-auto p-4">
        <h1 className="text-2xl font-bold mb-6">Transaction Management</h1>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium">Total Transactions</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{summary.totalTransactions}</div>
              <p className="text-xs text-muted-foreground">
                Value: {summary.totalAmount.toFixed(2)} BDT
              </p>
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium">Transaction Status</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex items-center justify-between text-sm">
                <div>
                  <div className="font-medium">Pending</div>
                  <div className="text-muted-foreground">{summary.pendingTransactions}</div>
                </div>
                <div>
                  <div className="font-medium">Approved</div>
                  <div className="text-muted-foreground">{summary.approvedTransactions}</div>
                </div>
                <div>
                  <div className="font-medium">Rejected</div>
                  <div className="text-muted-foreground">{summary.rejectedTransactions}</div>
                </div>
              </div>
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium">Transaction Types</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-2 gap-2 text-xs">
                <div>
                  <div>Top-ups: {summary.totalTopups}</div>
                  <div>Withdrawals: {summary.totalWithdrawals}</div>
                </div>
                <div>
                  <div>Player Deposits: {summary.totalPlayerDeposits}</div>
                  <div>Player Withdrawals: {summary.totalPlayerWithdrawals}</div>
                  <div>Remittances: {summary.totalRemittances}</div>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
        
        <Card className="mb-8">
          <CardHeader>
            <CardTitle>Filters</CardTitle>
            <CardDescription>Filter transaction history</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-4">
              <div>
                <label className="text-sm font-medium mb-1 block">Transaction Type</label>
                <Select onValueChange={handleTypeFilterChange}>
                  <SelectTrigger>
                    <SelectValue placeholder="All Types" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Types</SelectItem>
                    <SelectItem value="topup">USDT Top-up</SelectItem>
                    <SelectItem value="withdrawal">Withdrawal</SelectItem>
                    <SelectItem value="player_deposit">Player Deposit</SelectItem>
                    <SelectItem value="player_withdrawal">Player Withdrawal</SelectItem>
                    <SelectItem value="remittance">Remittance</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              
              <div>
                <label className="text-sm font-medium mb-1 block">Status</label>
                <Select onValueChange={handleStatusFilterChange}>
                  <SelectTrigger>
                    <SelectValue placeholder="All Statuses" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Statuses</SelectItem>
                    <SelectItem value="pending">Pending</SelectItem>
                    <SelectItem value="completed">Completed</SelectItem>
                    <SelectItem value="approved">Approved</SelectItem>
                    <SelectItem value="rejected">Rejected</SelectItem>
                    <SelectItem value="failed">Failed</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              
              <div>
                <label className="text-sm font-medium mb-1 block">Search</label>
                <div className="flex">
                  <Input 
                    placeholder="Search transactions..." 
                    value={search}
                    onChange={(e) => setSearch(e.target.value)}
                    className="w-full"
                  />
                </div>
              </div>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div>
                <label className="text-sm font-medium mb-1 block">Agent/User</label>
                <Select 
                  onValueChange={(value) => {
                    setAgentFilter(value === "all" ? "" : value);
                  }}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="All Agents" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Agents</SelectItem>
                    {agents && agents.map((agent: any) => (
                      <SelectItem key={agent.id} value={agent.id.toString()}>
                        {agent.username} ({agent.role})
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              
              <div>
                <label className="text-sm font-medium mb-1 block">Player ID</label>
                <Input 
                  placeholder="Enter player ID" 
                  value={playerFilter}
                  onChange={(e) => setPlayerFilter(e.target.value)}
                  className="w-full"
                />
              </div>
              
              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="text-sm font-medium mb-1 block">Start Date</label>
                  <Popover open={isStartDateOpen} onOpenChange={setIsStartDateOpen}>
                    <PopoverTrigger asChild>
                      <Button
                        variant="outline"
                        className="w-full justify-start text-left"
                      >
                        <CalendarIcon className="mr-2 h-4 w-4" />
                        {startDate ? format(startDate, 'PPP') : <span>Pick a date</span>}
                      </Button>
                    </PopoverTrigger>
                    <PopoverContent className="w-auto p-0">
                      <Calendar
                        mode="single"
                        selected={startDate}
                        onSelect={(date) => {
                          setStartDate(date);
                          setIsStartDateOpen(false);
                        }}
                        initialFocus
                      />
                    </PopoverContent>
                  </Popover>
                </div>
                
                <div>
                  <label className="text-sm font-medium mb-1 block">End Date</label>
                  <Popover open={isEndDateOpen} onOpenChange={setIsEndDateOpen}>
                    <PopoverTrigger asChild>
                      <Button
                        variant="outline"
                        className="w-full justify-start text-left"
                      >
                        <CalendarIcon className="mr-2 h-4 w-4" />
                        {endDate ? format(endDate, 'PPP') : <span>Pick a date</span>}
                      </Button>
                    </PopoverTrigger>
                    <PopoverContent className="w-auto p-0">
                      <Calendar
                        mode="single"
                        selected={endDate}
                        onSelect={(date) => {
                          setEndDate(date);
                          setIsEndDateOpen(false);
                        }}
                        initialFocus
                      />
                    </PopoverContent>
                  </Popover>
                </div>
              </div>
            </div>
          </CardContent>
          <CardFooter className="flex justify-between">
            <Button variant="outline" onClick={handleClearFilters}>
              Clear Filters
            </Button>
            <div className="flex gap-2 flex-wrap">
              <Button onClick={handleSearch} className="flex items-center gap-2">
                <Search className="h-4 w-4" />
                <span>Search</span>
              </Button>
              <Button onClick={exportToCSV} variant="outline" className="flex items-center gap-2">
                <Download className="h-4 w-4" />
                <span>CSV</span>
              </Button>
              <Button onClick={exportToPDF} variant="outline" className="flex items-center gap-2">
                <FileText className="h-4 w-4" />
                <span>PDF</span>
              </Button>
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button variant="outline">
                    <Filter className="h-4 w-4 mr-2" />
                    <span>Reports</span>
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent>
                  <DropdownMenuItem onClick={() => exportToCSV()}>
                    <Download className="h-4 w-4 mr-2" />
                    <span>Export as CSV</span>
                  </DropdownMenuItem>
                  <DropdownMenuItem onClick={() => exportToPDF()}>
                    <FileText className="h-4 w-4 mr-2" />
                    <span>Export as PDF</span>
                  </DropdownMenuItem>
                  <DropdownMenuItem>
                    <BarChart3 className="h-4 w-4 mr-2" />
                    <span>Transaction Report</span>
                  </DropdownMenuItem>
                  <DropdownMenuItem>
                    <PieChart className="h-4 w-4 mr-2" />
                    <span>Fee Report</span>
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            </div>
          </CardFooter>
        </Card>
        
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center justify-between">
              <span>Transaction History</span>
              <Tabs defaultValue="all" onValueChange={setActiveTab}>
                <TabsList>
                  <TabsTrigger value="all">All</TabsTrigger>
                  <TabsTrigger value="pending">Pending</TabsTrigger>
                  <TabsTrigger value="topups">Top-ups</TabsTrigger>
                  <TabsTrigger value="withdrawals">Withdrawals</TabsTrigger>
                  <TabsTrigger value="player">Player</TabsTrigger>
                  <TabsTrigger value="remittance">Remittance</TabsTrigger>
                </TabsList>
              </Tabs>
            </CardTitle>
            <CardDescription>
              {activeTab === 'all' ? 'All transactions' : 
               activeTab === 'pending' ? 'Pending transactions' :
               activeTab === 'topups' ? 'USDT Top-ups' :
               activeTab === 'withdrawals' ? 'Withdrawals' :
               activeTab === 'player' ? 'Player Transactions' :
               'Remittance Transactions'}
              
              {typeFilter.length > 0 && (
                <span className="ml-2">
                  (Filtered by {typeFilter.join(', ')})
                </span>
              )}
              {statusFilter.length > 0 && (
                <span className="ml-2">
                  (Status: {statusFilter.join(', ')})
                </span>
              )}
            </CardDescription>
          </CardHeader>
          <ScrollArea className="h-[600px]">
            <CardContent>
              {isLoading ? (
                <div className="flex justify-center items-center py-10">
                  <Loader2 className="h-8 w-8 animate-spin text-primary" />
                </div>
              ) : filteredTransactions && filteredTransactions.length > 0 ? (
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Date & Time</TableHead>
                      <TableHead>Transaction</TableHead>
                      <TableHead>Agent/User</TableHead>
                      <TableHead>Amount</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead>Details</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {filteredTransactions.map((transaction) => (
                      <TableRow key={transaction.id}>
                        <TableCell>
                          <div className="font-medium">{transaction.date}</div>
                          <div className="text-sm text-gray-500">{transaction.time}</div>
                        </TableCell>
                        <TableCell>
                          <div className="font-medium">{transaction.type}</div>
                          <div className="text-sm text-gray-500">ID: {transaction.id}</div>
                        </TableCell>
                        <TableCell>
                          {getUserDetails(transaction)}
                        </TableCell>
                        <TableCell>
                          <div className="font-medium">{transaction.amount} {transaction.currency}</div>
                          {transaction.totalAmount && String(transaction.totalAmount) !== String(transaction.amount) && (
                            <div className="text-sm text-gray-500">
                              Total: {transaction.totalAmount} {transaction.currency}
                            </div>
                          )}
                          {transaction.feeAmount && (
                            <div className="text-sm text-gray-500">
                              Fee: {transaction.feeAmount} {transaction.currency}
                            </div>
                          )}
                        </TableCell>
                        <TableCell>
                          {getStatusBadge(transaction.status)}
                          {transaction.statusReason && (
                            <div className="text-xs text-gray-500 mt-1">{transaction.statusReason}</div>
                          )}
                          {transaction.processedAt && (
                            <div className="text-xs text-gray-500 mt-1">
                              Processed: {new Date(transaction.processedAt).toLocaleDateString()}
                            </div>
                          )}
                        </TableCell>
                        <TableCell>
                          {getTransactionDetails(transaction)}
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              ) : (
                <div className="text-center py-10">
                  <p>No transactions found</p>
                  <p className="text-sm text-gray-500 mt-2">
                    Try adjusting your filters or search query
                  </p>
                </div>
              )}
            </CardContent>
          </ScrollArea>
        </Card>
      </div>
    </AppLayout>
  );
}
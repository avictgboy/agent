import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Link } from "wouter";
import { 
  User, 
  Wallet, 
  MessageSquare,
  Eye, 
  ChevronRight, 
  Plus,
  ArrowUp,
  ArrowDown,
  CheckCircle,
  Clock,
  XCircle
} from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { getQueryFn } from "@/lib/queryClient";
import { useAuth } from "@/hooks/use-auth";
import { useCurrency } from "@/hooks/use-currency";
import { AppLayout } from "@/layouts/app-layout";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";

interface Transaction {
  id: string;
  originalId?: number;  // Added for compatibility with prefixed IDs
  type: string;
  amount: number;
  currency: string;
  convertedAmount?: number;
  date: string;
  time: string;
  status: "pending" | "completed" | "failed" | "approved" | "rejected";
  statusReason?: string;
}

export default function DashboardPage() {
  // Removed Add Funds modal state
  const [selectedTransaction, setSelectedTransaction] = useState<Transaction | null>(null);
  const [isTransactionDetailsOpen, setIsTransactionDetailsOpen] = useState(false);
  const { user } = useAuth();
  const { rates } = useCurrency();

  // Fetch transactions
  const { data: transactions = [] } = useQuery<Transaction[]>({
    queryKey: ["/api/transactions"],
    queryFn: getQueryFn({ on401: "throw" }),
  });

  // Fetch commissions
  const { data: commissions } = useQuery({
    queryKey: ["/api/commissions"],
    queryFn: getQueryFn({ on401: "throw" }),
  });

  return (
    <AppLayout>
      {/* Balance Cards Section */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4 mb-6">
        {/* BDT Balance Card */}
        <Card className="relative overflow-hidden">
          <div className="absolute top-0 right-0 w-16 h-16 bg-primary-500 opacity-10 rounded-bl-full"></div>
          <CardContent className="p-5">
            <h3 className="text-gray-500 text-sm font-medium mb-1">Available Balance</h3>
            <div className="flex items-baseline">
              <span className="text-2xl font-bold font-mono">
                ৳ {user?.balance?.toLocaleString() || "0"}
              </span>
              <span className="text-sm text-gray-500 ml-1">BDT</span>
            </div>
            <div className="mt-4 flex">
              <Button
                size="sm"
                className="flex items-center"
                onClick={() => window.location.href = "/add-funds"}
              >
                <Plus className="h-4 w-4 mr-1" />
                Add Funds
              </Button>
              <div className="text-xs text-gray-500 flex items-center ml-3">
                <span className="mr-1">USDT/BDT:</span>
                <span className="font-semibold font-mono">{rates.usdtToBdt.toFixed(2)}</span>
              </div>
            </div>
          </CardContent>
        </Card>
        
        {/* Commissions Card */}
        <Card className="relative overflow-hidden">
          <div className="absolute top-0 right-0 w-16 h-16 bg-green-500 opacity-10 rounded-bl-full"></div>
          <CardContent className="p-5">
            <h3 className="text-gray-500 text-sm font-medium mb-1">Commissions</h3>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <p className="text-xs text-gray-500">Pending</p>
                <p className="text-lg font-bold font-mono text-gray-700">
                  ৳ {commissions?.pending?.toLocaleString() || "0"}
                </p>
              </div>
              <div>
                <p className="text-xs text-gray-500">Next Payout</p>
                <p className="text-sm font-medium text-gray-700">
                  {commissions?.nextPayout || "N/A"}
                </p>
              </div>
            </div>
            <div className="mt-4">
              <Link href="/commissions" className="text-primary-600 hover:text-primary-700 text-sm font-medium flex items-center">
                View Commission History
                <ChevronRight className="h-4 w-4 ml-1" />
              </Link>
            </div>
          </CardContent>
        </Card>
        
        {/* Support Card */}
        <Card className="relative overflow-hidden">
          <div className="absolute top-0 right-0 w-16 h-16 bg-blue-500 opacity-10 rounded-bl-full"></div>
          <CardContent className="p-5">
            <h3 className="text-gray-500 text-sm font-medium mb-1">Support</h3>
            <div className="mt-2">
              <p className="text-sm text-gray-700">
                Need help with your transactions or account? Our support team is available 24/7.
              </p>
            </div>
            <div className="mt-4">
              <Link href="/support">
                <Button size="sm" className="w-full">
                  <MessageSquare className="h-4 w-4 mr-2" />
                  Contact Support
                </Button>
              </Link>
            </div>
          </CardContent>
        </Card>
      </div>
      
      {/* Quick Actions */}
      <div className="mb-8">
        <h2 className="text-lg font-semibold text-gray-800 mb-4">Quick Actions</h2>
        <div className="grid grid-cols-1 sm:grid-cols-3 md:grid-cols-5 gap-3">
          <Link href="/player-management" className="bg-white hover:bg-gray-50 rounded-xl shadow-sm p-4 flex flex-col items-center justify-center text-center">
            <User className="h-8 w-8 text-primary-500 mb-2" />
            <span className="text-sm font-medium text-gray-800">Player Deposit</span>
          </Link>
          
          <Link href="/player-management?tab=withdrawal" className="bg-white hover:bg-gray-50 rounded-xl shadow-sm p-4 flex flex-col items-center justify-center text-center">
            <Wallet className="h-8 w-8 text-primary-500 mb-2" />
            <span className="text-sm font-medium text-gray-800">Player Withdrawal</span>
          </Link>
          
          <Link href="/transactions" className="bg-white hover:bg-gray-50 rounded-xl shadow-sm p-4 flex flex-col items-center justify-center text-center">
            <Eye className="h-8 w-8 text-primary-500 mb-2" />
            <span className="text-sm font-medium text-gray-800">Transaction History</span>
          </Link>
          
          <Link href="/remittance" className="bg-white hover:bg-gray-50 rounded-xl shadow-sm p-4 flex flex-col items-center justify-center text-center">
            <ArrowUp className="h-8 w-8 text-primary-500 mb-2" />
            <span className="text-sm font-medium text-gray-800">Send Remittance</span>
          </Link>
          
          <Link href="/support" className="bg-white hover:bg-gray-50 rounded-xl shadow-sm p-4 flex flex-col items-center justify-center text-center">
            <MessageSquare className="h-8 w-8 text-primary-500 mb-2" />
            <span className="text-sm font-medium text-gray-800">Contact Support</span>
          </Link>
        </div>
      </div>
      
      {/* Recent Transactions */}
      <div className="mb-8">
        <div className="flex justify-between items-center mb-4">
          <h2 className="text-lg font-semibold text-gray-800">Recent Transactions</h2>
          <Link href="/transactions" className="text-primary-600 hover:text-primary-700 text-sm font-medium">
            View All
          </Link>
        </div>
        
        <Card>
          <div className="overflow-x-auto">
            <table className="min-w-full divide-y divide-gray-200">
              <thead className="bg-gray-50">
                <tr>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Type</th>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Amount</th>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Date</th>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Status</th>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Details</th>
                </tr>
              </thead>
              <tbody className="bg-white divide-y divide-gray-200">
                {transactions.length === 0 ? (
                  <tr>
                    <td colSpan={5} className="px-6 py-4 text-center text-sm text-gray-500">
                      No transactions found
                    </td>
                  </tr>
                ) : (
                  transactions.map((transaction) => (
                    <tr key={transaction.id}>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <div className="flex items-center">
                          <div className={`p-1.5 rounded-lg mr-3 ${
                            transaction.type === "USDT Top-up" 
                              ? "bg-primary-100 text-primary-600"
                              : transaction.type === "Player Deposit"
                              ? "bg-red-100 text-red-600"
                              : "bg-green-100 text-green-600"
                          }`}>
                            {transaction.type === "USDT Top-up" && <Plus className="h-5 w-5" />}
                            {transaction.type === "Player Deposit" && <ArrowUp className="h-5 w-5" />}
                            {transaction.type === "Player Withdrawal" && <ArrowDown className="h-5 w-5" />}
                          </div>
                          <span className="text-sm font-medium text-gray-900">{transaction.type}</span>
                        </div>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <div className="text-sm font-medium font-mono text-gray-900">
                          <span>{transaction.currency}</span> {transaction.amount.toLocaleString()}
                        </div>
                        {transaction.convertedAmount && (
                          <div className="text-xs text-gray-500">
                            ৳ {transaction.convertedAmount.toLocaleString()}
                          </div>
                        )}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <div className="text-sm text-gray-900">{transaction.date}</div>
                        <div className="text-xs text-gray-500">{transaction.time}</div>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <span className={`px-2 py-1 text-xs font-medium rounded-full ${
                          transaction.status === "completed" || transaction.status === "approved"
                            ? "bg-green-100 text-green-800"
                            : transaction.status === "pending"
                            ? "bg-yellow-100 text-yellow-800"
                            : "bg-red-100 text-red-800"
                        }`}>
                          {transaction.status.charAt(0).toUpperCase() + transaction.status.slice(1)}
                        </span>
                        {transaction.statusReason && (
                          <div className="text-xs text-gray-500 mt-1 max-w-[200px] truncate" title={transaction.statusReason}>
                            {transaction.statusReason}
                          </div>
                        )}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                        <Button 
                          variant="ghost" 
                          size="sm" 
                          className="text-primary-600 hover:text-primary-700"
                          title="View Details"
                          onClick={() => {
                            setSelectedTransaction(transaction);
                            setIsTransactionDetailsOpen(true);
                          }}
                        >
                          <Eye className="h-5 w-5" />
                        </Button>
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </Card>
      </div>

      {/* Transaction Details Modal */}
      <Dialog 
        open={isTransactionDetailsOpen} 
        onOpenChange={setIsTransactionDetailsOpen}
      >
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Transaction Details</DialogTitle>
            <DialogDescription>
              Detailed information about your transaction
            </DialogDescription>
          </DialogHeader>
          
          {selectedTransaction && (
            <div className="space-y-4 py-3">
              <div className="flex items-center space-x-2">
                <div className={`p-2 rounded-full ${
                  selectedTransaction.status === "completed" || selectedTransaction.status === "approved"
                    ? "bg-green-100 text-green-700"
                    : selectedTransaction.status === "pending"
                    ? "bg-yellow-100 text-yellow-700" 
                    : "bg-red-100 text-red-700"
                }`}>
                  {selectedTransaction.status === "completed" || selectedTransaction.status === "approved" ? (
                    <CheckCircle className="h-6 w-6" />
                  ) : selectedTransaction.status === "pending" ? (
                    <Clock className="h-6 w-6" />
                  ) : (
                    <XCircle className="h-6 w-6" />
                  )}
                </div>
                <div>
                  <h3 className="text-lg font-semibold">{selectedTransaction.type}</h3>
                  <p className="text-sm text-gray-500">ID: {selectedTransaction.originalId || selectedTransaction.id}</p>
                </div>
              </div>
              
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <p className="text-sm font-medium text-gray-500">Amount</p>
                  <p className="font-mono text-base">{selectedTransaction.currency} {selectedTransaction.amount.toLocaleString()}</p>
                  {selectedTransaction.convertedAmount && (
                    <p className="text-sm text-gray-500 font-mono">
                      ৳ {selectedTransaction.convertedAmount.toLocaleString()}
                    </p>
                  )}
                </div>
                <div>
                  <p className="text-sm font-medium text-gray-500">Date & Time</p>
                  <p className="text-base">{selectedTransaction.date}</p>
                  <p className="text-sm text-gray-500">{selectedTransaction.time}</p>
                </div>
              </div>
              
              <div>
                <p className="text-sm font-medium text-gray-500 mb-1">Status</p>
                <div className="flex items-center">
                  <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-sm font-medium ${
                    selectedTransaction.status === "completed" || selectedTransaction.status === "approved"
                      ? "bg-green-100 text-green-800" 
                      : selectedTransaction.status === "pending"
                      ? "bg-yellow-100 text-yellow-800"
                      : "bg-red-100 text-red-800"
                  }`}>
                    {selectedTransaction.status.charAt(0).toUpperCase() + selectedTransaction.status.slice(1)}
                  </span>
                </div>
              </div>
              
              {selectedTransaction.statusReason && (
                <div className="border-t pt-3">
                  <p className="text-sm font-medium text-gray-500 mb-1">Status Reason</p>
                  <div className="bg-gray-50 p-3 rounded-md text-sm">
                    {selectedTransaction.statusReason}
                  </div>
                </div>
              )}
            </div>
          )}
          
          <DialogFooter className="sm:justify-center">
            <Button onClick={() => setIsTransactionDetailsOpen(false)}>Close</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </AppLayout>
  );
}

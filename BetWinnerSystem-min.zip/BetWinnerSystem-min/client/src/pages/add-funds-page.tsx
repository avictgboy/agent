import { useState } from "react";
import { useAuth } from "@/hooks/use-auth";
import { AppLayout } from "@/layouts/app-layout";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { AddFundsForm } from "@/components/add-funds-form";
import { useQuery } from "@tanstack/react-query";
import { getQueryFn } from "@/lib/queryClient";
import { Check, Clock, CircleDollarSign, PiggyBank } from "lucide-react";

interface Transaction {
  id: string;
  type: string;
  amount: number;
  currency: string;
  status: string;
  createdAt: string;
  paymentMethod: string;
}

export default function AddFundsPage() {
  const { user } = useAuth();
  const [showForm, setShowForm] = useState(true);

  // Fetch recent topup transactions
  const { data: transactions = [] } = useQuery<Transaction[]>({
    queryKey: ["/api/transactions/topup"],
    queryFn: getQueryFn({ on401: "throw" }),
  });

  return (
    <AppLayout>
      <div className="container mx-auto py-6 space-y-8">
        <div className="flex flex-col space-y-4">
          <h1 className="text-2xl sm:text-3xl font-bold tracking-tight">Add Funds</h1>
          <p className="text-muted-foreground">
            Add funds to your agent account to make transactions with your players.
          </p>
        </div>

        <Tabs defaultValue="add-funds" className="w-full">
          <TabsList className="mb-4">
            <TabsTrigger value="add-funds">Add Funds</TabsTrigger>
            <TabsTrigger value="history">Transaction History</TabsTrigger>
          </TabsList>
          
          <TabsContent value="add-funds" className="space-y-6">
            {showForm ? (
              <Card>
                <CardHeader>
                  <CardTitle>Add Funds to Your Account</CardTitle>
                  <CardDescription>
                    Choose your preferred payment method to add funds to your account.
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <AddFundsForm onSuccess={() => setShowForm(false)} />
                </CardContent>
              </Card>
            ) : (
              <Card>
                <CardHeader>
                  <CardTitle>Payment Request Submitted</CardTitle>
                  <CardDescription>
                    Your payment request has been successfully submitted.
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-6">
                  <div className="p-6 flex flex-col items-center justify-center space-y-4 bg-green-50 rounded-lg">
                    <div className="h-12 w-12 rounded-full bg-green-100 flex items-center justify-center">
                      <Check className="h-6 w-6 text-green-600" />
                    </div>
                    <h3 className="text-lg font-medium text-green-800">Request Received</h3>
                    <p className="text-center text-green-700">
                      Our team will process your payment request soon. You can check the status in the Transaction History tab.
                    </p>
                  </div>
                  
                  <button
                    onClick={() => setShowForm(true)}
                    className="w-full py-2 px-4 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-primary hover:bg-primary/90 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary"
                  >
                    Add More Funds
                  </button>
                </CardContent>
              </Card>
            )}
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Current Balance</CardTitle>
                  <PiggyBank className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">
                    {user?.balance ? parseFloat(user.balance.toString()).toFixed(2) : "0.00"} BDT
                  </div>
                  <p className="text-xs text-muted-foreground mt-1">
                    Available for transactions
                  </p>
                </CardContent>
              </Card>
              
              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Pending Deposits</CardTitle>
                  <Clock className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">
                    {transactions
                      .filter(t => t.status === "pending")
                      .reduce((total, t) => total + parseFloat(t.amount.toString()), 0)
                      .toFixed(2)} {transactions[0]?.currency || "BDT"}
                  </div>
                  <p className="text-xs text-muted-foreground mt-1">
                    Waiting for approval
                  </p>
                </CardContent>
              </Card>
              
              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Total Deposits</CardTitle>
                  <CircleDollarSign className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">
                    {transactions
                      .filter(t => t.status === "approved")
                      .reduce((total, t) => total + parseFloat(t.amount.toString()), 0)
                      .toFixed(2)} {transactions[0]?.currency || "BDT"}
                  </div>
                  <p className="text-xs text-muted-foreground mt-1">
                    Lifetime deposits
                  </p>
                </CardContent>
              </Card>
            </div>
          </TabsContent>
          
          <TabsContent value="history">
            <Card>
              <CardHeader>
                <CardTitle>Transaction History</CardTitle>
                <CardDescription>
                  View all your deposit transactions and their status.
                </CardDescription>
              </CardHeader>
              <CardContent>
                {transactions.length === 0 ? (
                  <div className="text-center py-8 text-muted-foreground">
                    No transactions found.
                  </div>
                ) : (
                  <div className="overflow-x-auto">
                    <table className="w-full text-sm">
                      <thead>
                        <tr className="border-b">
                          <th className="text-left py-3 px-4 font-medium">ID</th>
                          <th className="text-left py-3 px-4 font-medium">Date</th>
                          <th className="text-left py-3 px-4 font-medium">Amount</th>
                          <th className="text-left py-3 px-4 font-medium">Method</th>
                          <th className="text-left py-3 px-4 font-medium">Status</th>
                        </tr>
                      </thead>
                      <tbody>
                        {transactions.map((transaction) => (
                          <tr key={transaction.id} className="border-b hover:bg-muted/50">
                            <td className="py-3 px-4">{transaction.id}</td>
                            <td className="py-3 px-4">
                              {new Date(transaction.createdAt).toLocaleDateString()}
                            </td>
                            <td className="py-3 px-4">
                              {parseFloat(transaction.amount.toString()).toFixed(2)} {transaction.currency}
                            </td>
                            <td className="py-3 px-4">
                              {transaction.paymentMethod.replace('_', ' ').replace(/\b\w/g, l => l.toUpperCase())}
                            </td>
                            <td className="py-3 px-4">
                              <span
                                className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${
                                  transaction.status === "approved"
                                    ? "bg-green-100 text-green-800"
                                    : transaction.status === "rejected"
                                    ? "bg-red-100 text-red-800"
                                    : "bg-yellow-100 text-yellow-800"
                                }`}
                              >
                                {transaction.status.charAt(0).toUpperCase() + transaction.status.slice(1)}
                              </span>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </AppLayout>
  );
}
import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Award, Shield, Users, CreditCard, Clock, TrendingUp, AlertTriangle } from "lucide-react";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { useAuth } from "@/hooks/use-auth";
import { useToast } from "@/hooks/use-toast";

// Define achievement difficulty colors
const difficultyColors = {
  bronze: "text-amber-600 bg-amber-100 border-amber-200",
  silver: "text-slate-600 bg-slate-100 border-slate-200",
  gold: "text-yellow-600 bg-yellow-100 border-yellow-200",
  platinum: "text-emerald-600 bg-emerald-100 border-emerald-200",
  diamond: "text-blue-600 bg-blue-100 border-blue-200"
};

// Define achievement category icons
const categoryIcons = {
  transaction_volume: TrendingUp,
  player_acquisition: Users,
  retention: Clock,
  consistency: Shield,
  special: Award
};

// Achievement types
interface Achievement {
  id: number;
  title: string;
  description: string;
  category: 'transaction_volume' | 'player_acquisition' | 'retention' | 'consistency' | 'special';
  difficulty: 'bronze' | 'silver' | 'gold' | 'platinum' | 'diamond';
  pointsAwarded: number;
  icon: string;
  requirement: Record<string, any>;
  isActive: boolean;
  createdAt: string;
  updatedAt: string;
}

interface UserAchievement {
  id: number;
  userId: number;
  achievementId: number;
  progress: string;
  pointsAwarded: number | null;
  isCompleted: boolean | null;
  completedAt: string | null;
  createdAt: string;
  updatedAt: string;
  achievementTitle: string;
  achievementDescription: string;
  achievementCategory: 'transaction_volume' | 'player_acquisition' | 'retention' | 'consistency' | 'special';
  achievementDifficulty: 'bronze' | 'silver' | 'gold' | 'platinum' | 'diamond';
  achievementIcon: string;
  achievementPointsAwarded: number;
}

interface AchievementSummary {
  totalAchievements: number;
  completedAchievements: number;
  totalPointsEarned: number;
  categoryBreakdown: {
    transaction_volume: number;
    player_acquisition: number;
    retention: number;
    consistency: number;
    special: number;
  };
  nextMilestone?: {
    remaining: number;
    category: string;
    title: string;
  };
}

export default function AchievementsPage() {
  const { toast } = useToast();
  const { user } = useAuth();
  const [category, setCategory] = useState<string>("all");

  // Fetch user achievements
  const { data: userAchievements, isLoading: loadingUserAchievements } = useQuery({
    queryKey: ["/api/user/achievements"]
  });

  // Fetch achievement summary
  const { data: summary, isLoading: loadingSummary } = useQuery({
    queryKey: ["/api/user/achievements/summary"]
  });

  // Filter achievements by category
  const filteredAchievements = userAchievements ? 
    userAchievements.filter((achievement: UserAchievement) => 
      category === "all" || achievement.achievementCategory === category
    ) : [];

  return (
    <div className="container mx-auto p-4 pt-20 lg:pt-24 max-w-7xl">
      <div className="flex flex-col space-y-4 md:space-y-6">
        <h1 className="text-2xl md:text-3xl font-bold tracking-tight">Agent Achievements</h1>
        <p className="text-muted-foreground">
          Complete achievements to earn points and unlock special rewards as a top-performing agent.
        </p>

        {/* Achievement Summary Card */}
        {loadingSummary ? (
          <div className="grid gap-4 md:grid-cols-3">
            <Skeleton className="h-28 rounded-lg" />
            <Skeleton className="h-28 rounded-lg" />
            <Skeleton className="h-28 rounded-lg" />
          </div>
        ) : summary ? (
          <div className="grid gap-4 md:grid-cols-3">
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-lg">Progress</CardTitle>
                <CardDescription>Your achievement completion</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="flex flex-col gap-2">
                  <div className="flex justify-between items-center">
                    <span className="text-sm text-muted-foreground">
                      {summary.completedAchievements} of {summary.totalAchievements}
                    </span>
                    <span className="text-sm font-medium">
                      {Math.round((summary.completedAchievements / summary.totalAchievements) * 100)}%
                    </span>
                  </div>
                  <Progress 
                    value={(summary.completedAchievements / summary.totalAchievements) * 100} 
                    className="h-2" 
                  />
                </div>
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-lg">Total Points</CardTitle>
                <CardDescription>Points earned from achievements</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="flex items-center gap-2">
                  <Award className="h-10 w-10 text-blue-500" />
                  <div>
                    <p className="text-2xl font-bold">{summary.totalPointsEarned}</p>
                    <p className="text-sm text-muted-foreground">points</p>
                  </div>
                </div>
              </CardContent>
            </Card>
            
            {summary.nextMilestone ? (
              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-lg">Next Milestone</CardTitle>
                  <CardDescription>Your next achievement target</CardDescription>
                </CardHeader>
                <CardContent>
                  <p className="text-sm">
                    <span className="font-medium">{summary.nextMilestone.title}</span> - 
                    {" "}{summary.nextMilestone.remaining} more to complete
                  </p>
                </CardContent>
              </Card>
            ) : (
              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-lg">All Caught Up!</CardTitle>
                  <CardDescription>Great job on your achievements</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="flex items-center gap-2">
                    <Shield className="h-10 w-10 text-green-500" />
                    <p className="text-sm text-muted-foreground">
                      You've made great progress on all your active achievements!
                    </p>
                  </div>
                </CardContent>
              </Card>
            )}
          </div>
        ) : (
          <div className="p-8 text-center">
            <AlertTriangle className="h-12 w-12 text-yellow-500 mx-auto mb-4" />
            <h3 className="text-lg font-medium">Couldn't load achievement summary</h3>
            <p className="text-muted-foreground mt-2">Please try again later</p>
          </div>
        )}

        {/* Achievement Tabs & Filters */}
        <Tabs defaultValue="all" value={category} onValueChange={setCategory} className="mt-6">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-xl font-semibold">Your Achievements</h2>
            <TabsList>
              <TabsTrigger value="all">All</TabsTrigger>
              <TabsTrigger value="transaction_volume">Transaction</TabsTrigger>
              <TabsTrigger value="player_acquisition">Acquisition</TabsTrigger>
              <TabsTrigger value="consistency">Consistency</TabsTrigger>
              <TabsTrigger value="special">Special</TabsTrigger>
            </TabsList>
          </div>

          <TabsContent value={category} className="mt-0">
            {loadingUserAchievements ? (
              <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
                {[1, 2, 3, 4, 5, 6].map((i) => (
                  <Skeleton key={i} className="h-56 rounded-lg" />
                ))}
              </div>
            ) : filteredAchievements.length > 0 ? (
              <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
                {filteredAchievements.map((achievement: UserAchievement) => {
                  // Parse the progress data
                  const progressData = JSON.parse(achievement.progress || "{}");
                  const requirementData = JSON.parse(achievement.achievementIcon || "{}");
                  
                  // Calculate progress percentage
                  let progressPercentage = 0;
                  let progressText = "";
                  
                  if (achievement.isCompleted) {
                    progressPercentage = 100;
                    progressText = "Completed!";
                  } else if (progressData && requirementData) {
                    // This is a simplified calculation - would need to be adapted to actual requirement types
                    const current = progressData.current || 0;
                    const target = requirementData.target || 1;
                    progressPercentage = Math.min(Math.round((current / target) * 100), 100);
                    progressText = `${current} / ${target}`;
                  }
                  
                  // Get the appropriate category icon
                  const CategoryIcon = categoryIcons[achievement.achievementCategory] || Award;
                  
                  return (
                    <Card 
                      key={achievement.id} 
                      className={`overflow-hidden transition-all ${
                        achievement.isCompleted ? 'border-green-300 shadow-md' : ''
                      }`}
                    >
                      <div className={`bg-blue-50 p-4 flex items-center justify-between`}>
                        <div className="flex items-center gap-2">
                          <CategoryIcon className="h-5 w-5 text-blue-500" />
                          <span className="text-sm font-medium text-blue-700">
                            {achievement.achievementCategory.replace('_', ' ')}
                          </span>
                        </div>
                        <Badge 
                          variant="outline" 
                          className={`${difficultyColors[achievement.achievementDifficulty]} text-xs`}
                        >
                          {achievement.achievementDifficulty}
                        </Badge>
                      </div>
                      <CardHeader className="pb-2">
                        <CardTitle className="flex items-center justify-between">
                          <span>{achievement.achievementTitle}</span>
                          <span className="text-blue-600 font-bold text-sm ml-2">
                            {achievement.achievementPointsAwarded} pts
                          </span>
                        </CardTitle>
                        <CardDescription>
                          {achievement.achievementDescription}
                        </CardDescription>
                      </CardHeader>
                      <CardContent>
                        <div className="flex flex-col gap-2">
                          <div className="flex justify-between text-sm">
                            <span className="text-muted-foreground">Progress</span>
                            <span className="font-medium">
                              {achievement.isCompleted 
                                ? 'Completed!' 
                                : `${progressText} (${progressPercentage}%)`}
                            </span>
                          </div>
                          <Progress 
                            value={progressPercentage} 
                            className={`h-2 ${achievement.isCompleted ? 'bg-green-100' : ''}`} 
                          />
                        </div>
                      </CardContent>
                      {achievement.completedAt && (
                        <CardFooter className="pt-0 text-xs text-muted-foreground">
                          Completed on {new Date(achievement.completedAt).toLocaleDateString()}
                        </CardFooter>
                      )}
                    </Card>
                  );
                })}
              </div>
            ) : (
              <div className="text-center p-8 bg-gray-50 rounded-lg border">
                <Award className="h-10 w-10 text-gray-400 mx-auto mb-3" />
                <h3 className="text-lg font-medium">No achievements found</h3>
                <p className="text-muted-foreground">
                  {category === "all" 
                    ? "You haven't earned any achievements yet." 
                    : `You haven't earned any achievements in the ${category.replace('_', ' ')} category yet.`}
                </p>
              </div>
            )}
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}
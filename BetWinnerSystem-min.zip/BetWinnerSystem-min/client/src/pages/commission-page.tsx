import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from "recharts";
import { getQueryFn } from "@/lib/queryClient";
import { AppLayout } from "@/layouts/app-layout";

interface Commission {
  id: string;
  type: "deposit" | "withdrawal";
  playerId: string;
  playerUsername: string;
  amount: number;
  commission: number;
  date: string;
  isPaid: boolean;
  paidDate?: string;
  scheduledPayout?: string;
}

interface CommissionSummary {
  pendingAmount: number;
  nextPayoutDate: string;
  currentMonthEarnings: number;
  totalEarnings: number;
  depositCommissionRate: number;
  withdrawalCommissionRate: number;
  monthlyData: {
    month: string;
    deposit: number;
    withdrawal: number;
  }[];
}

export default function CommissionPage() {
  // Fetch commissions
  const { data: commissions = [] } = useQuery<Commission[]>({
    queryKey: ["/api/commissions/history"],
    queryFn: getQueryFn({ on401: "throw" }),
  });

  // Fetch summary
  const { data: summary } = useQuery<CommissionSummary>({
    queryKey: ["/api/commissions/summary"],
    queryFn: getQueryFn({ on401: "throw" }),
  });

  const pendingCommissions = commissions.filter(c => !c.isPaid);
  const paidCommissions = commissions.filter(c => c.isPaid);

  return (
    <AppLayout>
      <div className="mb-6">
        <h1 className="text-2xl font-bold text-gray-900 mb-2">Commissions</h1>
        <p className="text-gray-500">Track your earnings from player deposits and withdrawals</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
        <Card>
          <CardContent className="pt-6">
            <div className="text-center">
              <h3 className="text-sm text-gray-500">Pending Commission</h3>
              <p className="text-2xl font-bold font-mono mt-1">
                ৳ {summary?.pendingAmount?.toLocaleString() || "0"}
              </p>
              <p className="text-xs text-gray-500 mt-1">
                Next payout: {summary?.nextPayoutDate || "N/A"}
              </p>
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="pt-6">
            <div className="text-center">
              <h3 className="text-sm text-gray-500">This Month</h3>
              <p className="text-2xl font-bold font-mono mt-1">
                ৳ {summary?.currentMonthEarnings?.toLocaleString() || "0"}
              </p>
              <div className="flex justify-center space-x-2 mt-1">
                <Badge variant="outline" className="text-xs bg-primary-50">
                  Deposit: {summary?.depositCommissionRate || 2}%
                </Badge>
                <Badge variant="outline" className="text-xs bg-primary-50">
                  Withdrawal: {summary?.withdrawalCommissionRate || 1}%
                </Badge>
              </div>
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="pt-6">
            <div className="text-center">
              <h3 className="text-sm text-gray-500">Total Earnings</h3>
              <p className="text-2xl font-bold font-mono mt-1">
                ৳ {summary?.totalEarnings?.toLocaleString() || "0"}
              </p>
              <p className="text-xs text-gray-500 mt-1">
                Lifetime commission earnings
              </p>
            </div>
          </CardContent>
        </Card>
      </div>

      <Card className="mb-6">
        <CardHeader>
          <CardTitle>Monthly Earnings</CardTitle>
          <CardDescription>Your commission earnings over the past 6 months</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="h-80">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart
                data={summary?.monthlyData || []}
                margin={{ top: 20, right: 30, left: 20, bottom: 5 }}
              >
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="month" />
                <YAxis />
                <Tooltip 
                  formatter={(value: number) => [`৳ ${value.toLocaleString()}`, '']}
                  contentStyle={{
                    backgroundColor: 'white',
                    border: '1px solid #f0f0f0',
                    borderRadius: '4px',
                    padding: '10px'
                  }}
                />
                <Bar dataKey="deposit" name="Deposit Commissions" fill="#3b82f6" />
                <Bar dataKey="withdrawal" name="Withdrawal Commissions" fill="#10b981" />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Commission History</CardTitle>
          <div className="flex justify-between items-center mt-2">
            <CardDescription>Detailed list of your commission earnings</CardDescription>
            <Input placeholder="Search..." className="max-w-xs" />
          </div>
        </CardHeader>
        <CardContent>
          <Tabs defaultValue="all">
            <TabsList className="mb-4">
              <TabsTrigger value="all">All</TabsTrigger>
              <TabsTrigger value="pending">
                Pending
                {pendingCommissions.length > 0 && (
                  <Badge variant="secondary" className="ml-2">{pendingCommissions.length}</Badge>
                )}
              </TabsTrigger>
              <TabsTrigger value="paid">Paid</TabsTrigger>
            </TabsList>

            <div className="overflow-x-auto">
              <table className="min-w-full divide-y divide-gray-200">
                <thead className="bg-gray-50">
                  <tr>
                    <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Type</th>
                    <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Player</th>
                    <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Amount</th>
                    <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Commission</th>
                    <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Date</th>
                    <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Status</th>
                  </tr>
                </thead>
                <tbody className="bg-white divide-y divide-gray-200">
                  <TabsContent value="all">
                    {commissions.length === 0 ? (
                      <tr>
                        <td colSpan={6} className="px-6 py-4 text-center text-sm text-gray-500">
                          No commission history yet
                        </td>
                      </tr>
                    ) : (
                      commissions.map((commission) => (
                        <tr key={commission.id}>
                          <td className="px-6 py-4 whitespace-nowrap">
                            <Badge variant={commission.type === "deposit" ? "default" : "secondary"}>
                              {commission.type === "deposit" ? "Deposit" : "Withdrawal"}
                            </Badge>
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap">
                            <div className="text-sm text-gray-900">{commission.playerUsername}</div>
                            <div className="text-xs text-gray-500">ID: {commission.playerId}</div>
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap">
                            <div className="text-sm font-medium font-mono">
                              ৳ {commission.amount.toLocaleString()}
                            </div>
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap">
                            <div className="text-sm font-medium font-mono">
                              ৳ {commission.commission.toLocaleString()}
                            </div>
                            <div className="text-xs text-gray-500">
                              ({commission.type === "deposit" ? "2%" : "1%"})
                            </div>
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap">
                            <div className="text-sm text-gray-900">{commission.date}</div>
                            {commission.isPaid && commission.paidDate ? (
                              <div className="text-xs text-gray-500">Paid: {commission.paidDate}</div>
                            ) : commission.scheduledPayout && (
                              <div className="text-xs text-gray-500">Scheduled: {commission.scheduledPayout}</div>
                            )}
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap">
                            <span className={`px-2 py-1 text-xs font-medium rounded-full ${
                              commission.isPaid
                                ? "bg-green-100 text-green-800"
                                : "bg-yellow-100 text-yellow-800"
                            }`}>
                              {commission.isPaid ? "Paid" : "Pending"}
                            </span>
                          </td>
                        </tr>
                      ))
                    )}
                  </TabsContent>
                  
                  <TabsContent value="pending">
                    {pendingCommissions.length === 0 ? (
                      <tr>
                        <td colSpan={6} className="px-6 py-4 text-center text-sm text-gray-500">
                          No pending commissions
                        </td>
                      </tr>
                    ) : (
                      pendingCommissions.map((commission) => (
                        <tr key={commission.id}>
                          <td className="px-6 py-4 whitespace-nowrap">
                            <Badge variant={commission.type === "deposit" ? "default" : "secondary"}>
                              {commission.type === "deposit" ? "Deposit" : "Withdrawal"}
                            </Badge>
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap">
                            <div className="text-sm text-gray-900">{commission.playerUsername}</div>
                            <div className="text-xs text-gray-500">ID: {commission.playerId}</div>
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap">
                            <div className="text-sm font-medium font-mono">
                              ৳ {commission.amount.toLocaleString()}
                            </div>
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap">
                            <div className="text-sm font-medium font-mono">
                              ৳ {commission.commission.toLocaleString()}
                            </div>
                            <div className="text-xs text-gray-500">
                              ({commission.type === "deposit" ? "2%" : "1%"})
                            </div>
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap">
                            <div className="text-sm text-gray-900">{commission.date}</div>
                            {commission.scheduledPayout && (
                              <div className="text-xs text-gray-500">Scheduled: {commission.scheduledPayout}</div>
                            )}
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap">
                            <span className="px-2 py-1 text-xs font-medium rounded-full bg-yellow-100 text-yellow-800">
                              Pending
                            </span>
                          </td>
                        </tr>
                      ))
                    )}
                  </TabsContent>
                  
                  <TabsContent value="paid">
                    {paidCommissions.length === 0 ? (
                      <tr>
                        <td colSpan={6} className="px-6 py-4 text-center text-sm text-gray-500">
                          No paid commissions
                        </td>
                      </tr>
                    ) : (
                      paidCommissions.map((commission) => (
                        <tr key={commission.id}>
                          <td className="px-6 py-4 whitespace-nowrap">
                            <Badge variant={commission.type === "deposit" ? "default" : "secondary"}>
                              {commission.type === "deposit" ? "Deposit" : "Withdrawal"}
                            </Badge>
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap">
                            <div className="text-sm text-gray-900">{commission.playerUsername}</div>
                            <div className="text-xs text-gray-500">ID: {commission.playerId}</div>
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap">
                            <div className="text-sm font-medium font-mono">
                              ৳ {commission.amount.toLocaleString()}
                            </div>
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap">
                            <div className="text-sm font-medium font-mono">
                              ৳ {commission.commission.toLocaleString()}
                            </div>
                            <div className="text-xs text-gray-500">
                              ({commission.type === "deposit" ? "2%" : "1%"})
                            </div>
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap">
                            <div className="text-sm text-gray-900">{commission.date}</div>
                            {commission.isPaid && commission.paidDate ? (
                              <div className="text-xs text-gray-500">Paid: {commission.paidDate}</div>
                            ) : commission.scheduledPayout && (
                              <div className="text-xs text-gray-500">Scheduled: {commission.scheduledPayout}</div>
                            )}
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap">
                            <span className="px-2 py-1 text-xs font-medium rounded-full bg-green-100 text-green-800">
                              Paid
                            </span>
                          </td>
                        </tr>
                      ))
                    )}
                  </TabsContent>
                </tbody>
              </table>
            </div>
          </Tabs>
        </CardContent>
      </Card>
    </AppLayout>
  );
}

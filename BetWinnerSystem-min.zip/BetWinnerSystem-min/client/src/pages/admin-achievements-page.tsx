import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { 
  Award, 
  Plus, 
  Edit, 
  Trash2, 
  X, 
  Save,
  Search, 
  TrendingUp, 
  Users, 
  Clock, 
  Shield, 
  AlertTriangle,
  ChevronDown,
  ArrowUpDown
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Form, FormControl, FormDescription, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu";
import { useToast } from "@/hooks/use-toast";
import { zodResolver } from "@hookform/resolvers/zod";
import { useForm } from "react-hook-form";
import { z } from "zod";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { Textarea } from "@/components/ui/textarea";
import { Switch } from "@/components/ui/switch";

// Define achievement difficulty colors
const difficultyColors = {
  bronze: "text-amber-600 bg-amber-100 border-amber-200",
  silver: "text-slate-600 bg-slate-100 border-slate-200",
  gold: "text-yellow-600 bg-yellow-100 border-yellow-200",
  platinum: "text-emerald-600 bg-emerald-100 border-emerald-200",
  diamond: "text-blue-600 bg-blue-100 border-blue-200"
};

// Define achievement category icons
const categoryIcons = {
  transaction_volume: TrendingUp,
  player_acquisition: Users,
  retention: Clock,
  consistency: Shield,
  special: Award
};

// Zod schema for creating and updating achievements
const achievementSchema = z.object({
  title: z.string().min(3, "Title must be at least 3 characters"),
  description: z.string().min(5, "Description must be at least 5 characters"),
  category: z.enum(["transaction_volume", "player_acquisition", "retention", "consistency", "special"]),
  difficulty: z.enum(["bronze", "silver", "gold", "platinum", "diamond"]),
  pointsAwarded: z.coerce.number().int().min(1, "Points must be at least 1"),
  icon: z.string().default(""),
  requirement: z.record(z.any()).default({}),
  requirementJson: z.string().default("{}"),
  isActive: z.boolean().default(true)
}).superRefine(({ requirementJson, requirement }, ctx) => {
  try {
    // If requirementJson is provided, try parsing it as JSON
    if (requirementJson) {
      const parsed = JSON.parse(requirementJson);
      if (typeof parsed !== 'object') {
        ctx.addIssue({
          code: z.ZodIssueCode.custom,
          message: "Requirements must be a valid JSON object",
          path: ["requirementJson"]
        });
      }
    }
  } catch (error) {
    ctx.addIssue({
      code: z.ZodIssueCode.custom,
      message: "Invalid JSON format",
      path: ["requirementJson"]
    });
  }
});

// Achievement types
interface Achievement {
  id: number;
  title: string;
  description: string;
  category: 'transaction_volume' | 'player_acquisition' | 'retention' | 'consistency' | 'special';
  difficulty: 'bronze' | 'silver' | 'gold' | 'platinum' | 'diamond';
  pointsAwarded: number;
  icon: string;
  requirement: Record<string, any>;
  isActive: boolean;
  createdAt: string;
  updatedAt: string;
}

export default function AdminAchievementsPage() {
  const { toast } = useToast();
  const [isCreateDialogOpen, setIsCreateDialogOpen] = useState(false);
  const [isEditDialogOpen, setIsEditDialogOpen] = useState(false);
  const [isDeleteDialogOpen, setIsDeleteDialogOpen] = useState(false);
  const [selectedAchievement, setSelectedAchievement] = useState<Achievement | null>(null);
  const [searchQuery, setSearchQuery] = useState("");
  const [filterCategory, setFilterCategory] = useState<string | null>(null);
  const [filterDifficulty, setFilterDifficulty] = useState<string | null>(null);
  const [sortField, setSortField] = useState<string>("title");
  const [sortOrder, setSortOrder] = useState<"asc" | "desc">("asc");

  // Forms
  const createForm = useForm<z.infer<typeof achievementSchema>>({
    resolver: zodResolver(achievementSchema),
    defaultValues: {
      title: "",
      description: "",
      category: "transaction_volume",
      difficulty: "bronze",
      pointsAwarded: 10,
      icon: "",
      requirement: {},
      requirementJson: "{}",
      isActive: true
    }
  });

  const editForm = useForm<z.infer<typeof achievementSchema>>({
    resolver: zodResolver(achievementSchema),
    defaultValues: {
      title: "",
      description: "",
      category: "transaction_volume",
      difficulty: "bronze",
      pointsAwarded: 10,
      icon: "",
      requirement: {},
      requirementJson: "{}",
      isActive: true
    }
  });

  // Fetch achievements
  const { data: achievements, isLoading } = useQuery<Achievement[]>({
    queryKey: ["/api/achievements"]
  });

  // Create achievement mutation
  const createMutation = useMutation({
    mutationFn: async (data: z.infer<typeof achievementSchema>) => {
      // Parse the requirementJson into a requirement object
      let requirement = data.requirement;
      if (data.requirementJson) {
        try {
          requirement = JSON.parse(data.requirementJson);
        } catch (error) {
          console.error("Error parsing requirement JSON:", error);
        }
      }

      const payload = {
        ...data,
        requirement
      };
      
      // Remove the requirementJson property as it's not needed in the API
      delete (payload as any).requirementJson;
      
      const res = await apiRequest("POST", "/api/admin/achievements", payload);
      return await res.json();
    },
    onSuccess: () => {
      toast({
        title: "Achievement created",
        description: "The achievement has been created successfully.",
      });
      setIsCreateDialogOpen(false);
      createForm.reset();
      queryClient.invalidateQueries({ queryKey: ["/api/achievements"] });
    },
    onError: (error: Error) => {
      toast({
        title: "Failed to create achievement",
        description: error.message,
        variant: "destructive",
      });
    }
  });

  // Update achievement mutation
  const updateMutation = useMutation({
    mutationFn: async (data: z.infer<typeof achievementSchema> & { id: number }) => {
      // Parse the requirementJson into a requirement object
      let requirement = data.requirement;
      if (data.requirementJson) {
        try {
          requirement = JSON.parse(data.requirementJson);
        } catch (error) {
          console.error("Error parsing requirement JSON:", error);
        }
      }

      const { id, ...payload } = data;
      
      // Include the parsed requirement and remove requirementJson
      payload.requirement = requirement;
      delete (payload as any).requirementJson;
      
      const res = await apiRequest("PUT", `/api/admin/achievements/${id}`, payload);
      return await res.json();
    },
    onSuccess: () => {
      toast({
        title: "Achievement updated",
        description: "The achievement has been updated successfully.",
      });
      setIsEditDialogOpen(false);
      setSelectedAchievement(null);
      queryClient.invalidateQueries({ queryKey: ["/api/achievements"] });
    },
    onError: (error: Error) => {
      toast({
        title: "Failed to update achievement",
        description: error.message,
        variant: "destructive",
      });
    }
  });

  // Delete achievement mutation
  const deleteMutation = useMutation({
    mutationFn: async (id: number) => {
      const res = await apiRequest("DELETE", `/api/admin/achievements/${id}`);
      if (!res.ok) {
        throw new Error("Failed to delete achievement");
      }
      return true;
    },
    onSuccess: () => {
      toast({
        title: "Achievement deleted",
        description: "The achievement has been deleted successfully.",
      });
      setIsDeleteDialogOpen(false);
      setSelectedAchievement(null);
      queryClient.invalidateQueries({ queryKey: ["/api/achievements"] });
    },
    onError: (error: Error) => {
      toast({
        title: "Failed to delete achievement",
        description: error.message,
        variant: "destructive",
      });
    }
  });

  // Handle form submissions
  const handleCreateSubmit = (data: z.infer<typeof achievementSchema>) => {
    createMutation.mutate(data);
  };

  const handleEditSubmit = (data: z.infer<typeof achievementSchema>) => {
    if (!selectedAchievement) return;
    updateMutation.mutate({ ...data, id: selectedAchievement.id });
  };

  const handleDeleteConfirm = () => {
    if (!selectedAchievement) return;
    deleteMutation.mutate(selectedAchievement.id);
  };

  // Open edit dialog and set form values
  const openEditDialog = (achievement: Achievement) => {
    setSelectedAchievement(achievement);
    
    // Format the requirement object as JSON string
    const requirementJson = JSON.stringify(achievement.requirement, null, 2);
    
    editForm.reset({
      ...achievement,
      requirementJson
    });
    
    setIsEditDialogOpen(true);
  };

  // Filter and sort achievements
  const filteredAchievements = achievements 
    ? achievements.filter(achievement => {
        let matches = true;
        
        // Apply search query filter
        if (searchQuery) {
          const query = searchQuery.toLowerCase();
          matches = matches && (
            achievement.title.toLowerCase().includes(query) ||
            achievement.description.toLowerCase().includes(query)
          );
        }
        
        // Apply category filter
        if (filterCategory) {
          matches = matches && achievement.category === filterCategory;
        }
        
        // Apply difficulty filter
        if (filterDifficulty) {
          matches = matches && achievement.difficulty === filterDifficulty;
        }
        
        return matches;
      })
      .sort((a, b) => {
        // Handle different field types
        if (sortField === "pointsAwarded") {
          return sortOrder === "asc" 
            ? a.pointsAwarded - b.pointsAwarded
            : b.pointsAwarded - a.pointsAwarded;
        }
        
        if (sortField === "createdAt") {
          return sortOrder === "asc"
            ? new Date(a.createdAt).getTime() - new Date(b.createdAt).getTime()
            : new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime();
        }
        
        // Default string comparison
        const valueA = String(a[sortField as keyof Achievement]).toLowerCase();
        const valueB = String(b[sortField as keyof Achievement]).toLowerCase();
        
        return sortOrder === "asc"
          ? valueA.localeCompare(valueB)
          : valueB.localeCompare(valueA);
      })
    : [];

  // Toggle sort order
  const handleSort = (field: string) => {
    if (sortField === field) {
      setSortOrder(sortOrder === "asc" ? "desc" : "asc");
    } else {
      setSortField(field);
      setSortOrder("asc");
    }
  };

  return (
    <div className="container mx-auto p-4 pt-20 lg:pt-24 max-w-7xl">
      <div className="flex flex-col space-y-4 md:space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl md:text-3xl font-bold tracking-tight">Achievement Management</h1>
            <p className="text-muted-foreground">Create and manage achievements for your agents</p>
          </div>
          
          <div>
            <Button 
              onClick={() => setIsCreateDialogOpen(true)}
              className="flex items-center gap-2"
            >
              <Plus className="h-4 w-4" />
              <span>Create Achievement</span>
            </Button>
          </div>
        </div>

        {/* Filters section */}
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-lg">Filters</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 gap-4 md:grid-cols-3 lg:grid-cols-4">
              <div>
                <label className="text-sm font-medium mb-1 block">Search</label>
                <div className="relative">
                  <Search className="absolute left-2 top-2.5 h-4 w-4 text-muted-foreground" />
                  <Input
                    placeholder="Search achievements..."
                    className="pl-8"
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                  />
                </div>
              </div>
              
              <div>
                <label className="text-sm font-medium mb-1 block">Category</label>
                <Select 
                  value={filterCategory || ""} 
                  onValueChange={(value) => setFilterCategory(value || null)}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="All categories" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="">All categories</SelectItem>
                    <SelectItem value="transaction_volume">Transaction Volume</SelectItem>
                    <SelectItem value="player_acquisition">Player Acquisition</SelectItem>
                    <SelectItem value="retention">Retention</SelectItem>
                    <SelectItem value="consistency">Consistency</SelectItem>
                    <SelectItem value="special">Special</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              
              <div>
                <label className="text-sm font-medium mb-1 block">Difficulty</label>
                <Select 
                  value={filterDifficulty || ""} 
                  onValueChange={(value) => setFilterDifficulty(value || null)}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="All difficulties" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="">All difficulties</SelectItem>
                    <SelectItem value="bronze">Bronze</SelectItem>
                    <SelectItem value="silver">Silver</SelectItem>
                    <SelectItem value="gold">Gold</SelectItem>
                    <SelectItem value="platinum">Platinum</SelectItem>
                    <SelectItem value="diamond">Diamond</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Achievements table */}
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-lg flex items-center justify-between">
              <span>Achievements</span>
              <span className="text-sm font-normal text-muted-foreground">
                {filteredAchievements.length} achievement(s)
              </span>
            </CardTitle>
          </CardHeader>
          <CardContent>
            {isLoading ? (
              <div className="space-y-2">
                <Skeleton className="h-10 w-full" />
                <Skeleton className="h-10 w-full" />
                <Skeleton className="h-10 w-full" />
                <Skeleton className="h-10 w-full" />
                <Skeleton className="h-10 w-full" />
              </div>
            ) : filteredAchievements.length > 0 ? (
              <div className="rounded-md border">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead className="w-[300px]">
                        <Button
                          variant="ghost" 
                          className="p-0 font-bold hover:bg-transparent"
                          onClick={() => handleSort("title")}
                        >
                          Title
                          <ArrowUpDown className="ml-2 h-4 w-4" />
                        </Button>
                      </TableHead>
                      <TableHead>
                        <Button
                          variant="ghost" 
                          className="p-0 font-bold hover:bg-transparent"
                          onClick={() => handleSort("category")}
                        >
                          Category
                          <ArrowUpDown className="ml-2 h-4 w-4" />
                        </Button>
                      </TableHead>
                      <TableHead>
                        <Button
                          variant="ghost" 
                          className="p-0 font-bold hover:bg-transparent"
                          onClick={() => handleSort("difficulty")}
                        >
                          Difficulty
                          <ArrowUpDown className="ml-2 h-4 w-4" />
                        </Button>
                      </TableHead>
                      <TableHead className="text-center">
                        <Button
                          variant="ghost" 
                          className="p-0 font-bold hover:bg-transparent"
                          onClick={() => handleSort("pointsAwarded")}
                        >
                          Points
                          <ArrowUpDown className="ml-2 h-4 w-4" />
                        </Button>
                      </TableHead>
                      <TableHead className="text-center">Status</TableHead>
                      <TableHead className="text-right">Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {filteredAchievements.map((achievement) => {
                      const CategoryIcon = categoryIcons[achievement.category] || Award;
                      
                      return (
                        <TableRow key={achievement.id}>
                          <TableCell className="font-medium">{achievement.title}</TableCell>
                          <TableCell>
                            <div className="flex items-center gap-2">
                              <CategoryIcon className="h-4 w-4 text-primary" />
                              <span className="capitalize">{achievement.category.replace('_', ' ')}</span>
                            </div>
                          </TableCell>
                          <TableCell>
                            <Badge 
                              variant="outline" 
                              className={`${difficultyColors[achievement.difficulty]}`}
                            >
                              {achievement.difficulty}
                            </Badge>
                          </TableCell>
                          <TableCell className="text-center font-semibold">
                            {achievement.pointsAwarded}
                          </TableCell>
                          <TableCell className="text-center">
                            <Badge variant={achievement.isActive ? "default" : "secondary"}>
                              {achievement.isActive ? "Active" : "Inactive"}
                            </Badge>
                          </TableCell>
                          <TableCell className="text-right">
                            <div className="flex justify-end gap-2">
                              <Button
                                variant="outline"
                                size="icon"
                                onClick={() => openEditDialog(achievement)}
                              >
                                <Edit className="h-4 w-4" />
                              </Button>
                              <Button
                                variant="destructive"
                                size="icon"
                                onClick={() => {
                                  setSelectedAchievement(achievement);
                                  setIsDeleteDialogOpen(true);
                                }}
                              >
                                <Trash2 className="h-4 w-4" />
                              </Button>
                            </div>
                          </TableCell>
                        </TableRow>
                      );
                    })}
                  </TableBody>
                </Table>
              </div>
            ) : (
              <div className="text-center p-8 bg-gray-50 rounded-lg border">
                <Award className="h-10 w-10 text-gray-400 mx-auto mb-3" />
                <h3 className="text-lg font-medium">No achievements found</h3>
                <p className="text-muted-foreground">
                  {searchQuery || filterCategory || filterDifficulty 
                    ? "Try adjusting your filters to see more results" 
                    : "Create your first achievement to get started"}
                </p>
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      {/* Create Achievement Dialog */}
      <Dialog open={isCreateDialogOpen} onOpenChange={setIsCreateDialogOpen}>
        <DialogContent className="max-w-xl">
          <DialogHeader>
            <DialogTitle>Create Achievement</DialogTitle>
            <DialogDescription>
              Add a new achievement for your agents to earn.
            </DialogDescription>
          </DialogHeader>
          
          <Form {...createForm}>
            <form onSubmit={createForm.handleSubmit(handleCreateSubmit)} className="space-y-4">
              <FormField
                control={createForm.control}
                name="title"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Title</FormLabel>
                    <FormControl>
                      <Input placeholder="Enter achievement title..." {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <FormField
                control={createForm.control}
                name="description"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Description</FormLabel>
                    <FormControl>
                      <Textarea 
                        placeholder="Enter achievement description..." 
                        className="min-h-20"
                        {...field} 
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <div className="grid grid-cols-1 gap-4 md:grid-cols-2">
                <FormField
                  control={createForm.control}
                  name="category"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Category</FormLabel>
                      <Select 
                        onValueChange={field.onChange} 
                        defaultValue={field.value}
                      >
                        <FormControl>
                          <SelectTrigger>
                            <SelectValue placeholder="Select category" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          <SelectItem value="transaction_volume">Transaction Volume</SelectItem>
                          <SelectItem value="player_acquisition">Player Acquisition</SelectItem>
                          <SelectItem value="retention">Retention</SelectItem>
                          <SelectItem value="consistency">Consistency</SelectItem>
                          <SelectItem value="special">Special</SelectItem>
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={createForm.control}
                  name="difficulty"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Difficulty</FormLabel>
                      <Select 
                        onValueChange={field.onChange} 
                        defaultValue={field.value}
                      >
                        <FormControl>
                          <SelectTrigger>
                            <SelectValue placeholder="Select difficulty" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          <SelectItem value="bronze">Bronze</SelectItem>
                          <SelectItem value="silver">Silver</SelectItem>
                          <SelectItem value="gold">Gold</SelectItem>
                          <SelectItem value="platinum">Platinum</SelectItem>
                          <SelectItem value="diamond">Diamond</SelectItem>
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>
              
              <FormField
                control={createForm.control}
                name="pointsAwarded"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Points Awarded</FormLabel>
                    <FormControl>
                      <Input 
                        type="number" 
                        min="1"
                        placeholder="Enter points..." 
                        {...field} 
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <FormField
                control={createForm.control}
                name="requirementJson"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Requirements (JSON)</FormLabel>
                    <FormControl>
                      <Textarea 
                        placeholder='{"type": "transaction_count", "target": 10}' 
                        className="min-h-20 font-mono"
                        {...field} 
                      />
                    </FormControl>
                    <FormDescription>
                      Define the requirements for completing this achievement in JSON format.
                    </FormDescription>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <FormField
                control={createForm.control}
                name="isActive"
                render={({ field }) => (
                  <FormItem className="flex flex-row items-center justify-between rounded-lg border p-3 shadow-sm">
                    <div className="space-y-0.5">
                      <FormLabel>Active Status</FormLabel>
                      <FormDescription>
                        Make this achievement available to agents
                      </FormDescription>
                    </div>
                    <FormControl>
                      <Switch
                        checked={field.value}
                        onCheckedChange={field.onChange}
                      />
                    </FormControl>
                  </FormItem>
                )}
              />
              
              <DialogFooter>
                <Button 
                  type="button" 
                  variant="outline" 
                  onClick={() => setIsCreateDialogOpen(false)}
                >
                  Cancel
                </Button>
                <Button 
                  type="submit"
                  disabled={createMutation.isPending}
                >
                  {createMutation.isPending ? "Creating..." : "Create Achievement"}
                </Button>
              </DialogFooter>
            </form>
          </Form>
        </DialogContent>
      </Dialog>

      {/* Edit Achievement Dialog */}
      <Dialog open={isEditDialogOpen} onOpenChange={setIsEditDialogOpen}>
        <DialogContent className="max-w-xl">
          <DialogHeader>
            <DialogTitle>Edit Achievement</DialogTitle>
            <DialogDescription>
              Modify the selected achievement.
            </DialogDescription>
          </DialogHeader>
          
          <Form {...editForm}>
            <form onSubmit={editForm.handleSubmit(handleEditSubmit)} className="space-y-4">
              <FormField
                control={editForm.control}
                name="title"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Title</FormLabel>
                    <FormControl>
                      <Input placeholder="Enter achievement title..." {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <FormField
                control={editForm.control}
                name="description"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Description</FormLabel>
                    <FormControl>
                      <Textarea 
                        placeholder="Enter achievement description..." 
                        className="min-h-20"
                        {...field} 
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <div className="grid grid-cols-1 gap-4 md:grid-cols-2">
                <FormField
                  control={editForm.control}
                  name="category"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Category</FormLabel>
                      <Select 
                        onValueChange={field.onChange} 
                        defaultValue={field.value}
                        value={field.value}
                      >
                        <FormControl>
                          <SelectTrigger>
                            <SelectValue placeholder="Select category" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          <SelectItem value="transaction_volume">Transaction Volume</SelectItem>
                          <SelectItem value="player_acquisition">Player Acquisition</SelectItem>
                          <SelectItem value="retention">Retention</SelectItem>
                          <SelectItem value="consistency">Consistency</SelectItem>
                          <SelectItem value="special">Special</SelectItem>
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={editForm.control}
                  name="difficulty"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Difficulty</FormLabel>
                      <Select 
                        onValueChange={field.onChange} 
                        defaultValue={field.value}
                        value={field.value}
                      >
                        <FormControl>
                          <SelectTrigger>
                            <SelectValue placeholder="Select difficulty" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          <SelectItem value="bronze">Bronze</SelectItem>
                          <SelectItem value="silver">Silver</SelectItem>
                          <SelectItem value="gold">Gold</SelectItem>
                          <SelectItem value="platinum">Platinum</SelectItem>
                          <SelectItem value="diamond">Diamond</SelectItem>
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>
              
              <FormField
                control={editForm.control}
                name="pointsAwarded"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Points Awarded</FormLabel>
                    <FormControl>
                      <Input 
                        type="number" 
                        min="1"
                        placeholder="Enter points..." 
                        {...field} 
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <FormField
                control={editForm.control}
                name="requirementJson"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Requirements (JSON)</FormLabel>
                    <FormControl>
                      <Textarea 
                        placeholder='{"type": "transaction_count", "target": 10}' 
                        className="min-h-20 font-mono"
                        {...field} 
                      />
                    </FormControl>
                    <FormDescription>
                      Define the requirements for completing this achievement in JSON format.
                    </FormDescription>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <FormField
                control={editForm.control}
                name="isActive"
                render={({ field }) => (
                  <FormItem className="flex flex-row items-center justify-between rounded-lg border p-3 shadow-sm">
                    <div className="space-y-0.5">
                      <FormLabel>Active Status</FormLabel>
                      <FormDescription>
                        Make this achievement available to agents
                      </FormDescription>
                    </div>
                    <FormControl>
                      <Switch
                        checked={field.value}
                        onCheckedChange={field.onChange}
                      />
                    </FormControl>
                  </FormItem>
                )}
              />
              
              <DialogFooter>
                <Button 
                  type="button" 
                  variant="outline" 
                  onClick={() => setIsEditDialogOpen(false)}
                >
                  Cancel
                </Button>
                <Button 
                  type="submit"
                  disabled={updateMutation.isPending}
                >
                  {updateMutation.isPending ? "Updating..." : "Update Achievement"}
                </Button>
              </DialogFooter>
            </form>
          </Form>
        </DialogContent>
      </Dialog>

      {/* Delete Achievement Dialog */}
      <Dialog open={isDeleteDialogOpen} onOpenChange={setIsDeleteDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Delete Achievement</DialogTitle>
            <DialogDescription>
              Are you sure you want to delete this achievement? This action cannot be undone.
            </DialogDescription>
          </DialogHeader>
          
          {selectedAchievement && (
            <div className="py-4">
              <h3 className="font-medium">{selectedAchievement.title}</h3>
              <p className="text-sm text-muted-foreground mt-1">
                {selectedAchievement.description}
              </p>
            </div>
          )}
          
          <DialogFooter>
            <Button 
              type="button" 
              variant="outline" 
              onClick={() => setIsDeleteDialogOpen(false)}
            >
              Cancel
            </Button>
            <Button 
              type="button"
              variant="destructive"
              onClick={handleDeleteConfirm}
              disabled={deleteMutation.isPending}
            >
              {deleteMutation.isPending ? "Deleting..." : "Delete Achievement"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
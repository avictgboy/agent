import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { AppLayout } from "@/layouts/app-layout";
import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Switch } from "@/components/ui/switch";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";
import { Loader2, Plus, Edit, Trash, Wand2, Share2, ExternalLink, CheckSquare } from "lucide-react";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { PaymentMethod } from "@shared/schema";

interface PaymentMethodFormData {
  type: string;
  name: string;
  details: Record<string, any>;
  purpose: "agent_topup"; // Only support agent_topup
  active: boolean;
}

export default function AdminPaymentMethodsPage() {
  const { toast } = useToast();
  const [selectedTab, setSelectedTab] = useState("methods");
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false);
  const [isEditDialogOpen, setIsEditDialogOpen] = useState(false);
  const [isDeleteDialogOpen, setIsDeleteDialogOpen] = useState(false);
  const [selectedMethod, setSelectedMethod] = useState<PaymentMethod | null>(null);
  const [formData, setFormData] = useState<PaymentMethodFormData>({
    type: "binance_pay",
    name: "",
    details: {},
    purpose: "agent_topup",
    active: true,
  });
  const [useAI, setUseAI] = useState(false);
  const [isAIProcessing, setIsAIProcessing] = useState(false);
  const [aiProcessingResults, setAIProcessingResults] = useState<any>(null);
  const [selectedTransactions, setSelectedTransactions] = useState<string[]>([]);

  // Fetch payment methods
  const { data: paymentMethods, isLoading, error, refetch } = useQuery({
    queryKey: ["/api/payment-methods"],
    queryFn: async () => {
      const res = await apiRequest("GET", "/api/payment-methods");
      return await res.json() as PaymentMethod[];
    }
  });

  // Fetch all pending transactions for AI processing
  const { data: pendingTransactions, isLoading: isLoadingTransactions } = useQuery({
    queryKey: ["/api/admin/transactions/pending"],
    queryFn: async () => {
      const res = await apiRequest("GET", "/api/admin/transactions/pending");
      return await res.json();
    },
    enabled: selectedTab === "ai-automation",
  });

  // Add payment method mutation
  const addMethodMutation = useMutation({
    mutationFn: async (data: PaymentMethodFormData) => {
      const response = await apiRequest(
        "POST", 
        `/api/admin/payment-methods`,
        data
      );
      return await response.json();
    },
    onSuccess: () => {
      toast({
        title: "Payment Method Added",
        description: "The payment method has been successfully added.",
        variant: "default"
      });
      queryClient.invalidateQueries({ queryKey: ["/api/payment-methods"] });
      setIsAddDialogOpen(false);
      resetForm();
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: `Failed to add payment method: ${error.message}`,
        variant: "destructive"
      });
    }
  });

  // Edit payment method mutation
  const editMethodMutation = useMutation({
    mutationFn: async (data: PaymentMethodFormData & { id: number }) => {
      const response = await apiRequest(
        "PATCH", 
        `/api/admin/payment-methods/${data.id}`,
        data
      );
      return await response.json();
    },
    onSuccess: () => {
      toast({
        title: "Payment Method Updated",
        description: "The payment method has been successfully updated.",
        variant: "default"
      });
      queryClient.invalidateQueries({ queryKey: ["/api/payment-methods"] });
      setIsEditDialogOpen(false);
      resetForm();
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: `Failed to update payment method: ${error.message}`,
        variant: "destructive"
      });
    }
  });

  // Delete payment method mutation
  const deleteMethodMutation = useMutation({
    mutationFn: async (id: number) => {
      const response = await apiRequest(
        "DELETE", 
        `/api/admin/payment-methods/${id}`
      );
      return await response.json();
    },
    onSuccess: () => {
      toast({
        title: "Payment Method Deleted",
        description: "The payment method has been successfully deleted.",
        variant: "default"
      });
      queryClient.invalidateQueries({ queryKey: ["/api/payment-methods"] });
      setIsDeleteDialogOpen(false);
      setSelectedMethod(null);
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: `Failed to delete payment method: ${error.message}`,
        variant: "destructive"
      });
    }
  });

  // AI Processing mutation
  const aiProcessMutation = useMutation({
    mutationFn: async (data: { transactionIds: string[], action: string, useAI: boolean }) => {
      const response = await apiRequest(
        "POST", 
        `/api/admin/process-payments`,
        data
      );
      return await response.json();
    },
    onSuccess: (data) => {
      toast({
        title: "AI Processing Complete",
        description: `${data.message}`,
        variant: "default"
      });
      queryClient.invalidateQueries({ queryKey: ["/api/admin/transactions/pending"] });
      setAIProcessingResults(data);
      setSelectedTransactions([]);
      setIsAIProcessing(false);
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: `Failed to process transactions: ${error.message}`,
        variant: "destructive"
      });
      setIsAIProcessing(false);
    }
  });

  const handleOpenAddDialog = () => {
    resetForm();
    setIsAddDialogOpen(true);
  };

  const handleOpenEditDialog = (method: PaymentMethod) => {
    setSelectedMethod(method);
    setFormData({
      type: method.type,
      name: method.name,
      details: method.details || {},
      purpose: "agent_topup", // Always set to agent_topup
      active: method.active || true, // Ensure active is never null
    });
    setIsEditDialogOpen(true);
  };

  const handleOpenDeleteDialog = (method: PaymentMethod) => {
    setSelectedMethod(method);
    setIsDeleteDialogOpen(true);
  };

  const resetForm = () => {
    setFormData({
      type: "binance_pay",
      name: "",
      details: {},
      purpose: "agent_topup",
      active: true,
    });
    setSelectedMethod(null);
  };

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  const handleTypeChange = (value: string) => {
    setFormData((prev) => ({ ...prev, type: value }));
  };

  const handleActiveChange = (checked: boolean) => {
    setFormData((prev) => ({ ...prev, active: checked }));
  };
  
  // Purpose is always agent_topup
  const handlePurposeChange = (value: "agent_topup") => {
    setFormData((prev) => ({ ...prev, purpose: value }));
  };

  const handleDetailsChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setFormData((prev) => ({
      ...prev,
      details: { ...prev.details, [name]: value }
    }));
  };

  const handleAddSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    addMethodMutation.mutate(formData);
  };

  const handleEditSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (selectedMethod) {
      editMethodMutation.mutate({
        ...formData,
        id: selectedMethod.id
      });
    }
  };

  const handleDeleteConfirm = () => {
    if (selectedMethod) {
      deleteMethodMutation.mutate(selectedMethod.id);
    }
  };

  const handleToggleTransactionSelection = (txId: string) => {
    setSelectedTransactions(prev => 
      prev.includes(txId) 
        ? prev.filter(id => id !== txId) 
        : [...prev, txId]
    );
  };

  const handleSelectAllTransactions = () => {
    if (pendingTransactions && pendingTransactions.length > 0) {
      if (selectedTransactions.length === pendingTransactions.length) {
        // If all are selected, deselect all
        setSelectedTransactions([]);
      } else {
        // Select all
        setSelectedTransactions(pendingTransactions.map((tx: any) => `player-${tx.id}`));
      }
    }
  };

  const handleAIProcessing = (action: "approve" | "reject") => {
    if (selectedTransactions.length === 0) {
      toast({
        title: "No Transactions Selected",
        description: "Please select at least one transaction to process.",
        variant: "destructive"
      });
      return;
    }

    setIsAIProcessing(true);
    setAIProcessingResults(null);
    
    aiProcessMutation.mutate({
      transactionIds: selectedTransactions,
      action,
      useAI: useAI
    });
  };

  const getStatusBadgeVariant = (status: boolean | null) => {
    // Consider null as active (true)
    return status !== false ? "default" : "secondary";
  };

  // Render loading state
  if (isLoading) {
    return (
      <AppLayout>
        <div className="flex items-center justify-center min-h-[400px]">
          <Loader2 className="h-8 w-8 animate-spin text-primary" />
          <span className="ml-2">Loading payment methods...</span>
        </div>
      </AppLayout>
    );
  }

  // Render error state
  if (error) {
    return (
      <AppLayout>
        <Card>
          <CardHeader>
            <CardTitle className="text-destructive">Error</CardTitle>
          </CardHeader>
          <CardContent>
            <p>Failed to load payment methods. Please try again later.</p>
            <Button onClick={() => refetch()} className="mt-4">Retry</Button>
          </CardContent>
        </Card>
      </AppLayout>
    );
  }

  return (
    <AppLayout>
      <div className="container mx-auto py-6">
        <div className="flex justify-between items-center mb-6">
          <h1 className="text-3xl font-bold">Payment Methods Management</h1>
          <Button onClick={handleOpenAddDialog}>
            <Plus className="h-4 w-4 mr-2" />
            Add Method
          </Button>
        </div>

        <Tabs defaultValue="methods" value={selectedTab} onValueChange={setSelectedTab}>
          <TabsList className="mb-4">
            <TabsTrigger value="methods">Payment Methods</TabsTrigger>
            <TabsTrigger value="ai-automation">AI Payment Processing</TabsTrigger>
          </TabsList>
          
          <TabsContent value="methods">
            <Card>
              <CardHeader>
                <CardTitle>Available Payment Methods</CardTitle>
                <CardDescription>
                  Manage the payment methods available for users
                </CardDescription>
              </CardHeader>
              <CardContent>
                {!paymentMethods || paymentMethods.length === 0 ? (
                  <div className="text-center py-8 text-muted-foreground">
                    No payment methods found. Click "Add Method" to create one.
                  </div>
                ) : (
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                    {paymentMethods.map((method) => (
                      <Card key={method.id} className="overflow-hidden">
                        <CardHeader className="bg-muted/30 pb-2">
                          <div className="flex justify-between items-start">
                            <div>
                              <CardTitle className="text-lg">{method.name}</CardTitle>
                              <CardDescription className="capitalize">{method.type}</CardDescription>
                            </div>
                            <div className="flex flex-col gap-1 items-end">
                              <Badge variant={getStatusBadgeVariant(method.active)}>
                                {method.active !== false ? "Active" : "Inactive"}
                              </Badge>
                              <Badge variant="outline" className="bg-blue-50">
                                Agent Topup
                              </Badge>
                            </div>
                          </div>
                        </CardHeader>
                        <CardContent className="pt-4">
                          <div className="space-y-2">
                            {method.details && Object.entries(method.details || {}).map(([key, value]) => {
                              const displayValue = typeof value === 'string' 
                                ? value 
                                : (value === null ? '' : JSON.stringify(value));
                              return (
                                <div key={key} className="flex justify-between">
                                  <span className="text-sm font-medium text-muted-foreground capitalize">{key.replace('_', ' ')}:</span>
                                  <span className="text-sm">{displayValue}</span>
                                </div>
                              );
                            })}
                          </div>
                        </CardContent>
                        <CardFooter className="bg-muted/20 border-t flex justify-end space-x-2">
                          <Button variant="ghost" size="sm" onClick={() => handleOpenEditDialog(method)}>
                            <Edit className="h-4 w-4 mr-1" />
                            Edit
                          </Button>
                          <Button variant="ghost" size="sm" className="text-destructive" onClick={() => handleOpenDeleteDialog(method)}>
                            <Trash className="h-4 w-4 mr-1" />
                            Delete
                          </Button>
                        </CardFooter>
                      </Card>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>
          
          <TabsContent value="ai-automation">
            <Card>
              <CardHeader>
                <CardTitle>AI-Powered Payment Processing</CardTitle>
                <CardDescription>
                  Use AI to automatically approve or reject payment transactions
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="mb-6 bg-muted/30 p-4 rounded-md border">
                  <div className="flex items-center mb-3">
                    <Wand2 className="h-5 w-5 mr-2 text-primary" />
                    <h3 className="font-semibold text-lg">AI Processing Settings</h3>
                  </div>
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm mb-1">Enable AI for fraud detection and automatic processing</p>
                      <p className="text-xs text-muted-foreground">
                        When enabled, AI will analyze transactions for suspicious patterns before approval
                      </p>
                    </div>
                    <div className="flex items-center space-x-2">
                      <Switch
                        id="ai-mode"
                        checked={useAI}
                        onCheckedChange={setUseAI}
                      />
                      <Label htmlFor="ai-mode" className="cursor-pointer">
                        {useAI ? 'AI Enabled' : 'AI Disabled'}
                      </Label>
                    </div>
                  </div>
                </div>

                {isLoadingTransactions ? (
                  <div className="flex items-center justify-center py-8">
                    <Loader2 className="h-6 w-6 animate-spin text-primary mr-2" />
                    <span>Loading pending transactions...</span>
                  </div>
                ) : !pendingTransactions || pendingTransactions.length === 0 ? (
                  <div className="text-center py-8 text-muted-foreground">
                    No pending transactions to process.
                  </div>
                ) : (
                  <div className="space-y-4">
                    <div className="flex justify-between items-center mb-2">
                      <Button variant="outline" size="sm" onClick={handleSelectAllTransactions}>
                        <CheckSquare className="h-4 w-4 mr-2" />
                        {selectedTransactions.length === pendingTransactions.length ? 'Deselect All' : 'Select All'}
                      </Button>
                      <div className="flex space-x-2">
                        <Button 
                          variant="outline" 
                          size="sm"
                          className="bg-green-50 hover:bg-green-100 text-green-700 hover:text-green-800 border-green-200"
                          onClick={() => handleAIProcessing("approve")}
                          disabled={selectedTransactions.length === 0 || isAIProcessing}
                        >
                          {isAIProcessing ? (
                            <>
                              <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                              Processing...
                            </>
                          ) : (
                            <>
                              {useAI && <Wand2 className="h-4 w-4 mr-1" />}
                              Approve Selected
                            </>
                          )}
                        </Button>
                        <Button 
                          variant="outline" 
                          size="sm"
                          className="bg-red-50 hover:bg-red-100 text-red-700 hover:text-red-800 border-red-200"
                          onClick={() => handleAIProcessing("reject")}
                          disabled={selectedTransactions.length === 0 || isAIProcessing}
                        >
                          {isAIProcessing ? (
                            <>
                              <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                              Processing...
                            </>
                          ) : (
                            <>
                              {useAI && <Wand2 className="h-4 w-4 mr-1" />}
                              Reject Selected
                            </>
                          )}
                        </Button>
                      </div>
                    </div>

                    <div className="border rounded-md overflow-x-auto">
                      <table className="w-full">
                        <thead>
                          <tr className="bg-muted/40">
                            <th className="text-left py-2 px-4 font-medium">Select</th>
                            <th className="text-left py-2 px-4 font-medium">ID</th>
                            <th className="text-left py-2 px-4 font-medium">Type</th>
                            <th className="text-left py-2 px-4 font-medium">Player</th>
                            <th className="text-left py-2 px-4 font-medium">Agent</th>
                            <th className="text-left py-2 px-4 font-medium">Amount</th>
                            <th className="text-left py-2 px-4 font-medium">Date</th>
                          </tr>
                        </thead>
                        <tbody>
                          {pendingTransactions.map((tx: any) => (
                            <tr 
                              key={tx.id} 
                              className={`border-b hover:bg-muted/50 ${
                                selectedTransactions.includes(`player-${tx.id}`) ? 'bg-blue-50' : ''
                              }`}
                            >
                              <td className="py-3 px-4">
                                <input 
                                  type="checkbox" 
                                  checked={selectedTransactions.includes(`player-${tx.id}`)}
                                  onChange={() => handleToggleTransactionSelection(`player-${tx.id}`)}
                                  className="h-4 w-4 rounded border-gray-300"
                                />
                              </td>
                              <td className="py-3 px-4">{tx.id}</td>
                              <td className="py-3 px-4 capitalize">{tx.type}</td>
                              <td className="py-3 px-4">{tx.playerId}</td>
                              <td className="py-3 px-4">{tx.agentUsername}</td>
                              <td className="py-3 px-4">
                                {new Intl.NumberFormat('en-US', {
                                  style: 'currency',
                                  currency: 'BDT',
                                }).format(tx.amount)}
                              </td>
                              <td className="py-3 px-4">{tx.date} {tx.time}</td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  </div>
                )}

                {aiProcessingResults && (
                  <div className="mt-6 border rounded-md p-4 bg-muted/30">
                    <h3 className="font-semibold mb-2 flex items-center">
                      <Wand2 className="h-4 w-4 mr-2 text-primary" />
                      AI Processing Results
                    </h3>
                    <p className="mb-3">{aiProcessingResults.message}</p>
                    <div className="space-y-2">
                      {aiProcessingResults.results.map((result: any, index: number) => (
                        <div key={index} className="text-sm bg-card p-2 rounded border">
                          <div className="flex justify-between">
                            <span>Transaction ID: {result.id}</span>
                            <Badge variant={result.status === "not_implemented" ? "outline" : "default"}>
                              {result.status || (result.result?.status || "Processed")}
                            </Badge>
                          </div>
                          {result.message && <p className="text-xs text-muted-foreground mt-1">{result.message}</p>}
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>

      {/* Add Method Dialog */}
      <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
        <DialogContent className="sm:max-w-[550px]">
          <DialogHeader>
            <DialogTitle>Add Payment Method</DialogTitle>
            <DialogDescription>
              Add a new payment method for users to deposit or withdraw funds.
            </DialogDescription>
          </DialogHeader>
          
          <form onSubmit={handleAddSubmit}>
            <div className="space-y-4 py-4">
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="type">Method Type</Label>
                  <Select
                    value={formData.type}
                    onValueChange={handleTypeChange}
                  >
                    <SelectTrigger id="type">
                      <SelectValue placeholder="Select type" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="binance_pay">Binance Pay</SelectItem>
                      <SelectItem value="custom_usdt">Custom USDT</SelectItem>
                      <SelectItem value="bkash">bKash</SelectItem>
                      <SelectItem value="nagad">Nagad</SelectItem>
                      <SelectItem value="rocket">Rocket</SelectItem>
                      <SelectItem value="bank_transfer">Bank Transfer</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="purpose">Payment Purpose</Label>
                  <Select
                    value={formData.purpose}
                    onValueChange={handlePurposeChange}
                  >
                    <SelectTrigger id="purpose">
                      <SelectValue placeholder="Select purpose" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="agent_topup">Agent Topup</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="name">Display Name</Label>
                <Input
                  id="name"
                  name="name"
                  value={formData.name}
                  onChange={handleInputChange}
                  placeholder="e.g. bKash Mobile Banking"
                  required
                />
              </div>
              
              <div className="space-y-2">
                <Label>Method Details</Label>
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="account_number">Account Number</Label>
                    <Input
                      id="account_number"
                      name="account_number"
                      value={formData.details.account_number || ""}
                      onChange={handleDetailsChange}
                      placeholder="e.g. 01712345678"
                    />
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="account_name">Account Name</Label>
                    <Input
                      id="account_name"
                      name="account_name"
                      value={formData.details.account_name || ""}
                      onChange={handleDetailsChange}
                      placeholder="e.g. John Doe"
                    />
                  </div>
                </div>
                
                {formData.type === "bkash" && formData.purpose === "agent_topup" && (
                  <div className="space-y-2 mt-2">
                    <Label htmlFor="agent_number">bKash Agent Number</Label>
                    <Input
                      id="agent_number"
                      name="agent_number"
                      value={formData.details.agent_number || ""}
                      onChange={handleDetailsChange}
                      placeholder="e.g. 01712345678"
                    />
                    <p className="text-sm text-muted-foreground">
                      This is the dedicated agent number agents should use for sub-agent topups.
                    </p>
                  </div>
                )}
                
                {formData.type === "bank" && (
                  <div className="space-y-2 mt-2">
                    <Label htmlFor="bank_name">Bank Name</Label>
                    <Input
                      id="bank_name"
                      name="bank_name"
                      value={formData.details.bank_name || ""}
                      onChange={handleDetailsChange}
                      placeholder="e.g. City Bank"
                    />
                  </div>
                )}
                
                {formData.type === "crypto" && (
                  <div className="space-y-2 mt-2">
                    <Label htmlFor="wallet_address">Wallet Address</Label>
                    <Input
                      id="wallet_address"
                      name="wallet_address"
                      value={formData.details.wallet_address || ""}
                      onChange={handleDetailsChange}
                      placeholder="e.g. 0x1234..."
                    />
                  </div>
                )}
                
                <div className="space-y-2 mt-2">
                  <Label htmlFor="instructions">Instructions</Label>
                  <Textarea
                    id="instructions"
                    name="instructions"
                    value={formData.details.instructions || ""}
                    onChange={handleDetailsChange}
                    placeholder="Instructions for users..."
                    rows={3}
                  />
                </div>
              </div>
              
              <div className="flex items-center space-x-2 pt-2">
                <Switch
                  id="active"
                  checked={formData.active}
                  onCheckedChange={handleActiveChange}
                />
                <Label htmlFor="active">Method is active and available to users</Label>
              </div>
            </div>

            <DialogFooter>
              <Button type="button" variant="outline" onClick={() => setIsAddDialogOpen(false)}>
                Cancel
              </Button>
              <Button type="submit" disabled={addMethodMutation.isPending}>
                {addMethodMutation.isPending ? (
                  <>
                    <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                    Adding...
                  </>
                ) : 'Add Payment Method'}
              </Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>

      {/* Edit Method Dialog */}
      <Dialog open={isEditDialogOpen} onOpenChange={setIsEditDialogOpen}>
        <DialogContent className="sm:max-w-[550px]">
          <DialogHeader>
            <DialogTitle>Edit Payment Method</DialogTitle>
            <DialogDescription>
              Update the details of the selected payment method.
            </DialogDescription>
          </DialogHeader>
          
          <form onSubmit={handleEditSubmit}>
            <div className="space-y-4 py-4">
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="edit-type">Method Type</Label>
                  <Select
                    value={formData.type}
                    onValueChange={handleTypeChange}
                  >
                    <SelectTrigger id="edit-type">
                      <SelectValue placeholder="Select type" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="binance_pay">Binance Pay</SelectItem>
                      <SelectItem value="custom_usdt">Custom USDT</SelectItem>
                      <SelectItem value="bkash">bKash</SelectItem>
                      <SelectItem value="nagad">Nagad</SelectItem>
                      <SelectItem value="rocket">Rocket</SelectItem>
                      <SelectItem value="bank_transfer">Bank Transfer</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="edit-purpose">Payment Purpose</Label>
                  <Select
                    value={formData.purpose}
                    onValueChange={handlePurposeChange}
                  >
                    <SelectTrigger id="edit-purpose">
                      <SelectValue placeholder="Select purpose" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="agent_topup">Agent Topup</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="edit-name">Display Name</Label>
                <Input
                  id="edit-name"
                  name="name"
                  value={formData.name}
                  onChange={handleInputChange}
                  placeholder="e.g. bKash Mobile Banking"
                  required
                />
              </div>
              
              <div className="space-y-2">
                <Label>Method Details</Label>
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="edit-account_number">Account Number</Label>
                    <Input
                      id="edit-account_number"
                      name="account_number"
                      value={formData.details.account_number || ""}
                      onChange={handleDetailsChange}
                      placeholder="e.g. 01712345678"
                    />
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="edit-account_name">Account Name</Label>
                    <Input
                      id="edit-account_name"
                      name="account_name"
                      value={formData.details.account_name || ""}
                      onChange={handleDetailsChange}
                      placeholder="e.g. John Doe"
                    />
                  </div>
                </div>
                
                {formData.type === "bkash" && formData.purpose === "agent_topup" && (
                  <div className="space-y-2 mt-2">
                    <Label htmlFor="edit-agent_number">bKash Agent Number</Label>
                    <Input
                      id="edit-agent_number"
                      name="agent_number"
                      value={formData.details.agent_number || ""}
                      onChange={handleDetailsChange}
                      placeholder="e.g. 01712345678"
                    />
                    <p className="text-sm text-muted-foreground">
                      This is the dedicated agent number agents should use for sub-agent topups.
                    </p>
                  </div>
                )}
                
                {formData.type === "bank" && (
                  <div className="space-y-2 mt-2">
                    <Label htmlFor="edit-bank_name">Bank Name</Label>
                    <Input
                      id="edit-bank_name"
                      name="bank_name"
                      value={formData.details.bank_name || ""}
                      onChange={handleDetailsChange}
                      placeholder="e.g. City Bank"
                    />
                  </div>
                )}
                
                {formData.type === "crypto" && (
                  <div className="space-y-2 mt-2">
                    <Label htmlFor="edit-wallet_address">Wallet Address</Label>
                    <Input
                      id="edit-wallet_address"
                      name="wallet_address"
                      value={formData.details.wallet_address || ""}
                      onChange={handleDetailsChange}
                      placeholder="e.g. 0x1234..."
                    />
                  </div>
                )}
                
                <div className="space-y-2 mt-2">
                  <Label htmlFor="edit-instructions">Instructions</Label>
                  <Textarea
                    id="edit-instructions"
                    name="instructions"
                    value={formData.details.instructions || ""}
                    onChange={handleDetailsChange}
                    placeholder="Instructions for users..."
                    rows={3}
                  />
                </div>
              </div>
              
              <div className="flex items-center space-x-2 pt-2">
                <Switch
                  id="edit-active"
                  checked={formData.active}
                  onCheckedChange={handleActiveChange}
                />
                <Label htmlFor="edit-active">Method is active and available to users</Label>
              </div>
            </div>

            <DialogFooter>
              <Button type="button" variant="outline" onClick={() => setIsEditDialogOpen(false)}>
                Cancel
              </Button>
              <Button type="submit" disabled={editMethodMutation.isPending}>
                {editMethodMutation.isPending ? (
                  <>
                    <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                    Updating...
                  </>
                ) : 'Update Payment Method'}
              </Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>

      {/* Delete Method Dialog */}
      <Dialog open={isDeleteDialogOpen} onOpenChange={setIsDeleteDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Delete Payment Method</DialogTitle>
            <DialogDescription>
              Are you sure you want to delete this payment method? This action cannot be undone.
            </DialogDescription>
          </DialogHeader>
          
          {selectedMethod && (
            <div className="py-4">
              <div className="bg-muted p-3 rounded-md mb-4">
                <p><strong>Name:</strong> {selectedMethod.name}</p>
                <p><strong>Type:</strong> <span className="capitalize">{selectedMethod.type}</span></p>
                <p><strong>Purpose:</strong> Agent Topup</p>
                <p><strong>Status:</strong> {selectedMethod.active !== false ? 'Active' : 'Inactive'}</p>
              </div>
              <p className="text-sm text-destructive">
                Warning: This will remove the payment method and users will no longer be able to use it.
              </p>
            </div>
          )}

          <DialogFooter>
            <Button type="button" variant="outline" onClick={() => setIsDeleteDialogOpen(false)}>
              Cancel
            </Button>
            <Button 
              variant="destructive" 
              onClick={handleDeleteConfirm}
              disabled={deleteMethodMutation.isPending}
            >
              {deleteMethodMutation.isPending ? (
                <>
                  <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                  Deleting...
                </>
              ) : 'Delete Payment Method'}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </AppLayout>
  );
}
import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { ThemeProvider } from "@/components/providers";
import { AuthProvider } from "@/hooks/use-auth";
import AuthPage from "@/pages/auth-page";
import DashboardPage from "@/pages/dashboard-page";
import PlayerManagementPage from "@/pages/player-management-page";
import CommissionPage from "@/pages/commission-page";
import SupportPage from "@/pages/support-page";
import ChatPage from "@/pages/chat-page";
import AddFundsPage from "@/pages/add-funds-page";
import RemittancePage from "@/pages/remittance-page";
import TransactionsHistoryPage from "@/pages/transactions-history-page";
import AchievementsPage from "@/pages/achievements-page";
import AdminTransactionsPage from "@/pages/admin-transactions-page";
import AdminTransactionsHistoryPage from "@/pages/admin-transactions-history-page";
import AdminPaymentMethodsPage from "@/pages/admin-payment-methods-page";
import AdminRemittancePage from "@/pages/admin-remittance-page";
import AdminAchievementsPage from "@/pages/admin-achievements-page";
import UserManagementPage from "@/pages/user-management-page";
import CommissionSettingsPage from "@/pages/commission-settings-page";
import NotFound from "@/pages/not-found";
import { ProtectedRoute } from "@/lib/protected-route";
import { WebSocketProvider } from "@/hooks/use-websocket";
import { CurrencyProvider } from "@/hooks/use-currency";

function Router() {
  return (
    <Switch>
      <Route path="/auth" component={AuthPage} />
      <ProtectedRoute path="/" component={DashboardPage} />
      <ProtectedRoute path="/add-funds" component={AddFundsPage} />
      <ProtectedRoute path="/player-management" component={PlayerManagementPage} />
      <ProtectedRoute path="/commissions" component={CommissionPage} />
      <ProtectedRoute path="/remittance" component={RemittancePage} />
      <ProtectedRoute path="/transactions" component={TransactionsHistoryPage} />
      <ProtectedRoute path="/achievements" component={AchievementsPage} />
      <ProtectedRoute path="/support" component={SupportPage} />
      <ProtectedRoute path="/chat" component={ChatPage} />
      
      {/* Admin Routes */}
      <ProtectedRoute 
        path="/admin/transactions" 
        component={AdminTransactionsPage} 
        requiredRole="admin" 
      />
      <ProtectedRoute 
        path="/admin/transactions-history" 
        component={AdminTransactionsHistoryPage} 
        requiredRole="admin" 
      />
      <ProtectedRoute 
        path="/admin/users" 
        component={UserManagementPage} 
        requiredRole="admin" 
      />
      <ProtectedRoute 
        path="/admin/commission-settings" 
        component={CommissionSettingsPage} 
        requiredRole="admin" 
      />
      <ProtectedRoute 
        path="/admin/payment-methods" 
        component={AdminPaymentMethodsPage} 
        requiredRole="admin" 
      />
      <ProtectedRoute 
        path="/admin/remittance" 
        component={AdminRemittancePage} 
        requiredRole="admin" 
      />
      <ProtectedRoute 
        path="/admin/achievements" 
        component={AdminAchievementsPage} 
        requiredRole="admin" 
      />
      
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <AuthProvider>
        <CurrencyProvider>
          <WebSocketProvider>
            <ThemeProvider>
              <TooltipProvider>
                <Toaster />
                <Router />
              </TooltipProvider>
            </ThemeProvider>
          </WebSocketProvider>
        </CurrencyProvider>
      </AuthProvider>
    </QueryClientProvider>
  );
}

export default App;

import session from "express-session";
import { 
  User, InsertUser, 
  InsertRemittanceFee, InsertRemittanceTransaction,
  RemittanceFee, RemittanceTransaction,
  Achievement, UserAchievement, InsertAchievement, InsertUserAchievement
} from '@shared/schema';

export interface TopUpRequest {
  amount: number;
  currency: string;
  paymentMethod: "binance_pay" | "custom_usdt" | "bkash" | "nagad" | "rocket" | "bank_transfer";
  walletAddress?: string;
  accountNumber?: string;
  bankDetails?: string;
  transactionId?: string;
}

export interface WithdrawalRequest {
  amount: number;
  withdrawalMethod: "bank_transfer" | "bkash" | "nagad" | "rocket" | "usdt";
  accountNumber?: string;
  walletAddress?: string;
  bankDetails?: string;
}

export interface RemittanceRequest {
  recipientChannel: "npsb_bank" | "bkash" | "nagad" | "rocket";
  recipientName?: string;
  recipientAccount: string;
  recipientAdditionalInfo?: any;
  amount: number;
  notes?: string;
}

export interface TransactionFilter {
  startDate?: Date;
  endDate?: Date;
  type?: string[];
  status?: string[];
  search?: string;
  agentId?: number;
  playerId?: string;
}

export interface IStorage {
  sessionStore: any; // Using 'any' for session store type to avoid TypeScript issues
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUser(id: number, userData: Partial<User>): Promise<User | undefined>;
  createTopupRequest(userId: number, data: TopUpRequest): Promise<any>;
  createWithdrawalRequest(userId: number, data: WithdrawalRequest): Promise<any>;
  getTransactionsByUserId(userId: number, filters?: TransactionFilter): Promise<any[]>;
  getAllTransactions(filters?: TransactionFilter): Promise<any[]>; // Admin-only method for all transactions
  getTopupTransactionsByUserId(userId: number): Promise<any[]>;
  getPlayersByAgentId(agentId: number): Promise<any[]>;
  createPlayerDepositRequest(agentId: number, data: any): Promise<any>;
  createPlayerWithdrawalRequest(agentId: number, data: any): Promise<any>;
  getCommissionsByUserId(userId: number): Promise<any[]>;
  getCommissionsSummary(userId: number): Promise<any>;
  getAffiliateData(userId: number): Promise<any>;
  getAffiliateStats(userId: number): Promise<any>;
  getReferredPlayers(userId: number): Promise<any[]>;
  getSupportTicketsByUserId(userId: number): Promise<any[]>;
  createSupportTicket(userId: number, data: any): Promise<any>;
  addSupportTicketMessage(userId: number, data: any): Promise<any>;
  markSupportTicketAsRead(userId: number, ticketId: string): Promise<void>;
  
  // Remittance operations
  getRemittanceFees(): Promise<RemittanceFee[]>;
  getRemittanceFeeById(id: number): Promise<RemittanceFee | undefined>;
  createRemittanceFee(data: InsertRemittanceFee): Promise<RemittanceFee>;
  updateRemittanceFee(id: number, data: Partial<RemittanceFee>): Promise<RemittanceFee | undefined>;
  deleteRemittanceFee(id: number): Promise<boolean>;
  
  createRemittanceRequest(agentId: number, data: RemittanceRequest): Promise<RemittanceTransaction>;
  getRemittanceTransactionsByAgentId(agentId: number): Promise<RemittanceTransaction[]>;
  getPendingRemittanceTransactions(): Promise<RemittanceTransaction[]>;
  approveRemittanceTransaction(
    transactionId: number, 
    approve: boolean, 
    reason: string, 
    adminId: number,
    transactionNumber?: string
  ): Promise<RemittanceTransaction>;
  
  // Achievement operations
  getAchievements(): Promise<Achievement[]>;
  getAchievementById(id: number): Promise<Achievement | undefined>;
  getUserAchievements(userId: number): Promise<UserAchievement[]>;
  createAchievement(data: InsertAchievement): Promise<Achievement>;
  updateAchievement(id: number, data: Partial<Achievement>): Promise<Achievement | undefined>;
  deleteAchievement(id: number): Promise<boolean>;
  
  // User achievement tracking
  getUserAchievementById(id: number): Promise<UserAchievement | undefined>;
  createUserAchievement(data: InsertUserAchievement): Promise<UserAchievement>;
  updateUserAchievement(id: number, data: Partial<UserAchievement>): Promise<UserAchievement | undefined>;
  
  // Achievement progress tracking
  trackAchievementProgress(userId: number, category: string, action: string, value?: number): Promise<UserAchievement[]>;
  getUserAchievementSummary(userId: number): Promise<{
    total: number;
    completed: number;
    inProgress: number;
    totalPoints: number;
  }>;
}

// Import the database storage implementation
import { DatabaseStorage } from "./database-storage";

// Use DatabaseStorage for persistence
export const storage = new DatabaseStorage();
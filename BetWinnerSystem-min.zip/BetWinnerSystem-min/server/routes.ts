import type { Express } from "express";
import { createServer, type Server } from "http";
import { WebSocketServer, WebSocket } from 'ws';
import { storage } from "./storage";
import { setupAuth } from "./auth";
import { z } from "zod";
import { db } from "./db";
import { 
  users, players, playerTransactions, topupTransactions, withdrawalTransactions, commissions,
  chatMessages, paymentMethods, exchangeRates, remittanceFees, remittanceTransactions,
  achievements, userAchievements
} from "@shared/schema";
import { count, eq, sum, desc, and, isNull, or, inArray, SQL } from "drizzle-orm";
import { connections, sendNotification } from "./scheduled-jobs";
import OpenAI from "openai";

// Initialize OpenAI with API key from environment variable
// The API key is checked at runtime to allow the server to start without it
let openai: OpenAI | null = null;
if (process.env.OPENAI_API_KEY) {
  openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });
}

export async function registerRoutes(app: Express): Promise<Server> {
  // Setup authentication routes
  setupAuth(app);

  const httpServer = createServer(app);
  
  // Setup WebSocket server for real-time notifications
  const wss = new WebSocketServer({ server: httpServer, path: '/ws' });
  
  // Using the exported connections map from scheduled-jobs.ts
  wss.on('connection', (ws) => {
    let userId: number | null = null;
    
    ws.on('message', (message) => {
      try {
        const data = JSON.parse(message.toString());
        
        // Handle authentication message
        if (data.type === 'auth' && data.userId) {
          userId = data.userId;
          connections.set(userId, ws);
          console.log(`User ${userId} connected to WebSocket`);
        }
      } catch (error) {
        console.error('Error parsing WebSocket message:', error);
      }
    });
    
    ws.on('close', () => {
      if (userId) {
        connections.delete(userId);
        console.log(`User ${userId} disconnected from WebSocket`);
      }
    });
  });

  // Middleware to check authentication
  const requireAuth = (req: any, res: any, next: any) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ message: "Unauthorized" });
    }
    next();
  };

  // Middleware to check admin role
  const requireAdmin = (req: any, res: any, next: any) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ message: "Unauthorized" });
    }
    if (req.user.role !== 'admin') {
      return res.status(403).json({ message: "Access forbidden: Admin privileges required" });
    }
    next();
  };

  // Currency rates endpoint
  app.get("/api/rates", requireAuth, async (req, res) => {
    try {
      // Get latest exchange rate from database
      const [latestRate] = await db.select()
        .from(exchangeRates)
        .where(and(
          eq(exchangeRates.fromCurrency, 'USDT'),
          eq(exchangeRates.toCurrency, 'BDT')
        ))
        .orderBy(desc(exchangeRates.updatedAt))
        .limit(1);
      
      if (latestRate) {
        res.json({
          usdtToBdt: parseFloat(latestRate.rate.toString()),
          lastUpdated: latestRate.updatedAt.toISOString(),
          source: latestRate.source
        });
      } else {
        // Fallback to hardcoded value if no rate exists
        res.json({
          usdtToBdt: 125.45,
          lastUpdated: new Date().toISOString(),
          source: 'default'
        });
      }
    } catch (error) {
      console.error("Error fetching exchange rates:", error);
      res.status(500).json({ message: "Failed to fetch exchange rates" });
    }
  });
  
  // Get all exchange rates (for admin panel)
  app.get("/api/rates/all", requireAuth, async (req, res) => {
    try {
      // Get all exchange rates
      const rates = await db.select().from(exchangeRates).orderBy(desc(exchangeRates.updatedAt));
      res.json(rates);
    } catch (error) {
      console.error("Error fetching all exchange rates:", error);
      res.status(500).json({ message: "Failed to fetch all exchange rates" });
    }
  });
  
  // Update exchange rate (admin only)
  app.post("/api/admin/exchange-rate", requireAdmin, async (req, res) => {
    try {
      const schema = z.object({
        fromCurrency: z.string(),
        toCurrency: z.string(),
        rate: z.number().positive(),
        source: z.string()
      });
      
      const data = schema.parse(req.body);
      
      // Insert new exchange rate correctly matching the schema field names
      const [newRate] = await db.insert(exchangeRates)
        .values({
          fromCurrency: data.fromCurrency,
          toCurrency: data.toCurrency,
          rate: data.rate.toString(),
          source: data.source
        })
        .returning();
      
      res.status(201).json(newRate);
    } catch (error) {
      console.error("Error updating exchange rate:", error);
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid input data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to update exchange rate" });
    }
  });

  // Admin route to fetch exchange rates for configuration page
  app.get("/api/admin/exchange-rates", requireAdmin, async (req, res) => {
    try {
      // Get latest exchange rate from database
      const [latestRate] = await db.select()
        .from(exchangeRates)
        .where(and(
          eq(exchangeRates.fromCurrency, 'USDT'),
          eq(exchangeRates.toCurrency, 'BDT')
        ))
        .orderBy(desc(exchangeRates.updatedAt))
        .limit(1);
      
      if (latestRate) {
        res.json({
          usdtToBdt: parseFloat(latestRate.rate.toString()),
          lastUpdated: latestRate.updatedAt.toISOString(),
          source: latestRate.source
        });
      } else {
        res.json({
          usdtToBdt: 0,
          lastUpdated: null,
          source: null
        });
      }
    } catch (error) {
      console.error("Error fetching admin exchange rates:", error);
      res.status(500).json({ message: "Failed to fetch exchange rates" });
    }
  });

  // Admin route to update exchange rates for sub-agent topup
  app.post("/api/admin/exchange-rates/update", requireAdmin, async (req, res) => {
    try {
      const schema = z.object({
        usdtToBdt: z.number().positive("Exchange rate must be positive")
      });
      
      const { usdtToBdt } = schema.parse(req.body);
      
      // Insert new exchange rate record
      const [newRate] = await db.insert(exchangeRates)
        .values({
          fromCurrency: 'USDT',
          toCurrency: 'BDT',
          rate: usdtToBdt.toString(),
          source: 'admin_manual_update'
        })
        .returning();
      
      res.json({
        usdtToBdt: parseFloat(newRate.rate.toString()),
        lastUpdated: newRate.updatedAt.toISOString(),
        source: newRate.source
      });
    } catch (error) {
      console.error("Error updating admin exchange rates:", error);
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid input data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to update exchange rate" });
    }
  });

  // Get all payment methods (for users and admins)
  app.get("/api/payment-methods", requireAuth, async (req, res) => {
    try {
      // Only return active payment methods for regular users, all methods for admins
      const query = req.user!.role === 'admin' 
        ? db.select().from(paymentMethods)
        : db.select().from(paymentMethods).where(eq(paymentMethods.active, true));
        
      const methods = await query;
      res.json(methods);
    } catch (error) {
      console.error("Error fetching payment methods:", error);
      res.status(500).json({ message: "Failed to fetch payment methods" });
    }
  });

  // Top-up requests
  app.post("/api/topup", requireAuth, async (req, res) => {
    try {
      console.log("Processing top-up request:", req.body);
      
      const schema = z.object({
        amount: z.number().positive(),
        currency: z.string().default("USDT"),
        paymentMethod: z.enum(["binance_pay", "custom_usdt", "bkash", "nagad", "rocket", "bank_transfer"]),
        walletAddress: z.string().optional(),
        accountNumber: z.string().optional(),
        bankDetails: z.string().optional(),
        transactionId: z.string().optional(),
      });

      const data = schema.parse(req.body);
      console.log("Validated data:", data);

      // Process top-up request
      const topupTransaction = await storage.createTopupRequest(req.user!.id, data);
      console.log("Created transaction:", topupTransaction);
      
      // Update user's balance
      const user = await storage.getUser(req.user!.id);
      if (user) {
        const newBalance = Number(user.balance || 0) + (topupTransaction.convertedAmount || 0);
        user.balance = newBalance;
        await storage.updateUser(req.user!.id, { balance: newBalance });
        console.log(`Updated user balance to ${newBalance}`);
        
        // Send notification to the user
        sendNotification(req.user!.id, {
          type: 'transaction',
          action: 'created',
          data: {
            transactionType: 'topup',
            amount: data.amount,
            currency: data.currency,
            status: 'completed',
            timestamp: new Date().toISOString()
          },
          message: `Your ${data.currency} ${data.amount} top-up has been completed.`
        });
      }
      
      // Send notification to all admin users
      const adminUsers = await db.select().from(users).where(eq(users.role, 'admin'));
      adminUsers.forEach(admin => {
        sendNotification(admin.id, {
          type: 'admin_notification',
          action: 'transaction',
          data: {
            userId: req.user!.id,
            username: req.user!.username,
            transactionType: 'topup',
            amount: data.amount,
            currency: data.currency,
            timestamp: new Date().toISOString()
          },
          message: `User ${req.user!.username} has completed a ${data.currency} ${data.amount} top-up.`
        });
      });
      
      res.status(201).json(topupTransaction);
    } catch (error) {
      console.error("Top-up request error:", error);
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid input data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to process top-up request" });
    }
  });
  
  // Withdrawal request
  app.post("/api/withdrawal", requireAuth, async (req, res) => {
    try {
      console.log("Processing withdrawal request:", req.body);
      
      const schema = z.object({
        amount: z.number().positive(),
        withdrawalMethod: z.enum(["bank_transfer", "bkash", "nagad", "rocket", "usdt"]),
        accountNumber: z.string().optional(),
        walletAddress: z.string().optional(),
        bankDetails: z.string().optional(),
      });

      const data = schema.parse(req.body);
      console.log("Validated withdrawal data:", data);

      // Process withdrawal request
      const withdrawalTransaction = await storage.createWithdrawalRequest(req.user!.id, data);
      console.log("Created withdrawal transaction:", withdrawalTransaction);
      
      // Send notification to the user
      sendNotification(req.user!.id, {
        type: 'transaction',
        action: 'created',
        data: {
          transactionType: 'withdrawal',
          amount: data.amount,
          method: data.withdrawalMethod,
          status: 'pending',
          timestamp: new Date().toISOString()
        },
        message: `Your withdrawal request for ${data.amount} BDT has been submitted and is pending approval.`
      });
      
      // Send notification to all admin users
      const adminUsers = await db.select().from(users).where(eq(users.role, 'admin'));
      adminUsers.forEach(admin => {
        sendNotification(admin.id, {
          type: 'admin_notification',
          action: 'transaction',
          data: {
            userId: req.user!.id,
            username: req.user!.username,
            transactionType: 'withdrawal',
            amount: data.amount,
            method: data.withdrawalMethod,
            timestamp: new Date().toISOString()
          },
          message: `User ${req.user!.username} has requested a withdrawal of ${data.amount} BDT.`
        });
      });
      
      res.status(201).json(withdrawalTransaction);
    } catch (error) {
      console.error("Withdrawal request error:", error);
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid input data", errors: error.errors });
      }
      res.status(500).json({ 
        message: "Failed to process withdrawal request", 
        error: error instanceof Error ? error.message : String(error) 
      });
    }
  });
  
  // AI-powered admin payment processing endpoint
  app.post("/api/admin/process-payments", requireAdmin, async (req, res) => {
    try {
      console.log("AI Admin processing payments");
      
      const schema = z.object({
        transactionIds: z.array(z.string()),
        action: z.enum(["approve", "reject"]),
        reason: z.string().optional(),
        useAI: z.boolean().default(false)
      });

      const data = schema.parse(req.body);
      
      // Process payments with AI assistance if requested
      let processedResults = [];
      
      if (data.useAI) {
        // Use OpenAI for intelligent payment fraud detection and processing
        if (!openai) {
          // Check if OpenAI API key is available
          return res.status(400).json({ 
            message: "AI processing is not available. Please provide an OpenAI API key.",
            error: "OPENAI_API_KEY is not set in environment variables." 
          });
        }
        
        // Process each transaction with AI assistance
        for (const txId of data.transactionIds) {
          try {
            // Extract the original ID (remove the prefix)
            const parts = txId.split('-');
            if (parts.length !== 2) {
              throw new Error(`Invalid transaction ID format: ${txId}`);
            }
            
            const type = parts[0]; // "topup", "player", or "withdrawal"
            const id = parseInt(parts[1]);
            
            if (isNaN(id)) {
              throw new Error(`Invalid transaction ID number: ${parts[1]}`);
            }
            
            // Get transaction details for AI analysis
            let transactionDetails: any = null;
            let userDetails: any = null;
            
            if (type === "player") {
              // Get player transaction details
              const playerTransaction = await db.select()
                .from(playerTransactions)
                .where(eq(playerTransactions.id, id))
                .limit(1);
              
              if (playerTransaction.length > 0) {
                transactionDetails = playerTransaction[0];
                // Get user (agent) details
                const agent = await storage.getUser(transactionDetails.agentId);
                userDetails = agent;
              }
            } else if (type === "topup") {
              // Get topup transaction details
              const topupTransaction = await db.select()
                .from(topupTransactions)
                .where(eq(topupTransactions.id, id))
                .limit(1);
              
              if (topupTransaction.length > 0) {
                transactionDetails = topupTransaction[0];
                // Get user details
                const user = await storage.getUser(transactionDetails.userId);
                userDetails = user;
              }
            } else if (type === "withdrawal") {
              // Get withdrawal transaction details
              const withdrawalTransaction = await db.select()
                .from(withdrawalTransactions)
                .where(eq(withdrawalTransactions.id, id))
                .limit(1);
              
              if (withdrawalTransaction.length > 0) {
                transactionDetails = withdrawalTransaction[0];
                // Get user details
                const user = await storage.getUser(transactionDetails.userId);
                userDetails = user;
              }
            }
            
            if (!transactionDetails) {
              processedResults.push({
                id: txId,
                status: "error",
                message: `Transaction not found: ${txId}`
              });
              continue;
            }
            
            // Prepare transaction data for AI analysis
            const transactionData = {
              id: txId,
              type: type,
              amount: transactionDetails.amount,
              createdAt: transactionDetails.createdAt,
              status: transactionDetails.status,
              user: userDetails ? {
                username: userDetails.username,
                role: userDetails.role,
                createdAt: userDetails.createdAt,
                balance: userDetails.balance
              } : null
            };
            
            // Use OpenAI to analyze the transaction
            console.log("Analyzing transaction with OpenAI:", txId);
            const prompt = `
              As an AI payment fraud detection system, analyze this payment transaction and determine if it should be approved or rejected.
              
              Transaction details:
              ${JSON.stringify(transactionData, null, 2)}
              
              Current action requested: ${data.action}
              
              Respond with a detailed analysis including:
              1. Is this transaction suspicious? Why or why not?
              2. Should it be approved or rejected?
              3. A detailed reason for your decision that can be shown to the admin.
              
              Format your response as JSON with the following structure:
              {
                "suspicious": boolean,
                "recommendation": "approve" | "reject",
                "confidence": number (0-1),
                "reason": "string",
                "detailed_analysis": "string"
              }
            `;
            
            const completion = await openai.chat.completions.create({
              model: "gpt-4o", // the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
              messages: [
                { role: "system", content: "You are an expert AI payment fraud detection system for BetWinner Sub-Agent Management System. Your task is to analyze transactions and determine if they are legitimate or suspicious." },
                { role: "user", content: prompt }
              ],
              response_format: { type: "json_object" }
            });
            
            // Parse the AI response
            const aiResponse = JSON.parse(completion.choices[0].message.content);
            console.log("AI analysis:", aiResponse);
            
            // Make decision based on AI recommendation
            const aiDecision = aiResponse.recommendation === "approve";
            const aiReason = aiResponse.reason || (aiDecision ? "AI detected no fraud indicators" : "AI detected suspicious patterns");
            
            // Process transaction based on AI recommendation
            if (type === "player") {
              const result = await storage.approveTransaction(
                id,
                aiDecision,
                `${aiReason} (AI confidence: ${Math.round(aiResponse.confidence * 100)}%)`
              );
              processedResults.push({ 
                id: txId, 
                result, 
                aiAnalysis: {
                  suspicious: aiResponse.suspicious,
                  recommendation: aiResponse.recommendation,
                  confidence: aiResponse.confidence,
                  reason: aiResponse.reason
                }
              });
            } else {
              // For now, just report AI recommendation for other transaction types
              processedResults.push({ 
                id: txId, 
                status: "ai_analyzed",
                message: `AI ${aiResponse.recommendation === "approve" ? "approved" : "rejected"} ${type} transaction`,
                aiAnalysis: {
                  suspicious: aiResponse.suspicious,
                  recommendation: aiResponse.recommendation,
                  confidence: aiResponse.confidence,
                  reason: aiResponse.reason
                }
              });
            }
          } catch (error) {
            console.error(`Error processing transaction ${txId} with AI:`, error);
            processedResults.push({
              id: txId,
              status: "error",
              message: error instanceof Error ? error.message : String(error)
            });
          }
        }
      } else {
        // Manual processing
        for (const txId of data.transactionIds) {
          // Extract the original ID (remove the prefix)
          const parts = txId.split('-');
          if (parts.length !== 2) {
            throw new Error(`Invalid transaction ID format: ${txId}`);
          }
          
          const type = parts[0]; // "topup" or "player"
          const id = parseInt(parts[1]);
          
          if (isNaN(id)) {
            throw new Error(`Invalid transaction ID number: ${parts[1]}`);
          }
          
          if (type === "player") {
            // Process player transactions
            const result = await storage.approveTransaction(
              id, 
              data.action === "approve", 
              data.reason || (data.action === "approve" ? "Admin approved" : "Admin rejected")
            );
            processedResults.push({ id: txId, result });
          } else {
            // For other transaction types
            processedResults.push({ 
              id: txId, 
              status: "not_implemented",
              message: `Processing for ${type} transactions not implemented yet` 
            });
          }
        }
      }
      
      res.status(200).json({ 
        success: true, 
        message: `${data.action}d ${processedResults.length} transactions`, 
        results: processedResults 
      });
    } catch (error) {
      console.error("AI Admin payment processing error:", error);
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid input data", errors: error.errors });
      }
      res.status(500).json({ 
        message: "Failed to process payments", 
        error: error instanceof Error ? error.message : String(error) 
      });
    }
  });

  // Get transactions with unified filtering
  app.get("/api/transactions", requireAuth, async (req, res) => {
    try {
      const { 
        startDate, 
        endDate, 
        type, 
        status, 
        search,
        playerId 
      } = req.query;
      
      // Parse filters from query parameters
      const filters: any = {};
      
      if (startDate) {
        filters.startDate = new Date(startDate as string);
      }
      
      if (endDate) {
        filters.endDate = new Date(endDate as string);
      }
      
      if (type) {
        filters.type = Array.isArray(type) 
          ? type as string[] 
          : [type as string];
      }
      
      if (status) {
        filters.status = Array.isArray(status) 
          ? status as string[] 
          : [status as string];
      }
      
      if (search) {
        filters.search = search as string;
      }
      
      if (playerId) {
        filters.playerId = playerId as string;
      }
      
      console.log(`Getting transactions for user ${req.user!.id} with filters:`, filters);
      const transactions = await storage.getTransactionsByUserId(req.user!.id, filters);
      res.json(transactions);
    } catch (error) {
      console.error("Error fetching transactions:", error);
      res.status(500).json({ message: "Failed to fetch transactions" });
    }
  });

  // Get top-up transactions
  app.get("/api/transactions/topup", requireAuth, async (req, res) => {
    try {
      const transactions = await storage.getTopupTransactionsByUserId(req.user!.id);
      res.json(transactions);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch top-up transactions" });
    }
  });

  // Get players
  app.get("/api/players", requireAuth, async (req, res) => {
    try {
      const players = await storage.getPlayersByAgentId(req.user!.id);
      res.json(players);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch players" });
    }
  });

  // Player deposit request
  app.post("/api/players/deposit", requireAuth, async (req, res) => {
    try {
      console.log("Routes: Processing deposit request:", req.body);
      
      const schema = z.object({
        playerId: z.string(),
        amount: z.number().positive(),
      });

      const data = schema.parse(req.body);
      console.log("Routes: Validated deposit data:", data);
      
      // Use the storage implementation to process the deposit
      const depositRequest = await storage.createPlayerDepositRequest(req.user!.id, data);
      
      // Send notification to the agent
      sendNotification(req.user!.id, {
        type: 'transaction',
        action: 'created',
        data: {
          transactionType: 'player_deposit',
          amount: data.amount,
          playerId: data.playerId,
          timestamp: new Date().toISOString()
        },
        message: `You initiated a player deposit of ${data.amount} BDT.`
      });
      
      // Send notification to all admin users
      const adminUsers = await db.select().from(users).where(eq(users.role, 'admin'));
      adminUsers.forEach(admin => {
        sendNotification(admin.id, {
          type: 'admin_notification',
          action: 'transaction',
          data: {
            userId: req.user!.id,
            username: req.user!.username,
            transactionType: 'player_deposit',
            playerId: data.playerId,
            amount: data.amount,
            timestamp: new Date().toISOString()
          },
          message: `Agent ${req.user!.username} initiated a player deposit of ${data.amount} BDT.`
        });
      });
      
      console.log("Routes: Deposit request processed successfully:", depositRequest);
      res.status(201).json(depositRequest);
    } catch (error) {
      console.error("Routes: Deposit request error:", error);
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid input data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to process deposit request: " + (error as Error).message });
    }
  });

  // Player withdrawal request
  app.post("/api/players/withdrawal", requireAuth, async (req, res) => {
    try {
      console.log("Routes: Processing withdrawal request:", req.body);
      
      const schema = z.object({
        playerId: z.string(),
        amount: z.number().positive(),
        paymentCode: z.string(),
      });

      const data = schema.parse(req.body);
      console.log("Routes: Validated withdrawal data:", data);

      // Use the storage implementation to process the withdrawal
      const withdrawalRequest = await storage.createPlayerWithdrawalRequest(req.user!.id, data);
      
      // Send notification to the agent
      sendNotification(req.user!.id, {
        type: 'transaction',
        action: 'created',
        data: {
          transactionType: 'player_withdrawal',
          amount: data.amount,
          playerId: data.playerId,
          timestamp: new Date().toISOString()
        },
        message: `You initiated a player withdrawal of ${data.amount} BDT.`
      });
      
      // Send notification to all admin users
      const adminUsers = await db.select().from(users).where(eq(users.role, 'admin'));
      adminUsers.forEach(admin => {
        sendNotification(admin.id, {
          type: 'admin_notification',
          action: 'transaction',
          data: {
            userId: req.user!.id,
            username: req.user!.username,
            transactionType: 'player_withdrawal',
            playerId: data.playerId,
            amount: data.amount,
            timestamp: new Date().toISOString()
          },
          message: `Agent ${req.user!.username} initiated a player withdrawal of ${data.amount} BDT.`
        });
      });
      
      console.log("Routes: Withdrawal request processed successfully:", withdrawalRequest);
      res.status(201).json(withdrawalRequest);
    } catch (error) {
      console.error("Routes: Withdrawal request error:", error);
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid input data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to process withdrawal request: " + (error as Error).message });
    }
  });

  // Get commissions history
  app.get("/api/commissions/history", requireAuth, async (req, res) => {
    try {
      const commissions = await storage.getCommissionsByUserId(req.user!.id);
      res.json(commissions);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch commission history" });
    }
  });

  // Get commissions summary
  app.get("/api/commissions/summary", requireAuth, async (req, res) => {
    try {
      const summary = await storage.getCommissionsSummary(req.user!.id);
      res.json(summary);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch commission summary" });
    }
  });

  // Get affiliate data
  app.get("/api/affiliate", requireAuth, async (req, res) => {
    try {
      const affiliate = await storage.getAffiliateData(req.user!.id);
      res.json(affiliate);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch affiliate data" });
    }
  });

  // Get affiliate stats
  app.get("/api/affiliate/stats", requireAuth, async (req, res) => {
    try {
      const stats = await storage.getAffiliateStats(req.user!.id);
      res.json(stats);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch affiliate stats" });
    }
  });

  // Get referred players
  app.get("/api/affiliate/players", requireAuth, async (req, res) => {
    try {
      const players = await storage.getReferredPlayers(req.user!.id);
      res.json(players);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch referred players" });
    }
  });

  // Get support tickets
  app.get("/api/support/tickets", requireAuth, async (req, res) => {
    try {
      const tickets = await storage.getSupportTicketsByUserId(req.user!.id);
      res.json(tickets);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch support tickets" });
    }
  });

  // Create support ticket
  app.post("/api/support/tickets", requireAuth, async (req, res) => {
    try {
      const schema = z.object({
        subject: z.string().min(1),
        message: z.string().min(1),
      });

      const data = schema.parse(req.body);

      // Create ticket
      const ticket = await storage.createSupportTicket(req.user!.id, data);
      
      res.status(201).json(ticket);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid input data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to create support ticket" });
    }
  });

  // Send message to support ticket
  app.post("/api/support/messages", requireAuth, async (req, res) => {
    try {
      const schema = z.object({
        ticketId: z.string(),
        message: z.string().min(1),
      });

      const data = schema.parse(req.body);

      // Send message
      const message = await storage.addSupportTicketMessage(req.user!.id, data);
      
      res.status(201).json(message);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid input data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to send message" });
    }
  });

  // Mark ticket as read
  app.post("/api/support/tickets/:ticketId/read", requireAuth, async (req, res) => {
    try {
      const ticketId = req.params.ticketId;
      
      // Mark as read
      await storage.markSupportTicketAsRead(req.user!.id, ticketId);
      
      res.status(200).json({ success: true });
    } catch (error) {
      res.status(500).json({ message: "Failed to mark ticket as read" });
    }
  });

  // Admin API routes
  // Get all users (admin only)
  app.get("/api/admin/users", requireAdmin, async (req, res) => {
    try {
      // This would typically be in storage.ts but we'll handle it here for simplicity
      const allUsers = await db.select({
        id: users.id,
        username: users.username,
        fullName: users.fullName,
        email: users.email,
        phone: users.phone,
        balance: users.balance,
        agentId: users.agentId,
        role: users.role,
        createdAt: users.createdAt
      }).from(users);
      
      res.json(allUsers);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch users" });
    }
  });
  
  // Update user (admin only)
  app.put("/api/admin/users/:id", requireAdmin, async (req, res) => {
    try {
      const userId = parseInt(req.params.id);
      if (isNaN(userId)) {
        return res.status(400).json({ message: "Invalid user ID" });
      }
      
      const schema = z.object({
        username: z.string().optional(),
        fullName: z.string().optional(),
        email: z.string().email().optional(),
        phone: z.string().optional(),
        role: z.enum(["admin", "agent"]).optional()
      });
      
      const data = schema.parse(req.body);
      
      // Update user
      await db.update(users)
        .set(data)
        .where(eq(users.id, userId));
      
      // Fetch updated user
      const [updatedUser] = await db.select().from(users).where(eq(users.id, userId));
      
      res.json(updatedUser);
    } catch (error) {
      console.error("Error updating user:", error);
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid input data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to update user" });
    }
  });
  
  // Delete user (admin only)
  app.delete("/api/admin/users/:id", requireAdmin, async (req, res) => {
    try {
      const userId = parseInt(req.params.id);
      if (isNaN(userId)) {
        return res.status(400).json({ message: "Invalid user ID" });
      }
      
      // Don't allow deleting yourself
      if (userId === req.user!.id) {
        return res.status(400).json({ message: "Cannot delete your own account" });
      }
      
      // Delete user
      await db.delete(users).where(eq(users.id, userId));
      
      res.json({ success: true });
    } catch (error) {
      console.error("Error deleting user:", error);
      res.status(500).json({ message: "Failed to delete user" });
    }
  });
  
  // Add funds to user (admin only)
  app.post("/api/admin/users/:id/add-funds", requireAdmin, async (req, res) => {
    try {
      const userId = parseInt(req.params.id);
      if (isNaN(userId)) {
        return res.status(400).json({ message: "Invalid user ID" });
      }
      
      const schema = z.object({
        amount: z.number().positive(),
        currency: z.string().default("USDT"),
        notes: z.string().optional()
      });
      
      const data = schema.parse(req.body);
      
      // Get current user balance
      const [user] = await db.select().from(users).where(eq(users.id, userId));
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      
      // Calculate new balance
      const currentBalance = parseFloat(user.balance?.toString() || "0");
      const newBalance = currentBalance + data.amount;
      
      // Update user balance
      await db.update(users)
        .set({ balance: newBalance })
        .where(eq(users.id, userId));
      
      // Create transaction record
      const [transaction] = await db.insert(topupTransactions)
        .values({
          userId: userId,
          amount: data.amount.toString(),
          currency: data.currency || "USDT",
          convertedAmount: data.amount.toString(),
          paymentMethod: "admin_adjustment", // Correct field name is paymentMethod not method
          status: "completed",
          createdAt: new Date(),
          updatedAt: new Date()
        })
        .returning();
      
      // Send notification to the user that got funds added
      sendNotification(userId, {
        type: 'transaction',
        action: 'admin_funds',
        data: {
          amount: data.amount,
          currency: data.currency,
          newBalance: newBalance,
          timestamp: new Date().toISOString()
        },
        message: `Admin added ${data.amount} ${data.currency} to your balance. New balance: ${newBalance} ${data.currency}.`
      });
      
      // Notify all other admins
      const adminUsers = await db.select().from(users).where(eq(users.role, 'admin'));
      adminUsers.forEach(admin => {
        if (admin.id !== req.user!.id) { // Don't notify the admin who did the action
          sendNotification(admin.id, {
            type: 'admin_notification',
            action: 'admin_funds',
            data: {
              userId: userId,
              adminId: req.user!.id,
              adminUsername: req.user!.username,
              amount: data.amount,
              currency: data.currency,
              timestamp: new Date().toISOString()
            },
            message: `Admin ${req.user!.username} added ${data.amount} ${data.currency} to user ID ${userId}.`
          });
        }
      });
      
      res.status(201).json({
        success: true,
        transaction,
        newBalance
      });
    } catch (error) {
      console.error("Error adding funds to user:", error);
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid input data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to add funds to user" });
    }
  });

  // Get all transactions (admin only)
  app.get("/api/admin/transactions", requireAdmin, async (req, res) => {
    try {
      // Fetch all top-up transactions
      const topupTxs = await db.select().from(topupTransactions);
      
      // Fetch all player transactions
      const playerTxs = await db.select().from(playerTransactions);
      
      res.json({
        topupTransactions: topupTxs,
        playerTransactions: playerTxs
      });
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch transactions" });
    }
  });
  
  // Get all transactions unified view with filtering (admin only)
  app.get("/api/admin/all-transactions", requireAdmin, async (req, res) => {
    try {
      const { 
        startDate, 
        endDate, 
        type, 
        status, 
        search,
        agentId,
        playerId
      } = req.query;
      
      // Parse filters from query parameters
      const filters: any = {};
      
      if (startDate) {
        filters.startDate = new Date(startDate as string);
      }
      
      if (endDate) {
        filters.endDate = new Date(endDate as string);
      }
      
      if (type) {
        filters.type = Array.isArray(type) 
          ? type as string[] 
          : [type as string];
      }
      
      if (status) {
        filters.status = Array.isArray(status) 
          ? status as string[] 
          : [status as string];
      }
      
      if (search) {
        filters.search = search as string;
      }
      
      if (agentId) {
        filters.agentId = parseInt(agentId as string);
      }
      
      if (playerId) {
        filters.playerId = playerId as string;
      }
      
      const transactions = await storage.getAllTransactions(filters);
      res.json(transactions);
    } catch (error) {
      console.error("Error fetching all transactions:", error);
      res.status(500).json({ message: "Failed to fetch transactions" });
    }
  });
  
  // Get pending transactions (admin only)
  app.get("/api/admin/transactions/pending", requireAdmin, async (req, res) => {
    try {
      const pendingTransactions = await storage.getPendingTransactions();
      res.json(pendingTransactions);
    } catch (error) {
      console.error("Error fetching pending transactions:", error);
      res.status(500).json({ message: "Failed to fetch pending transactions" });
    }
  });
  
  // Chat API endpoints
  // Get chat messages
  app.get("/api/chat/messages", requireAuth, async (req, res) => {
    try {
      // Get messages where user is either sender or recipient (to admin) or admin sees all
      if (req.user!.role === 'admin') {
        // Admin sees all messages
        const messages = await db.select({
          id: chatMessages.id,
          senderId: chatMessages.senderId,
          senderName: users.username,
          recipientId: chatMessages.recipientId,
          message: chatMessages.message,
          read: chatMessages.read,
          timestamp: chatMessages.timestamp
        })
        .from(chatMessages)
        .innerJoin(users, eq(chatMessages.senderId, users.id))
        .orderBy(chatMessages.timestamp);
        
        res.json(messages);
      } else {
        // Regular users only see their messages
        const messages = await db.select({
          id: chatMessages.id,
          senderId: chatMessages.senderId,
          senderName: users.username,
          recipientId: chatMessages.recipientId,
          message: chatMessages.message,
          read: chatMessages.read,
          timestamp: chatMessages.timestamp
        })
        .from(chatMessages)
        .innerJoin(users, eq(chatMessages.senderId, users.id))
        .where(
          or(
            eq(chatMessages.senderId, req.user!.id),
            eq(chatMessages.recipientId, req.user!.id)
          )
        )
        .orderBy(chatMessages.timestamp);
        
        res.json(messages);
      }
    } catch (error) {
      console.error("Error fetching chat messages:", error);
      res.status(500).json({ message: "Failed to fetch chat messages" });
    }
  });
  
  // Send a chat message
  app.post("/api/chat/messages", requireAuth, async (req, res) => {
    try {
      const schema = z.object({
        recipientId: z.number().optional(),
        message: z.string().min(1)
      });
      
      const data = schema.parse(req.body);
      
      // For non-admin users, messages always go to admins
      let recipientId = data.recipientId;
      if (req.user!.role !== 'admin' && !recipientId) {
        // Find an admin user
        const [adminUser] = await db.select({
          id: users.id
        })
        .from(users)
        .where(eq(users.role, 'admin'))
        .limit(1);
        
        if (adminUser) {
          recipientId = adminUser.id;
        }
      }
      
      // Insert message
      const [newMessage] = await db.insert(chatMessages)
        .values({
          senderId: req.user!.id,
          recipientId: recipientId,
          message: data.message,
          read: false,
          timestamp: new Date()
        })
        .returning();
      
      // Get sender name for response
      const [sender] = await db.select({
        username: users.username
      })
      .from(users)
      .where(eq(users.id, req.user!.id));
      
      res.status(201).json({
        ...newMessage,
        senderName: sender?.username
      });
    } catch (error) {
      console.error("Error sending chat message:", error);
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid input data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to send chat message" });
    }
  });
  
  // Mark chat messages as read
  app.post("/api/chat/messages/read", requireAuth, async (req, res) => {
    try {
      const schema = z.object({
        messageIds: z.array(z.number())
      });
      
      const { messageIds } = schema.parse(req.body);
      
      // Update messages
      await db.update(chatMessages)
        .set({ read: true })
        .where(
          and(
            inArray(chatMessages.id, messageIds),
            eq(chatMessages.recipientId, req.user!.id)
          )
        );
      
      res.status(200).json({ success: true });
    } catch (error) {
      console.error("Error marking chat messages as read:", error);
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid input data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to mark chat messages as read" });
    }
  });
  
  // Payment Methods API endpoints
  // Get payment methods
  app.get("/api/payment-methods", requireAuth, async (req, res) => {
    try {
      const methods = await db.select()
        .from(paymentMethods)
        .where(eq(paymentMethods.active, true));
      
      res.json(methods);
    } catch (error) {
      console.error("Error fetching payment methods:", error);
      res.status(500).json({ message: "Failed to fetch payment methods" });
    }
  });
  
  // Admin: Create payment method
  app.post("/api/admin/payment-methods", requireAdmin, async (req, res) => {
    try {
      const schema = z.object({
        type: z.string(),
        name: z.string(),
        details: z.any(),
        purpose: z.string().default("agent_topup"),
        active: z.boolean().optional()
      });
      
      const data = schema.parse(req.body);
      
      // Insert new payment method
      const [newMethod] = await db.insert(paymentMethods)
        .values({
          type: data.type,
          name: data.name,
          details: data.details,
          purpose: data.purpose,
          active: data.active ?? true,
          createdAt: new Date(),
          updatedAt: new Date()
        })
        .returning();
      
      res.status(201).json(newMethod);
    } catch (error) {
      console.error("Error creating payment method:", error);
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid input data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to create payment method" });
    }
  });
  
  // Update payment method
  app.patch("/api/admin/payment-methods/:id", requireAdmin, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid payment method ID" });
      }
      
      const schema = z.object({
        type: z.string().optional(),
        name: z.string().optional(),
        details: z.any().optional(),
        purpose: z.string().optional(),
        active: z.boolean().optional()
      });
      
      const data = schema.parse(req.body);
      
      // Update payment method
      const [updatedMethod] = await db.update(paymentMethods)
        .set({
          ...(data.type && { type: data.type }),
          ...(data.name && { name: data.name }),
          ...(data.details && { details: data.details }),
          ...(data.purpose && { purpose: data.purpose }),
          ...(data.active !== undefined && { active: data.active }),
          updatedAt: new Date()
        })
        .where(eq(paymentMethods.id, id))
        .returning();
      
      if (!updatedMethod) {
        return res.status(404).json({ message: "Payment method not found" });
      }
      
      res.json(updatedMethod);
    } catch (error) {
      console.error("Error updating payment method:", error);
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid input data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to update payment method" });
    }
  });
  
  // Delete payment method
  app.delete("/api/admin/payment-methods/:id", requireAdmin, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid payment method ID" });
      }
      
      // Delete the payment method
      await db.delete(paymentMethods).where(eq(paymentMethods.id, id));
      
      res.json({ success: true, message: "Payment method deleted successfully" });
    } catch (error) {
      console.error("Error deleting payment method:", error);
      res.status(500).json({ message: "Failed to delete payment method" });
    }
  });
  
  // Approve or reject a transaction (admin only)
  app.post("/api/admin/transactions/:transactionId/process", requireAdmin, async (req, res) => {
    try {
      const transactionIdStr = req.params.transactionId;
      // Parse transactionId properly - don't use parseInt for IDs that might have prefixes
      let originalId;
      
      if (transactionIdStr.startsWith('player-') || transactionIdStr.startsWith('topup-')) {
        originalId = parseInt(transactionIdStr.split('-')[1]);
        if (isNaN(originalId)) {
          return res.status(400).json({ message: "Invalid transaction ID format" });
        }
      } else {
        originalId = parseInt(transactionIdStr);
        if (isNaN(originalId)) {
          return res.status(400).json({ message: "Invalid transaction ID" });
        }
      }
      
      const schema = z.object({
        approve: z.boolean(),
        reason: z.string().optional()
      });
      
      const data = schema.parse(req.body);
      console.log(`Processing transaction ${transactionIdStr} (original ID: ${originalId}): ${data.approve ? 'approve' : 'reject'}`);
      
      const result = await storage.approveTransaction(
        originalId, 
        data.approve, 
        data.reason || (data.approve ? "Approved by admin" : "Rejected by admin")
      );
      
      // If we have a transaction with an owner, notify them about the status change
      if (result && result.userId) {
        sendNotification(result.userId, {
          type: 'transaction',
          action: 'status_update',
          data: {
            transactionId: transactionIdStr, // Use the original string ID
            originalId: originalId, // Include the numeric ID for reference
            status: data.approve ? 'approved' : 'rejected',
            reason: data.reason || (data.approve ? "Approved by admin" : "Rejected by admin"),
            timestamp: new Date().toISOString()
          },
          message: `Your transaction has been ${data.approve ? 'approved' : 'rejected'}${data.reason ? ': ' + data.reason : ''}.`
        });
      }
      
      // Notify other admins
      const adminUsers = await db.select().from(users).where(eq(users.role, 'admin'));
      adminUsers.forEach(admin => {
        if (admin.id !== req.user!.id) { // Don't notify the admin who performed the action
          sendNotification(admin.id, {
            type: 'admin_notification',
            action: 'transaction_status_update',
            data: {
              transactionId: transactionIdStr, // Use the original string ID
              originalId: originalId, // Include the numeric ID for reference
              status: data.approve ? 'approved' : 'rejected',
              reason: data.reason || (data.approve ? "Approved by admin" : "Rejected by admin"),
              adminId: req.user!.id,
              adminUsername: req.user!.username,
              timestamp: new Date().toISOString()
            },
            message: `Admin ${req.user!.username} has ${data.approve ? 'approved' : 'rejected'} transaction #${transactionIdStr}.`
          });
        }
      });
      
      res.json(result);
    } catch (error) {
      console.error("Error processing transaction:", error);
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid input data", errors: error.errors });
      }
      res.status(500).json({ 
        message: "Failed to process transaction", 
        error: (error as Error).message 
      });
    }
  });

  // Update user role (admin only)
  app.patch("/api/admin/users/:userId/role", requireAdmin, async (req, res) => {
    try {
      const userId = parseInt(req.params.userId);
      const schema = z.object({
        role: z.enum(["admin", "agent"])
      });

      const data = schema.parse(req.body);
      
      await db.update(users)
        .set({ role: data.role })
        .where(eq(users.id, userId));
      
      res.json({ success: true });
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid role", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to update user role" });
    }
  });

  // Get dashboard stats (admin only)
  app.get("/api/admin/dashboard", requireAdmin, async (req, res) => {
    try {
      // Count total users
      const [userCount] = await db.select({ count: count() }).from(users);
      
      // Count total players
      const [playerCount] = await db.select({ count: count() }).from(players);
      
      // Sum deposits
      const [depositSum] = await db.select({
        sum: sum(playerTransactions.amount)
      }).from(playerTransactions)
        .where(eq(playerTransactions.type, "deposit"));
      
      // Sum withdrawals
      const [withdrawalSum] = await db.select({
        sum: sum(playerTransactions.amount)
      }).from(playerTransactions)
        .where(eq(playerTransactions.type, "withdrawal"));
      
      res.json({
        userCount: userCount.count,
        playerCount: playerCount.count,
        totalDeposits: Number(depositSum.sum || 0),
        totalWithdrawals: Number(withdrawalSum.sum || 0)
      });
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch dashboard stats" });
    }
  });
  
  //=======================================
  // Remittance API Routes
  //=======================================
  
  // Get all remittance fees (admin only)
  app.get("/api/admin/remittance-fees", requireAdmin, async (req, res) => {
    try {
      const fees = await storage.getRemittanceFees();
      res.json(fees);
    } catch (error) {
      console.error("Error fetching remittance fees:", error);
      res.status(500).json({ message: "Failed to fetch remittance fees" });
    }
  });
  
  // Get remittance fee by ID (admin only)
  app.get("/api/admin/remittance-fees/:id", requireAdmin, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid fee ID" });
      }
      
      const fee = await storage.getRemittanceFeeById(id);
      
      if (!fee) {
        return res.status(404).json({ message: "Remittance fee not found" });
      }
      
      res.json(fee);
    } catch (error) {
      console.error("Error fetching remittance fee:", error);
      res.status(500).json({ message: "Failed to fetch remittance fee" });
    }
  });
  
  // Create a new remittance fee (admin only)
  app.post("/api/admin/remittance-fees", requireAdmin, async (req, res) => {
    try {
      // Define schema for fee creation
      const schema = z.object({
        name: z.string(),
        description: z.string().optional(),
        channel: z.enum(["npsb_bank", "bkash", "nagad", "rocket"]),
        feeType: z.enum(["flat", "percentage", "hybrid"]),
        flatFee: z.number().min(0).optional(),
        percentageFee: z.number().min(0).optional(),
        minAmount: z.number().min(0).optional(),
        maxAmount: z.number().min(0).optional().nullable(),
        active: z.boolean().default(true)
      });
      
      const data = schema.parse(req.body);
      
      // Validate based on fee type
      if (data.feeType === "flat" && (data.flatFee === undefined || data.flatFee < 0)) {
        return res.status(400).json({ message: "Flat fee is required for fee type 'flat'" });
      }
      
      if (data.feeType === "percentage" && (data.percentageFee === undefined || data.percentageFee < 0)) {
        return res.status(400).json({ message: "Percentage fee is required for fee type 'percentage'" });
      }
      
      if (data.feeType === "hybrid" && (
        data.flatFee === undefined || data.flatFee < 0 || 
        data.percentageFee === undefined || data.percentageFee < 0
      )) {
        return res.status(400).json({ 
          message: "Both flat fee and percentage fee are required for fee type 'hybrid'" 
        });
      }
      
      // Convert numbers to strings for database storage
      const feeData = {
        ...data,
        flatFee: data.flatFee !== undefined ? data.flatFee.toString() : null,
        percentageFee: data.percentageFee !== undefined ? data.percentageFee.toString() : null,
        minAmount: data.minAmount !== undefined ? data.minAmount.toString() : null,
        maxAmount: data.maxAmount !== undefined ? data.maxAmount.toString() : null
      };
      
      const newFee = await storage.createRemittanceFee(feeData);
      res.status(201).json(newFee);
    } catch (error) {
      console.error("Error creating remittance fee:", error);
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid input data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to create remittance fee" });
    }
  });
  
  // Update a remittance fee (admin only)
  app.put("/api/admin/remittance-fees/:id", requireAdmin, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid fee ID" });
      }
      
      // Define schema for fee update
      const schema = z.object({
        name: z.string().optional(),
        description: z.string().optional(),
        channel: z.enum(["npsb_bank", "bkash", "nagad", "rocket"]).optional(),
        feeType: z.enum(["flat", "percentage", "hybrid"]).optional(),
        flatFee: z.number().min(0).optional(),
        percentageFee: z.number().min(0).optional(),
        minAmount: z.number().min(0).optional(),
        maxAmount: z.number().min(0).optional().nullable(),
        active: z.boolean().optional()
      });
      
      const data = schema.parse(req.body);
      
      // Convert numbers to strings for database storage
      const updateData: any = { ...data };
      if (data.flatFee !== undefined) updateData.flatFee = data.flatFee.toString();
      if (data.percentageFee !== undefined) updateData.percentageFee = data.percentageFee.toString();
      if (data.minAmount !== undefined) updateData.minAmount = data.minAmount.toString();
      if (data.maxAmount !== undefined) updateData.maxAmount = data.maxAmount !== null ? data.maxAmount.toString() : null;
      
      const updatedFee = await storage.updateRemittanceFee(id, updateData);
      
      if (!updatedFee) {
        return res.status(404).json({ message: "Remittance fee not found" });
      }
      
      res.json(updatedFee);
    } catch (error) {
      console.error("Error updating remittance fee:", error);
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid input data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to update remittance fee" });
    }
  });
  
  // Delete a remittance fee (admin only)
  app.delete("/api/admin/remittance-fees/:id", requireAdmin, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid fee ID" });
      }
      
      const success = await storage.deleteRemittanceFee(id);
      
      if (!success) {
        return res.status(404).json({ message: "Remittance fee not found or could not be deleted" });
      }
      
      res.json({ success: true, message: "Remittance fee deleted successfully" });
    } catch (error) {
      console.error("Error deleting remittance fee:", error);
      res.status(500).json({ message: "Failed to delete remittance fee" });
    }
  });
  
  // Get applicable remittance fees for a specific channel (for agents when creating remittance requests)
  app.get("/api/remittance-fees/:channel", requireAuth, async (req, res) => {
    try {
      const channel = req.params.channel;
      console.log(`Fetching fees for channel: ${channel}`);
      
      if (!["npsb_bank", "bkash", "nagad", "rocket"].includes(channel)) {
        return res.status(400).json({ message: "Invalid channel" });
      }
      
      // Get active fees for the specified channel
      const fees = await db.select()
        .from(remittanceFees)
        .where(and(
          eq(remittanceFees.channel, channel as any),
          eq(remittanceFees.active, true)
        ));
      
      console.log(`Found ${fees.length} active fees for channel ${channel}:`, fees);
      
      if (fees.length === 0) {
        // If no fees found, create a default fee for this channel
        console.log(`No fees found for channel ${channel}. Creating a default fee.`);
        
        const defaultFee = {
          channel: channel as any,
          name: `Default ${channel} Fee`,
          feeType: "flat",
          flatFee: "10.00", // Default 10 BDT flat fee
          active: true,
          description: "Default fee automatically created by the system"
        };
        
        const [newFee] = await db.insert(remittanceFees)
          .values(defaultFee)
          .returning();
        
        console.log("Created default fee:", newFee);
        
        return res.json([newFee]);
      }
      
      res.json(fees);
    } catch (error) {
      console.error("Error fetching channel remittance fees:", error);
      res.status(500).json({ message: "Failed to fetch remittance fees" });
    }
  });
  
  // Create a remittance request (for agents)
  app.post("/api/remittance", requireAuth, async (req, res) => {
    try {
      // Define schema for remittance request
      const schema = z.object({
        recipientChannel: z.enum(["npsb_bank", "bkash", "nagad", "rocket"]),
        recipientName: z.string().min(3, "Recipient name is required").optional(),
        recipientAccount: z.string().min(5, "Valid recipient account number is required"),
        recipientAdditionalInfo: z.any().optional(),
        amount: z.number().positive("Amount must be positive"),
        notes: z.string().optional()
      });
      
      const data = schema.parse(req.body);
      
      // Process remittance request
      const remittanceTransaction = await storage.createRemittanceRequest(req.user!.id, data);
      
      // Send notification to the agent
      sendNotification(req.user!.id, {
        type: 'transaction',
        action: 'created',
        data: {
          transactionType: 'remittance',
          amount: data.amount,
          recipientChannel: data.recipientChannel,
          status: 'pending',
          timestamp: new Date().toISOString()
        },
        message: `Your remittance request for ${data.amount} BDT ${data.recipientName ? `to ${data.recipientName}` : ''} has been submitted and is pending approval.`
      });
      
      // Send notification to all admin users
      const adminUsers = await db.select().from(users).where(eq(users.role, 'admin'));
      adminUsers.forEach(admin => {
        sendNotification(admin.id, {
          type: 'admin_notification',
          action: 'remittance',
          data: {
            userId: req.user!.id,
            username: req.user!.username,
            transactionType: 'remittance',
            amount: data.amount,
            recipientChannel: data.recipientChannel,
            timestamp: new Date().toISOString()
          },
          message: `Agent ${req.user!.username} has submitted a remittance request for ${data.amount} BDT. Review required.`
        });
      });
      
      res.status(201).json(remittanceTransaction);
    } catch (error) {
      console.error("Remittance request error:", error);
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid input data", errors: error.errors });
      }
      if (error instanceof Error && error.message.includes("Insufficient balance")) {
        return res.status(400).json({ message: error.message });
      }
      res.status(500).json({ message: "Failed to process remittance request" });
    }
  });
  
  // Get agent's remittance transactions
  app.get("/api/remittance/transactions", requireAuth, async (req, res) => {
    try {
      const transactions = await storage.getRemittanceTransactionsByAgentId(req.user!.id);
      res.json(transactions);
    } catch (error) {
      console.error("Error fetching remittance transactions:", error);
      res.status(500).json({ message: "Failed to fetch remittance transactions" });
    }
  });
  
  // Get pending remittance transactions (admin only)
  app.get("/api/admin/remittance/pending", requireAdmin, async (req, res) => {
    try {
      const transactions = await storage.getPendingRemittanceTransactions();
      res.json(transactions);
    } catch (error) {
      console.error("Error fetching pending remittance transactions:", error);
      res.status(500).json({ message: "Failed to fetch pending remittance transactions" });
    }
  });
  
  // Approve or reject a remittance transaction (admin only)
  app.post("/api/admin/remittance/:transactionId/process", requireAdmin, async (req, res) => {
    try {
      const transactionId = parseInt(req.params.transactionId);
      
      if (isNaN(transactionId)) {
        return res.status(400).json({ message: "Invalid transaction ID" });
      }
      
      const schema = z.object({
        approve: z.boolean(),
        reason: z.string().optional(),
        transactionNumber: z.string().optional()
      });
      
      const data = schema.parse(req.body);
      
      // Process the remittance transaction
      const result = await storage.approveRemittanceTransaction(
        transactionId,
        data.approve,
        data.reason || (data.approve ? "Approved by admin" : "Rejected by admin"),
        req.user!.id,
        data.transactionNumber
      );
      
      // Get the agent for notification
      const [agent] = await db.select().from(users).where(eq(users.id, result.agentId));
      
      // Send notification to the agent
      if (agent) {
        sendNotification(agent.id, {
          type: 'transaction',
          action: 'updated',
          data: {
            transactionType: 'remittance',
            transactionId: result.id,
            status: result.status,
            timestamp: new Date().toISOString()
          },
          message: data.approve 
            ? `Your remittance transaction #${result.id} has been approved. Transaction Number: ${result.transactionNumber}.` 
            : `Your remittance transaction #${result.id} has been rejected: ${data.reason || "Rejected by admin"}.`
        });
      }
      
      res.json(result);
    } catch (error) {
      console.error("Error processing remittance transaction:", error);
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid input data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to process remittance transaction" });
    }
  });

  // Achievement system endpoints
  
  // Get all achievements
  app.get("/api/achievements", requireAuth, async (req, res) => {
    try {
      const achievements = await storage.getAchievements();
      res.json(achievements);
    } catch (error) {
      console.error("Error fetching achievements:", error);
      res.status(500).json({ message: "Failed to fetch achievements" });
    }
  });
  
  // Get user achievements
  app.get("/api/user/achievements", requireAuth, async (req, res) => {
    try {
      const userAchievements = await storage.getUserAchievements(req.user!.id);
      res.json(userAchievements);
    } catch (error) {
      console.error("Error fetching user achievements:", error);
      res.status(500).json({ message: "Failed to fetch user achievements" });
    }
  });
  
  // Get user achievement summary (counts and points)
  app.get("/api/user/achievements/summary", requireAuth, async (req, res) => {
    try {
      const summary = await storage.getUserAchievementSummary(req.user!.id);
      res.json(summary);
    } catch (error) {
      console.error("Error fetching achievement summary:", error);
      res.status(500).json({ message: "Failed to fetch achievement summary" });
    }
  });
  
  // Manually track achievement progress (useful for testing)
  app.post("/api/user/achievements/track", requireAuth, async (req, res) => {
    try {
      const schema = z.object({
        category: z.enum(["transaction_volume", "player_acquisition", "retention", "consistency", "special"]),
        action: z.string(),
        value: z.number().optional()
      });
      
      const data = schema.parse(req.body);
      
      const updatedAchievements = await storage.trackAchievementProgress(
        req.user!.id,
        data.category,
        data.action,
        data.value
      );
      
      res.json(updatedAchievements);
    } catch (error) {
      console.error("Error tracking achievement progress:", error);
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid input data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to track achievement progress" });
    }
  });
  
  // Admin routes for achievement management
  
  // Get achievement by ID
  app.get("/api/admin/achievements/:id", requireAdmin, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid achievement ID" });
      }
      
      const achievement = await storage.getAchievementById(id);
      if (!achievement) {
        return res.status(404).json({ message: "Achievement not found" });
      }
      
      res.json(achievement);
    } catch (error) {
      console.error("Error fetching achievement:", error);
      res.status(500).json({ message: "Failed to fetch achievement" });
    }
  });
  
  // Create new achievement
  app.post("/api/admin/achievements", requireAdmin, async (req, res) => {
    try {
      const schema = z.object({
        title: z.string().min(3, "Title must be at least 3 characters"),
        description: z.string().min(5, "Description must be at least 5 characters"),
        category: z.enum(["transaction_volume", "player_acquisition", "retention", "consistency", "special"]),
        difficulty: z.enum(["bronze", "silver", "gold", "platinum", "diamond"]),
        pointsAwarded: z.number().int().min(1, "Points must be at least 1"),
        icon: z.string(),
        requirement: z.record(z.any()),
        isActive: z.boolean().default(true)
      });
      
      const data = schema.parse(req.body);
      const achievement = await storage.createAchievement(data);
      
      res.status(201).json(achievement);
    } catch (error) {
      console.error("Error creating achievement:", error);
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid input data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to create achievement" });
    }
  });
  
  // Update achievement
  app.put("/api/admin/achievements/:id", requireAdmin, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid achievement ID" });
      }
      
      const schema = z.object({
        title: z.string().min(3, "Title must be at least 3 characters").optional(),
        description: z.string().min(5, "Description must be at least 5 characters").optional(),
        category: z.enum(["transaction_volume", "player_acquisition", "retention", "consistency", "special"]).optional(),
        difficulty: z.enum(["bronze", "silver", "gold", "platinum", "diamond"]).optional(),
        pointsAwarded: z.number().int().min(1, "Points must be at least 1").optional(),
        icon: z.string().optional(),
        requirement: z.record(z.any()).optional(),
        isActive: z.boolean().optional()
      });
      
      const data = schema.parse(req.body);
      const achievement = await storage.updateAchievement(id, data);
      
      if (!achievement) {
        return res.status(404).json({ message: "Achievement not found" });
      }
      
      res.json(achievement);
    } catch (error) {
      console.error("Error updating achievement:", error);
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid input data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to update achievement" });
    }
  });
  
  // Delete achievement
  app.delete("/api/admin/achievements/:id", requireAdmin, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid achievement ID" });
      }
      
      const success = await storage.deleteAchievement(id);
      if (!success) {
        return res.status(404).json({ message: "Achievement not found" });
      }
      
      res.status(204).end();
    } catch (error) {
      console.error("Error deleting achievement:", error);
      res.status(500).json({ message: "Failed to delete achievement" });
    }
  });

  return httpServer;
}

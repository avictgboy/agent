import { db } from "./db";
import { 
  User, InsertUser, users, 
  topupTransactions, withdrawalTransactions, 
  players, playerTransactions, commissions, 
  supportTickets, supportMessages, remittanceFees, 
  remittanceTransactions, RemittanceFee, RemittanceTransaction,
  Achievement, UserAchievement, InsertAchievement, InsertUserAchievement,
  achievements, userAchievements
} from "@shared/schema";
import { IStorage, TopUpRequest, WithdrawalRequest, RemittanceRequest, TransactionFilter } from "./storage";
import { eq, and, between, or, like, desc, gt, lt, SQL, sql } from "drizzle-orm";
import session from "express-session";
import connectPgSimple from "connect-pg-simple";
import { pool } from "./db";

const PostgresSessionStore = connectPgSimple(session);

export class DatabaseStorage implements IStorage {
  sessionStore: any; // Using any for better compatibility

  constructor() {
    try {
      this.sessionStore = new PostgresSessionStore({
        pool,
        tableName: "sessions",
        createTableIfMissing: true,
        schemaName: "public"
      });
      console.log("Session store initialized with sessions table creation enabled");
    } catch (error) {
      console.error("Error initializing session store:", error);
      // Fallback to memory store if database store fails
      const MemoryStore = require('memorystore')(session);
      this.sessionStore = new MemoryStore({
        checkPeriod: 86400000 // 24 hours
      });
      console.log("Using fallback memory store for sessions due to database error");
    }
  }

  // User operations
  async getUser(id: number): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user || undefined;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.username, username));
    return user || undefined;
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values(insertUser)
      .returning();
    return user;
  }

  async updateUser(id: number, userData: Partial<User>): Promise<User | undefined> {
    const [updatedUser] = await db
      .update(users)
      .set(userData)
      .where(eq(users.id, id))
      .returning();
    return updatedUser;
  }

  // Top-up operations
  async createTopupRequest(userId: number, data: TopUpRequest): Promise<any> {
    const [transaction] = await db
      .insert(topupTransactions)
      .values({
        userId,
        amount: data.amount.toString(),
        currency: data.currency,
        paymentMethod: data.paymentMethod,
        walletAddress: data.walletAddress,
        accountNumber: data.accountNumber,
        bankDetails: data.bankDetails,
        transactionId: data.transactionId,
      })
      .returning();
    return transaction;
  }

  // Withdrawal operations
  async createWithdrawalRequest(userId: number, data: WithdrawalRequest): Promise<any> {
    const [transaction] = await db
      .insert(withdrawalTransactions)
      .values({
        userId,
        amount: data.amount.toString(),
        withdrawalMethod: data.withdrawalMethod,
        accountNumber: data.accountNumber,
        walletAddress: data.walletAddress,
        bankDetails: data.bankDetails,
      })
      .returning();
    return transaction;
  }

  // Transaction operations
  async getTransactionsByUserId(userId: number, filters?: TransactionFilter): Promise<any[]> {
    let conditions = [eq(topupTransactions.userId, userId)];
    
    if (filters?.startDate && filters?.endDate) {
      conditions.push(between(topupTransactions.createdAt, filters.startDate, filters.endDate));
    } else if (filters?.startDate) {
      conditions.push(gt(topupTransactions.createdAt, filters.startDate));
    } else if (filters?.endDate) {
      conditions.push(lt(topupTransactions.createdAt, filters.endDate));
    }
    
    if (filters?.status && filters.status.length > 0) {
      conditions.push(or(...filters.status.map(status => eq(topupTransactions.status, status))));
    }
    
    const topups = await db
      .select()
      .from(topupTransactions)
      .where(and(...conditions))
      .orderBy(desc(topupTransactions.createdAt));
    
    // Now get withdrawals
    let withdrawalConditions = [eq(withdrawalTransactions.userId, userId)];
    
    if (filters?.startDate && filters?.endDate) {
      withdrawalConditions.push(between(withdrawalTransactions.createdAt, filters.startDate, filters.endDate));
    } else if (filters?.startDate) {
      withdrawalConditions.push(gt(withdrawalTransactions.createdAt, filters.startDate));
    } else if (filters?.endDate) {
      withdrawalConditions.push(lt(withdrawalTransactions.createdAt, filters.endDate));
    }
    
    if (filters?.status && filters.status.length > 0) {
      withdrawalConditions.push(or(...filters.status.map(status => eq(withdrawalTransactions.status, status))));
    }
    
    const withdrawals = await db
      .select()
      .from(withdrawalTransactions)
      .where(and(...withdrawalConditions))
      .orderBy(desc(withdrawalTransactions.createdAt));
    
    // Combine and add type field for frontend
    const topupsWithType = topups.map(t => ({ ...t, type: "topup" }));
    const withdrawalsWithType = withdrawals.map(w => ({ ...w, type: "withdrawal" }));
    
    // Combine and sort by createdAt
    const transactions = [...topupsWithType, ...withdrawalsWithType];
    transactions.sort((a, b) => 
      new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
    );
    
    return transactions;
  }

  async getPendingTransactions(): Promise<any[]> {
    try {
      // Get pending topup transactions with user details
      const topups = await db
        .select({
          ...topupTransactions,
          username: users.username,
          role: users.role
        })
        .from(topupTransactions)
        .where(eq(topupTransactions.status, "pending"))
        .leftJoin(users, eq(topupTransactions.userId, users.id))
        .orderBy(desc(topupTransactions.createdAt));
      
      // Get pending withdrawal transactions with user details
      const withdrawals = await db
        .select({
          ...withdrawalTransactions,
          username: users.username,
          role: users.role
        })
        .from(withdrawalTransactions)
        .where(eq(withdrawalTransactions.status, "pending"))
        .leftJoin(users, eq(withdrawalTransactions.userId, users.id))
        .orderBy(desc(withdrawalTransactions.createdAt));

      // Get pending player transactions
      let playerTxs: any[] = [];
      try {
        playerTxs = await db
          .select({
            id: playerTransactions.id,
            agentId: playerTransactions.agentId,
            playerId: playerTransactions.playerId,
            type: playerTransactions.type,
            amount: playerTransactions.amount,
            status: playerTransactions.status,
            paymentCode: playerTransactions.paymentCode,
            statusReason: playerTransactions.statusReason,
            createdAt: playerTransactions.createdAt,
            updatedAt: playerTransactions.updatedAt,
            username: users.username,
            role: users.role
          })
          .from(playerTransactions)
          .where(eq(playerTransactions.status, "pending"))
          .leftJoin(users, eq(playerTransactions.agentId, users.id))
          .orderBy(desc(playerTransactions.createdAt));
      } catch (error) {
        console.error("Error fetching player transactions:", error);
      }

      // Get pending remittance transactions
      let remittanceTxs: any[] = [];
      try {
        remittanceTxs = await db
          .select({
            id: remittanceTransactions.id,
            agentId: remittanceTransactions.agentId,
            amount: remittanceTransactions.amount,
            status: remittanceTransactions.status,
            recipientChannel: remittanceTransactions.recipientChannel,
            recipientName: remittanceTransactions.recipientName,
            recipientAccount: remittanceTransactions.recipientAccount,
            statusReason: remittanceTransactions.statusReason,
            notes: remittanceTransactions.notes,
            createdAt: remittanceTransactions.createdAt,
            updatedAt: remittanceTransactions.updatedAt,
            username: users.username,
            role: users.role
          })
          .from(remittanceTransactions)
          .where(eq(remittanceTransactions.status, "pending"))
          .leftJoin(users, eq(remittanceTransactions.agentId, users.id))
          .orderBy(desc(remittanceTransactions.createdAt));
      } catch (error) {
        console.error("Error fetching remittance transactions:", error);
      }
      
      // Combine and add type field
      const topupsWithType = topups.map(t => ({ 
        ...t, 
        transactionType: "topup",
        type: "topup",
        agentUsername: t.username,
        paymentCode: t.transactionId || null,
        date: new Date(t.createdAt).toLocaleDateString(),
        time: new Date(t.createdAt).toLocaleTimeString(),
      }));
      
      const withdrawalsWithType = withdrawals.map(w => ({ 
        ...w, 
        transactionType: "withdrawal",
        type: "withdrawal",
        agentUsername: w.username,
        paymentCode: w.transactionId || null,
        date: new Date(w.createdAt).toLocaleDateString(),
        time: new Date(w.createdAt).toLocaleTimeString(),
      }));

      const playerDepositsWithType = playerTxs
        .filter(p => p.type === "deposit")
        .map(p => ({
          ...p,
          transactionType: "player_deposit",
          type: "player_deposit",
          agentUsername: p.username,
          date: new Date(p.createdAt).toLocaleDateString(),
          time: new Date(p.createdAt).toLocaleTimeString(),
        }));

      const playerWithdrawalsWithType = playerTxs
        .filter(p => p.type === "withdrawal")
        .map(p => ({
          ...p,
          transactionType: "player_withdrawal",
          type: "player_withdrawal",
          agentUsername: p.username,
          date: new Date(p.createdAt).toLocaleDateString(),
          time: new Date(p.createdAt).toLocaleTimeString(),
        }));

      const remittancesWithType = remittanceTxs.map(r => ({
        ...r,
        transactionType: "remittance",
        type: "remittance",
        agentUsername: r.username,
        date: new Date(r.createdAt).toLocaleDateString(),
        time: new Date(r.createdAt).toLocaleTimeString(),
      }));
      
      // Combine and sort by createdAt
      const transactions = [
        ...topupsWithType, 
        ...withdrawalsWithType,
        ...playerDepositsWithType,
        ...playerWithdrawalsWithType,
        ...remittancesWithType
      ];

      transactions.sort((a, b) => {
        const dateA = a.createdAt ? new Date(a.createdAt).getTime() : 0;
        const dateB = b.createdAt ? new Date(b.createdAt).getTime() : 0;
        return dateB - dateA;
      });
      
      return transactions;
    } catch (error) {
      console.error("Error in getPendingTransactions:", error);
      return [];
    }
  }

  async getAllTransactions(filters?: TransactionFilter): Promise<any[]> {
    try {
      let topupConditions: SQL[] = [];
      let withdrawalConditions: SQL[] = [];
      let playerTxConditions: SQL[] = [];
      let remittanceConditions: SQL[] = [];
      
      // Apply date filters
      if (filters?.startDate && filters?.endDate) {
        topupConditions.push(between(topupTransactions.createdAt, filters.startDate, filters.endDate));
        withdrawalConditions.push(between(withdrawalTransactions.createdAt, filters.startDate, filters.endDate));
        playerTxConditions.push(between(playerTransactions.createdAt, filters.startDate, filters.endDate));
        remittanceConditions.push(between(remittanceTransactions.createdAt, filters.startDate, filters.endDate));
      } else if (filters?.startDate) {
        topupConditions.push(gt(topupTransactions.createdAt, filters.startDate));
        withdrawalConditions.push(gt(withdrawalTransactions.createdAt, filters.startDate));
        playerTxConditions.push(gt(playerTransactions.createdAt, filters.startDate));
        remittanceConditions.push(gt(remittanceTransactions.createdAt, filters.startDate));
      } else if (filters?.endDate) {
        topupConditions.push(lt(topupTransactions.createdAt, filters.endDate));
        withdrawalConditions.push(lt(withdrawalTransactions.createdAt, filters.endDate));
        playerTxConditions.push(lt(playerTransactions.createdAt, filters.endDate));
        remittanceConditions.push(lt(remittanceTransactions.createdAt, filters.endDate));
      }
      
      // Apply status filters
      if (filters?.status && filters.status.length > 0) {
        const statusConditions = filters.status.map(status => eq(topupTransactions.status, status));
        if (statusConditions.length > 0) {
          topupConditions.push(or(...statusConditions));
        }
        
        const withdrawalStatusConditions = filters.status.map(status => eq(withdrawalTransactions.status, status));
        if (withdrawalStatusConditions.length > 0) {
          withdrawalConditions.push(or(...withdrawalStatusConditions));
        }
        
        const playerStatusConditions = filters.status.map(status => eq(playerTransactions.status, status));
        if (playerStatusConditions.length > 0) {
          playerTxConditions.push(or(...playerStatusConditions));
        }
        
        const remittanceStatusConditions = filters.status.map(status => eq(remittanceTransactions.status, status));
        if (remittanceStatusConditions.length > 0) {
          remittanceConditions.push(or(...remittanceStatusConditions));
        }
      }
      
      // Apply type filters
      if (filters?.type && filters.type.length > 0) {
        // Skip other transaction types if only specific ones are requested
        const types = filters.type.map(t => t.toLowerCase());
        
        // Get topup transactions
        const topups = !types.length || types.includes('topup') 
          ? await db
              .select({
                id: topupTransactions.id,
                userId: topupTransactions.userId,
                amount: topupTransactions.amount,
                currency: topupTransactions.currency,
                paymentMethod: topupTransactions.paymentMethod,
                walletAddress: topupTransactions.walletAddress,
                accountNumber: topupTransactions.accountNumber,
                bankDetails: topupTransactions.bankDetails,
                transactionId: topupTransactions.transactionId,
                status: topupTransactions.status,
                statusReason: topupTransactions.statusReason,
                createdAt: topupTransactions.createdAt,
                updatedAt: topupTransactions.updatedAt,
                username: users.username,
                fullName: users.fullName,
                email: users.email,
                phone: users.phone,
              })
              .from(topupTransactions)
              .innerJoin(users, eq(topupTransactions.userId, users.id))
              .where(topupConditions.length ? and(...topupConditions) : sql`1=1`)
              .orderBy(desc(topupTransactions.createdAt))
          : [];
        
        // Get withdrawal transactions
        const withdrawals = !types.length || types.includes('withdrawal') 
          ? await db
              .select({
                id: withdrawalTransactions.id,
                userId: withdrawalTransactions.userId,
                amount: withdrawalTransactions.amount,
                withdrawalMethod: withdrawalTransactions.withdrawalMethod,
                walletAddress: withdrawalTransactions.walletAddress,
                accountNumber: withdrawalTransactions.accountNumber,
                bankDetails: withdrawalTransactions.bankDetails,
                transactionId: withdrawalTransactions.transactionId,
                status: withdrawalTransactions.status,
                statusReason: withdrawalTransactions.statusReason,
                createdAt: withdrawalTransactions.createdAt,
                updatedAt: withdrawalTransactions.updatedAt,
                username: users.username,
                fullName: users.fullName,
                email: users.email,
                phone: users.phone,
              })
              .from(withdrawalTransactions)
              .innerJoin(users, eq(withdrawalTransactions.userId, users.id))
              .where(withdrawalConditions.length ? and(...withdrawalConditions) : sql`1=1`)
              .orderBy(desc(withdrawalTransactions.createdAt))
          : [];
        
        // Get player transactions
        let playerDeposits: any[] = [];
        let playerWithdrawals: any[] = [];
        
        if (!types.length || types.includes('player_deposit') || types.includes('player_withdrawal')) {
          try {
            const playerTxs = await db
              .select({
                id: playerTransactions.id,
                agentId: playerTransactions.agentId,
                playerId: playerTransactions.playerId,
                type: playerTransactions.type,
                amount: playerTransactions.amount,
                status: playerTransactions.status,
                paymentCode: playerTransactions.paymentCode,
                statusReason: playerTransactions.statusReason,
                createdAt: playerTransactions.createdAt,
                updatedAt: playerTransactions.updatedAt,
                username: users.username,
                fullName: users.fullName,
                email: users.email,
                phone: users.phone
              })
              .from(playerTransactions)
              .innerJoin(users, eq(playerTransactions.agentId, users.id))
              .where(playerTxConditions.length ? and(...playerTxConditions) : sql`1=1`)
              .orderBy(desc(playerTransactions.createdAt));
              
            if (!types.length || types.includes('player_deposit')) {
              playerDeposits = playerTxs.filter(p => p.type === 'deposit');
            }
              
            if (!types.length || types.includes('player_withdrawal')) {
              playerWithdrawals = playerTxs.filter(p => p.type === 'withdrawal');
            }
          } catch (error) {
            console.error("Error fetching player transactions for history:", error);
          }
        }
        
        // Get remittance transactions
        let remittances: any[] = [];
        if (!types.length || types.includes('remittance')) {
          try {
            remittances = await db
              .select({
                id: remittanceTransactions.id,
                agentId: remittanceTransactions.agentId,
                amount: remittanceTransactions.amount,
                status: remittanceTransactions.status,
                recipientChannel: remittanceTransactions.recipientChannel,
                recipientName: remittanceTransactions.recipientName,
                recipientAccount: remittanceTransactions.recipientAccount,
                statusReason: remittanceTransactions.statusReason,
                notes: remittanceTransactions.notes,
                createdAt: remittanceTransactions.createdAt,
                updatedAt: remittanceTransactions.updatedAt,
                username: users.username,
                fullName: users.fullName,
                email: users.email,
                phone: users.phone
              })
              .from(remittanceTransactions)
              .innerJoin(users, eq(remittanceTransactions.agentId, users.id))
              .where(remittanceConditions.length ? and(...remittanceConditions) : sql`1=1`)
              .orderBy(desc(remittanceTransactions.createdAt));
          } catch (error) {
            console.error("Error fetching remittance transactions for history:", error);
          }
        }
        
        // Format transactions with proper types and common fields
        const topupsWithType = topups.map(t => ({ 
          ...t, 
          transactionType: "topup",
          type: "topup",
          date: new Date(t.createdAt).toLocaleDateString(),
          time: new Date(t.createdAt).toLocaleTimeString(),
          timestamp: t.createdAt,
          originalId: t.id // Keep original ID for reference
        }));
        
        const withdrawalsWithType = withdrawals.map(w => ({ 
          ...w, 
          transactionType: "withdrawal",
          type: "withdrawal",
          date: new Date(w.createdAt).toLocaleDateString(),
          time: new Date(w.createdAt).toLocaleTimeString(),
          timestamp: w.createdAt,
          originalId: w.id
        }));
        
        const playerDepositsWithType = playerDeposits.map(p => ({
          ...p,
          transactionType: "player_deposit",
          type: "player_deposit",
          date: new Date(p.createdAt).toLocaleDateString(),
          time: new Date(p.createdAt).toLocaleTimeString(),
          timestamp: p.createdAt,
          originalId: p.id
        }));
        
        const playerWithdrawalsWithType = playerWithdrawals.map(p => ({
          ...p,
          transactionType: "player_withdrawal",
          type: "player_withdrawal",
          date: new Date(p.createdAt).toLocaleDateString(),
          time: new Date(p.createdAt).toLocaleTimeString(),
          timestamp: p.createdAt,
          originalId: p.id
        }));
        
        const remittancesWithType = remittances.map(r => ({
          ...r,
          transactionType: "remittance",
          type: "remittance",
          date: new Date(r.createdAt).toLocaleDateString(),
          time: new Date(r.createdAt).toLocaleTimeString(),
          timestamp: r.createdAt,
          originalId: r.id
        }));
        
        // Combine all transaction types
        const transactions = [
          ...topupsWithType,
          ...withdrawalsWithType,
          ...playerDepositsWithType,
          ...playerWithdrawalsWithType,
          ...remittancesWithType
        ];
        
        // Apply agent filter
        let filteredTransactions = transactions;
        if (filters?.agentId) {
          filteredTransactions = transactions.filter(t => 
            (t.userId && t.userId === filters.agentId) || 
            (t.agentId && t.agentId === filters.agentId)
          );
        }
        
        // Apply player filter
        if (filters?.playerId) {
          filteredTransactions = filteredTransactions.filter(t => 
            t.playerId && t.playerId === filters.playerId
          );
        }
        
        // Apply search filter
        if (filters?.search && filters.search.trim()) {
          const searchTerm = filters.search.trim().toLowerCase();
          filteredTransactions = filteredTransactions.filter(t => 
            (t.username && t.username.toLowerCase().includes(searchTerm)) ||
            (t.id && t.id.toString().includes(searchTerm)) ||
            (t.playerId && t.playerId.toString().includes(searchTerm)) ||
            (t.status && t.status.toLowerCase().includes(searchTerm)) ||
            (t.transactionId && t.transactionId.toLowerCase().includes(searchTerm)) ||
            (t.recipientName && t.recipientName.toLowerCase().includes(searchTerm))
          );
        }
        
        // Sort by timestamp (handling unknown types safely)
        filteredTransactions.sort((a, b) => {
          const dateA = a.timestamp ? new Date(a.timestamp).getTime() : 0;
          const dateB = b.timestamp ? new Date(b.timestamp).getTime() : 0;
          return dateB - dateA;
        });
        
        return filteredTransactions;
      } else {
        // If no type filter, we need to fetch all transaction types
        // Get all transaction types and process them
        
        // Get topup transactions
        const topups = await db
          .select({
            id: topupTransactions.id,
            userId: topupTransactions.userId,
            amount: topupTransactions.amount,
            currency: topupTransactions.currency,
            paymentMethod: topupTransactions.paymentMethod,
            walletAddress: topupTransactions.walletAddress,
            accountNumber: topupTransactions.accountNumber,
            bankDetails: topupTransactions.bankDetails,
            transactionId: topupTransactions.transactionId,
            status: topupTransactions.status,
            statusReason: topupTransactions.statusReason,
            createdAt: topupTransactions.createdAt,
            updatedAt: topupTransactions.updatedAt,
            username: users.username,
            fullName: users.fullName,
            email: users.email,
            phone: users.phone,
          })
          .from(topupTransactions)
          .innerJoin(users, eq(topupTransactions.userId, users.id))
          .where(topupConditions.length ? and(...topupConditions) : sql`1=1`)
          .orderBy(desc(topupTransactions.createdAt));
        
        // Get withdrawal transactions
        const withdrawals = await db
          .select({
            id: withdrawalTransactions.id,
            userId: withdrawalTransactions.userId,
            amount: withdrawalTransactions.amount,
            withdrawalMethod: withdrawalTransactions.withdrawalMethod,
            walletAddress: withdrawalTransactions.walletAddress,
            accountNumber: withdrawalTransactions.accountNumber,
            bankDetails: withdrawalTransactions.bankDetails,
            transactionId: withdrawalTransactions.transactionId,
            status: withdrawalTransactions.status,
            statusReason: withdrawalTransactions.statusReason,
            createdAt: withdrawalTransactions.createdAt,
            updatedAt: withdrawalTransactions.updatedAt,
            username: users.username,
            fullName: users.fullName,
            email: users.email,
            phone: users.phone,
          })
          .from(withdrawalTransactions)
          .innerJoin(users, eq(withdrawalTransactions.userId, users.id))
          .where(withdrawalConditions.length ? and(...withdrawalConditions) : sql`1=1`)
          .orderBy(desc(withdrawalTransactions.createdAt));
        
        // Get player transactions
        let playerDeposits: any[] = [];
        let playerWithdrawals: any[] = [];
        
        try {
          const playerTxs = await db
            .select({
              id: playerTransactions.id,
              agentId: playerTransactions.agentId,
              playerId: playerTransactions.playerId,
              type: playerTransactions.type,
              amount: playerTransactions.amount,
              status: playerTransactions.status,
              paymentCode: playerTransactions.paymentCode,
              statusReason: playerTransactions.statusReason,
              createdAt: playerTransactions.createdAt,
              updatedAt: playerTransactions.updatedAt,
              username: users.username,
              fullName: users.fullName,
              email: users.email,
              phone: users.phone
            })
            .from(playerTransactions)
            .innerJoin(users, eq(playerTransactions.agentId, users.id))
            .where(playerTxConditions.length ? and(...playerTxConditions) : sql`1=1`)
            .orderBy(desc(playerTransactions.createdAt));
            
          playerDeposits = playerTxs.filter(p => p.type === 'deposit');
          playerWithdrawals = playerTxs.filter(p => p.type === 'withdrawal');
        } catch (error) {
          console.error("Error fetching player transactions for history:", error);
        }
        
        // Get remittance transactions
        let remittances: any[] = [];
        try {
          remittances = await db
            .select({
              id: remittanceTransactions.id,
              agentId: remittanceTransactions.agentId,
              amount: remittanceTransactions.amount,
              status: remittanceTransactions.status,
              recipientChannel: remittanceTransactions.recipientChannel,
              recipientName: remittanceTransactions.recipientName,
              recipientAccount: remittanceTransactions.recipientAccount,
              statusReason: remittanceTransactions.statusReason,
              notes: remittanceTransactions.notes,
              createdAt: remittanceTransactions.createdAt,
              updatedAt: remittanceTransactions.updatedAt,
              username: users.username,
              fullName: users.fullName,
              email: users.email,
              phone: users.phone
            })
            .from(remittanceTransactions)
            .innerJoin(users, eq(remittanceTransactions.agentId, users.id))
            .where(remittanceConditions.length ? and(...remittanceConditions) : sql`1=1`)
            .orderBy(desc(remittanceTransactions.createdAt));
        } catch (error) {
          console.error("Error fetching remittance transactions for history:", error);
        }
        
        // Format transactions with proper types and common fields
        const topupsWithType = topups.map(t => ({ 
          ...t, 
          transactionType: "topup",
          type: "topup",
          date: t.createdAt ? new Date(t.createdAt).toLocaleDateString() : '',
          time: t.createdAt ? new Date(t.createdAt).toLocaleTimeString() : '',
          timestamp: t.createdAt,
          originalId: t.id
        }));
        
        const withdrawalsWithType = withdrawals.map(w => ({ 
          ...w, 
          transactionType: "withdrawal",
          type: "withdrawal", 
          date: w.createdAt ? new Date(w.createdAt).toLocaleDateString() : '',
          time: w.createdAt ? new Date(w.createdAt).toLocaleTimeString() : '',
          timestamp: w.createdAt,
          originalId: w.id
        }));
        
        const playerDepositsWithType = playerDeposits.map(p => ({
          ...p,
          transactionType: "player_deposit",
          type: "player_deposit",
          date: p.createdAt ? new Date(p.createdAt).toLocaleDateString() : '',
          time: p.createdAt ? new Date(p.createdAt).toLocaleTimeString() : '',
          timestamp: p.createdAt,
          originalId: p.id
        }));
        
        const playerWithdrawalsWithType = playerWithdrawals.map(p => ({
          ...p,
          transactionType: "player_withdrawal",
          type: "player_withdrawal",
          date: p.createdAt ? new Date(p.createdAt).toLocaleDateString() : '',
          time: p.createdAt ? new Date(p.createdAt).toLocaleTimeString() : '',
          timestamp: p.createdAt,
          originalId: p.id
        }));
        
        const remittancesWithType = remittances.map(r => ({
          ...r,
          transactionType: "remittance",
          type: "remittance",
          date: r.createdAt ? new Date(r.createdAt).toLocaleDateString() : '',
          time: r.createdAt ? new Date(r.createdAt).toLocaleTimeString() : '',
          timestamp: r.createdAt,
          originalId: r.id
        }));
        
        const allTransactions = [
          ...topupsWithType,
          ...withdrawalsWithType,
          ...playerDepositsWithType,
          ...playerWithdrawalsWithType,
          ...remittancesWithType
        ];
        
        // Apply sorting and filtering
        let filteredResults = allTransactions;
        
        // Apply agent filter
        if (filters?.agentId) {
          filteredResults = filteredResults.filter(t => 
            (t.userId && t.userId === filters.agentId) || 
            (t.agentId && t.agentId === filters.agentId)
          );
        }
        
        // Apply player filter
        if (filters?.playerId) {
          filteredResults = filteredResults.filter(t => 
            t.playerId && t.playerId === filters.playerId
          );
        }
        
        // Apply search filter
        if (filters?.search && filters.search.trim()) {
          const searchTerm = filters.search.trim().toLowerCase();
          filteredResults = filteredResults.filter(t => 
            (t.username && t.username.toLowerCase().includes(searchTerm)) ||
            (t.id && t.id.toString().includes(searchTerm)) ||
            (t.playerId && t.playerId?.toString().includes(searchTerm)) ||
            (t.status && t.status.toLowerCase().includes(searchTerm)) ||
            (t.transactionId && t.transactionId?.toLowerCase().includes(searchTerm)) ||
            (t.recipientName && t.recipientName?.toLowerCase().includes(searchTerm))
          );
        }
        
        // Sort by timestamp
        filteredResults.sort((a, b) => {
          const dateA = a.timestamp ? new Date(a.timestamp).getTime() : 0;
          const dateB = b.timestamp ? new Date(b.timestamp).getTime() : 0;
          return dateB - dateA;
        });
        
        return filteredResults;
      }
    } catch (error) {
      console.error("Error in getAllTransactions:", error);
      return [];
    }
  }

  async isTopupTransaction(transactionId: number): Promise<boolean> {
    const [topup] = await db
      .select()
      .from(topupTransactions)
      .where(eq(topupTransactions.id, transactionId));
    
    return !!topup;
  }

  async approveTransaction(transactionId: number, approve: boolean, reason: string): Promise<any> {
    // First determine transaction type
    const isTopup = await this.isTopupTransaction(transactionId);
    
    if (isTopup) {
      return this.approveTopupTransaction(db, transactionId, approve, reason);
    } else {
      // Handle withdrawal transaction
      const [transaction] = await db
        .select()
        .from(withdrawalTransactions)
        .where(eq(withdrawalTransactions.id, transactionId));
      
      if (!transaction) {
        throw new Error("Transaction not found");
      }
      
      // Update transaction status
      const [updatedTransaction] = await db
        .update(withdrawalTransactions)
        .set({
          status: approve ? "approved" : "rejected",
          statusReason: reason,
        })
        .where(eq(withdrawalTransactions.id, transactionId))
        .returning();
      
      // If approved, update user balance
      if (approve) {
        // Reduce user balance for withdrawals
        await db
          .update(users)
          .set({
            balance: sql`balance - ${transaction.amount}`
          })
          .where(eq(users.id, transaction.userId));
      }
      
      return updatedTransaction;
    }
  }

  private async approveTopupTransaction(tx: any, transactionId: number, approve: boolean, reason: string): Promise<any> {
    const [transaction] = await tx
      .select()
      .from(topupTransactions)
      .where(eq(topupTransactions.id, transactionId));
    
    if (!transaction) {
      throw new Error("Transaction not found");
    }
    
    // Update transaction status
    const [updatedTransaction] = await tx
      .update(topupTransactions)
      .set({
        status: approve ? "approved" : "rejected",
      })
      .where(eq(topupTransactions.id, transactionId))
      .returning();
    
    // If approved, update user balance
    if (approve) {
      await tx
        .update(users)
        .set({
          balance: sql`balance + ${transaction.amount}`
        })
        .where(eq(users.id, transaction.userId));
    }
    
    return updatedTransaction;
  }

  async getTopupTransactionsByUserId(userId: number): Promise<any[]> {
    return db
      .select()
      .from(topupTransactions)
      .where(eq(topupTransactions.userId, userId))
      .orderBy(desc(topupTransactions.createdAt));
  }

  // Player operations
  async getPlayersByAgentId(agentId: number): Promise<any[]> {
    return db
      .select()
      .from(players)
      .where(eq(players.agentId, agentId))
      .orderBy(desc(players.registrationDate));
  }

  async createPlayerDepositRequest(agentId: number, data: any): Promise<any> {
    const [transaction] = await db
      .insert(playerTransactions)
      .values({
        agentId,
        playerId: data.playerId,
        type: "deposit",
        amount: data.amount.toString(),
        paymentCode: data.paymentCode || null,
        status: "pending",
      })
      .returning();
    
    return transaction;
  }

  async createPlayerWithdrawalRequest(agentId: number, data: any): Promise<any> {
    const [transaction] = await db
      .insert(playerTransactions)
      .values({
        agentId,
        playerId: data.playerId,
        type: "withdrawal",
        amount: data.amount.toString(),
        paymentCode: data.paymentCode || null,
        status: "pending",
      })
      .returning();
    
    return transaction;
  }

  // Commission operations
  async getCommissionsByUserId(userId: number): Promise<any[]> {
    return db
      .select()
      .from(commissions)
      .where(eq(commissions.agentId, userId))
      .orderBy(desc(commissions.createdAt));
  }

  async getCommissionsSummary(userId: number): Promise<any> {
    const commissionData = await db
      .select()
      .from(commissions)
      .where(eq(commissions.agentId, userId));
    
    // Calculate summary
    let totalCommission = 0;
    let pendingCommission = 0;
    let paidCommission = 0;
    
    commissionData.forEach(commission => {
      const amount = Number(commission.commission);
      totalCommission += amount;
      
      if (commission.isPaid) {
        paidCommission += amount;
      } else {
        pendingCommission += amount;
      }
    });
    
    return {
      totalCommission,
      pendingCommission,
      paidCommission,
      count: commissionData.length,
    };
  }

  // Affiliate operations
  async getAffiliateData(userId: number): Promise<any> {
    const user = await this.getUser(userId);
    if (!user) {
      throw new Error("User not found");
    }
    
    const playerCount = await db
      .select({ count: db.fn.count() })
      .from(players)
      .where(eq(players.agentId, userId));
    
    const transactionCount = await db
      .select({ count: db.fn.count() })
      .from(playerTransactions)
      .where(eq(playerTransactions.agentId, userId));
    
    const commissions = await this.getCommissionsSummary(userId);
    
    return {
      agentId: user.agentId,
      promoCode: user.promoCode,
      players: Number(playerCount[0].count) || 0,
      transactions: Number(transactionCount[0].count) || 0,
      commissions,
    };
  }

  async getAffiliateStats(userId: number): Promise<any> {
    // Get player data
    const players = await db
      .select()
      .from(players)
      .where(eq(players.agentId, userId));
    
    // Get transaction data
    const transactions = await db
      .select()
      .from(playerTransactions)
      .where(eq(playerTransactions.agentId, userId));
    
    // Calculate transaction totals
    let totalDeposits = 0;
    let totalWithdrawals = 0;
    
    transactions.forEach(transaction => {
      const amount = Number(transaction.amount);
      if (transaction.type === "deposit") {
        totalDeposits += amount;
      } else if (transaction.type === "withdrawal") {
        totalWithdrawals += amount;
      }
    });
    
    // Calculate active players
    const activePlayers = players.filter(player => player.isActive).length;
    
    // Get commissions
    const commissions = await this.getCommissionsSummary(userId);
    
    return {
      playerCount: players.length,
      activePlayers,
      totalDeposits,
      totalWithdrawals,
      transactionCount: transactions.length,
      ...commissions,
    };
  }

  async getReferredPlayers(userId: number): Promise<any[]> {
    return db
      .select()
      .from(players)
      .where(eq(players.agentId, userId))
      .orderBy(desc(players.registrationDate));
  }

  // Support ticket operations
  async getSupportTicketsByUserId(userId: number): Promise<any[]> {
    const tickets = await db
      .select()
      .from(supportTickets)
      .where(eq(supportTickets.userId, userId))
      .orderBy(desc(supportTickets.lastActivity));
    
    // For each ticket, get the last message to show a preview
    const ticketsWithMessages = await Promise.all(
      tickets.map(async (ticket) => {
        const messages = await db
          .select()
          .from(supportMessages)
          .where(eq(supportMessages.ticketId, ticket.id))
          .orderBy(desc(supportMessages.createdAt))
          .limit(1);
        
        const unreadMessages = await db
          .select({ count: db.fn.count() })
          .from(supportMessages)
          .where(
            and(
              eq(supportMessages.ticketId, ticket.id),
              eq(supportMessages.sender, "admin"),
              eq(supportMessages.read, false)
            )
          );
        
        return {
          ...ticket,
          lastMessage: messages[0] || null,
          unreadCount: Number(unreadMessages[0].count) || 0,
        };
      })
    );
    
    return ticketsWithMessages;
  }

  async createSupportTicket(userId: number, data: any): Promise<any> {
    const [ticket] = await db
      .insert(supportTickets)
      .values({
        userId,
        subject: data.subject,
        status: "open",
      })
      .returning();
    
    // Add initial message
    if (data.message) {
      await db
        .insert(supportMessages)
        .values({
          ticketId: ticket.id,
          sender: "user",
          content: data.message,
        });
    }
    
    return ticket;
  }

  async addSupportTicketMessage(userId: number, data: any): Promise<any> {
    // First verify user owns the ticket
    const [ticket] = await db
      .select()
      .from(supportTickets)
      .where(
        and(
          eq(supportTickets.id, data.ticketId),
          eq(supportTickets.userId, userId)
        )
      );
    
    if (!ticket) {
      throw new Error("Ticket not found or not owned by the user");
    }
    
    // Add message
    const [message] = await db
      .insert(supportMessages)
      .values({
        ticketId: data.ticketId,
        sender: "user",
        content: data.message,
      })
      .returning();
    
    // Update ticket's lastActivity
    await db
      .update(supportTickets)
      .set({
        lastActivity: new Date(),
        status: "open", // Reopen ticket if it was closed
      })
      .where(eq(supportTickets.id, data.ticketId));
    
    return message;
  }

  async markSupportTicketAsRead(userId: number, ticketId: string): Promise<void> {
    // First verify user owns the ticket
    const [ticket] = await db
      .select()
      .from(supportTickets)
      .where(
        and(
          eq(supportTickets.id, parseInt(ticketId)),
          eq(supportTickets.userId, userId)
        )
      );
    
    if (!ticket) {
      throw new Error("Ticket not found or not owned by the user");
    }
    
    // Mark all admin messages as read
    await db
      .update(supportMessages)
      .set({ read: true })
      .where(
        and(
          eq(supportMessages.ticketId, parseInt(ticketId)),
          eq(supportMessages.sender, "admin"),
          eq(supportMessages.read, false)
        )
      );
  }

  // Remittance operations
  async getRemittanceFees(): Promise<RemittanceFee[]> {
    return db
      .select()
      .from(remittanceFees)
      .where(eq(remittanceFees.active, true))
      .orderBy(remittanceFees.channel);
  }

  async getRemittanceFeeById(id: number): Promise<RemittanceFee | undefined> {
    const [fee] = await db
      .select()
      .from(remittanceFees)
      .where(eq(remittanceFees.id, id));
    
    return fee;
  }

  async createRemittanceFee(data: any): Promise<RemittanceFee> {
    const [fee] = await db
      .insert(remittanceFees)
      .values(data)
      .returning();
    
    return fee;
  }

  async updateRemittanceFee(id: number, data: Partial<RemittanceFee>): Promise<RemittanceFee | undefined> {
    const [updatedFee] = await db
      .update(remittanceFees)
      .set(data)
      .where(eq(remittanceFees.id, id))
      .returning();
    
    return updatedFee;
  }

  async deleteRemittanceFee(id: number): Promise<boolean> {
    const result = await db
      .delete(remittanceFees)
      .where(eq(remittanceFees.id, id));
    
    return !!result;
  }

  async createRemittanceRequest(agentId: number, data: RemittanceRequest): Promise<RemittanceTransaction> {
    try {
      // Calculate fee if applicable
      let feeId = null;
      let feeAmount = 0;
      let totalAmount = Number(data.amount);
      
      // Validate amount
      if (isNaN(totalAmount) || totalAmount <= 0) {
        throw new Error("Invalid remittance amount");
      }
      
      // Get fee configuration for this channel
      const [fee] = await db
        .select()
        .from(remittanceFees)
        .where(
          and(
            eq(remittanceFees.channel, data.recipientChannel),
            eq(remittanceFees.active, true)
          )
        );
      
      if (fee) {
        feeId = fee.id;
        
        if (fee.feeType === "flat") {
          feeAmount = Number(fee.flatFee) || 0;
        } else if (fee.feeType === "percentage") {
          feeAmount = (Number(data.amount) * (Number(fee.percentageFee) || 0)) / 100;
        } else if (fee.feeType === "hybrid") {
          feeAmount = (Number(fee.flatFee) || 0) + ((Number(data.amount) * (Number(fee.percentageFee) || 0)) / 100);
        }
        
        totalAmount += feeAmount;
      }
      
      // Check if agent has sufficient balance before creating the transaction
      const agent = await this.getUser(agentId);
      if (!agent) {
        throw new Error("Agent not found");
      }
      
      const agentBalance = Number(agent.balance) || 0;
      if (agentBalance < totalAmount) {
        throw new Error("Insufficient balance for remittance transaction");
      }
      
      // Create the transaction
      const [transaction] = await db
        .insert(remittanceTransactions)
        .values({
          agentId,
          recipientChannel: data.recipientChannel,
          recipientName: data.recipientName || "",
          recipientAccount: data.recipientAccount,
          recipientAdditionalInfo: data.recipientAdditionalInfo || null,
          amount: data.amount.toString(),
          feeId: feeId,
          feeAmount: feeAmount.toString(),
          totalAmount: totalAmount.toString(),
          notes: data.notes || null,
          status: "pending",
        })
        .returning();
      
      // Deduct from user's balance
      await db
        .update(users)
        .set({
          balance: sql`balance - ${totalAmount}`
        })
        .where(eq(users.id, agentId));
      
      return transaction;
    } catch (error) {
      console.error("Error creating remittance request:", error);
      throw error;
    }
  }

  async getRemittanceTransactionsByAgentId(agentId: number): Promise<RemittanceTransaction[]> {
    try {
      return db
        .select({
          id: remittanceTransactions.id,
          agentId: remittanceTransactions.agentId,
          amount: remittanceTransactions.amount,
          status: remittanceTransactions.status,
          recipientChannel: remittanceTransactions.recipientChannel,
          recipientName: remittanceTransactions.recipientName,
          recipientAccount: remittanceTransactions.recipientAccount,
          recipientAdditionalInfo: remittanceTransactions.recipientAdditionalInfo,
          feeId: remittanceTransactions.feeId,
          feeAmount: remittanceTransactions.feeAmount,
          totalAmount: remittanceTransactions.totalAmount,
          notes: remittanceTransactions.notes,
          statusReason: remittanceTransactions.statusReason,
          processedById: remittanceTransactions.processedById,
          processedAt: remittanceTransactions.processedAt,
          transactionNumber: remittanceTransactions.transactionNumber,
          createdAt: remittanceTransactions.createdAt,
          updatedAt: remittanceTransactions.updatedAt
        })
        .from(remittanceTransactions)
        .where(eq(remittanceTransactions.agentId, agentId))
        .orderBy(desc(remittanceTransactions.createdAt));
    } catch (error) {
      console.error("Error fetching remittance transactions for agent:", error);
      return [];
    }
  }

  async getPendingRemittanceTransactions(): Promise<RemittanceTransaction[]> {
    try {
      const transactions = await db
        .select({
          id: remittanceTransactions.id,
          agentId: remittanceTransactions.agentId,
          amount: remittanceTransactions.amount,
          status: remittanceTransactions.status,
          recipientChannel: remittanceTransactions.recipientChannel,
          recipientName: remittanceTransactions.recipientName,
          recipientAccount: remittanceTransactions.recipientAccount,
          recipientAdditionalInfo: remittanceTransactions.recipientAdditionalInfo,
          feeId: remittanceTransactions.feeId,
          feeAmount: remittanceTransactions.feeAmount,
          totalAmount: remittanceTransactions.totalAmount,
          notes: remittanceTransactions.notes,
          statusReason: remittanceTransactions.statusReason,
          processedById: remittanceTransactions.processedById,
          processedAt: remittanceTransactions.processedAt,
          transactionNumber: remittanceTransactions.transactionNumber,
          createdAt: remittanceTransactions.createdAt,
          updatedAt: remittanceTransactions.updatedAt,
          agentUsername: users.username,
          agentFullName: users.fullName,
          agentEmail: users.email,
          agentPhone: users.phone
        })
        .from(remittanceTransactions)
        .innerJoin(users, eq(remittanceTransactions.agentId, users.id))
        .where(eq(remittanceTransactions.status, "pending"))
        .orderBy(desc(remittanceTransactions.createdAt));
      
      return transactions;
    } catch (error) {
      console.error("Error fetching pending remittance transactions:", error);
      return [];
    }
  }

  async approveRemittanceTransaction(
    transactionId: number, 
    approve: boolean, 
    reason: string,
    adminId: number,
    transactionNumber?: string
  ): Promise<RemittanceTransaction> {
    const [transaction] = await db
      .select()
      .from(remittanceTransactions)
      .where(eq(remittanceTransactions.id, transactionId));
    
    if (!transaction) {
      throw new Error("Transaction not found");
    }
    
    // Can only approve/reject pending transactions
    if (transaction.status !== "pending") {
      throw new Error("Can only approve or reject pending transactions");
    }
    
    // Update the transaction
    const [updatedTransaction] = await db
      .update(remittanceTransactions)
      .set({
        status: approve ? "approved" : "rejected",
        statusReason: reason,
        processedById: adminId,
        processedAt: new Date(),
        transactionNumber: approve && transactionNumber ? transactionNumber : null,
      })
      .where(eq(remittanceTransactions.id, transactionId))
      .returning();
    
    // If rejected, return the amount to the agent's balance
    if (!approve) {
      await db
        .update(users)
        .set({
          balance: sql`balance + ${transaction.totalAmount}`
        })
        .where(eq(users.id, transaction.agentId));
    }
    
    // If approved, update achievements progress
    if (approve) {
      await this.trackAchievementProgress(
        transaction.agentId,
        'transaction_volume',
        'remittance_transaction',
        parseFloat(transaction.amount)
      );
    }
    
    return updatedTransaction;
  }
  
  // Achievement operations
  async getAchievements(): Promise<Achievement[]> {
    return db
      .select()
      .from(achievements)
      .where(eq(achievements.isActive, true))
      .orderBy(achievements.category, achievements.difficulty);
  }
  
  async getAchievementById(id: number): Promise<Achievement | undefined> {
    const [achievement] = await db
      .select()
      .from(achievements)
      .where(eq(achievements.id, id));
    
    return achievement;
  }
  
  async getUserAchievements(userId: number): Promise<UserAchievement[]> {
    return db
      .select({
        ...userAchievements,
        achievementTitle: achievements.title,
        achievementDescription: achievements.description,
        achievementCategory: achievements.category,
        achievementDifficulty: achievements.difficulty,
        achievementIcon: achievements.icon,
        achievementRequirement: achievements.requirement,
      })
      .from(userAchievements)
      .innerJoin(achievements, eq(userAchievements.achievementId, achievements.id))
      .where(eq(userAchievements.userId, userId))
      .orderBy(userAchievements.isCompleted, achievements.category);
  }
  
  async createAchievement(data: InsertAchievement): Promise<Achievement> {
    const [achievement] = await db
      .insert(achievements)
      .values(data)
      .returning();
    
    return achievement;
  }
  
  async updateAchievement(id: number, data: Partial<Achievement>): Promise<Achievement | undefined> {
    const [updatedAchievement] = await db
      .update(achievements)
      .set(data)
      .where(eq(achievements.id, id))
      .returning();
    
    return updatedAchievement;
  }
  
  async deleteAchievement(id: number): Promise<boolean> {
    const result = await db
      .delete(achievements)
      .where(eq(achievements.id, id))
      .returning();
    
    return result.length > 0;
  }
  
  // User achievement tracking
  async getUserAchievementById(id: number): Promise<UserAchievement | undefined> {
    const [userAchievement] = await db
      .select()
      .from(userAchievements)
      .where(eq(userAchievements.id, id));
    
    return userAchievement;
  }
  
  async createUserAchievement(data: InsertUserAchievement): Promise<UserAchievement> {
    const [userAchievement] = await db
      .insert(userAchievements)
      .values(data)
      .returning();
    
    return userAchievement;
  }
  
  async updateUserAchievement(id: number, data: Partial<UserAchievement>): Promise<UserAchievement | undefined> {
    const [updatedUserAchievement] = await db
      .update(userAchievements)
      .set(data)
      .where(eq(userAchievements.id, id))
      .returning();
    
    return updatedUserAchievement;
  }
  
  // Achievement progress tracking
  async trackAchievementProgress(
    userId: number, 
    category: string, 
    action: string, 
    value: number = 1
  ): Promise<UserAchievement[]> {
    // Get all achievements of the specified category
    const relevantAchievements = await db
      .select()
      .from(achievements)
      .where(
        and(
          eq(achievements.category, category),
          eq(achievements.isActive, true)
        )
      );
    
    if (relevantAchievements.length === 0) {
      return [];
    }
    
    const updatedAchievements: UserAchievement[] = [];
    
    // Process each achievement
    for (const achievement of relevantAchievements) {
      // Find existing user achievement progress or create one
      let [userAchievement] = await db
        .select()
        .from(userAchievements)
        .where(
          and(
            eq(userAchievements.userId, userId),
            eq(userAchievements.achievementId, achievement.id)
          )
        );
      
      if (!userAchievement) {
        // Create new progress record
        [userAchievement] = await db
          .insert(userAchievements)
          .values({
            userId,
            achievementId: achievement.id,
            progress: '0',
            isCompleted: false,
          })
          .returning();
      }
      
      // Skip if already completed
      if (userAchievement.isCompleted) {
        continue;
      }
      
      // Update progress based on the action and requirement
      let requirement: any = achievement.requirement;
      let newProgress = parseFloat(userAchievement.progress);
      
      switch (action) {
        case 'transaction_count':
        case 'remittance_transaction':
          // For transaction count-based achievements
          if (requirement.transaction_count) {
            newProgress = newProgress + 1;
          }
          // For transaction volume-based achievements
          else if (requirement.transaction_volume) {
            newProgress = newProgress + value;
          }
          break;
          
        case 'player_add':
          // For player count-based achievements
          if (requirement.player_count || requirement.active_player_count) {
            newProgress = newProgress + 1;
          }
          break;
          
        case 'login':
          // For consecutive login achievements
          if (requirement.consecutive_days) {
            // Check if last login was yesterday or this is first login
            const lastUpdate = userAchievement.updatedAt;
            const today = new Date();
            const yesterday = new Date(today);
            yesterday.setDate(yesterday.getDate() - 1);
            
            // Reset progress if not consecutive
            if (!lastUpdate || 
                lastUpdate.toDateString() !== yesterday.toDateString()) {
              newProgress = 1; // Reset to 1 (today's login)
            } else {
              newProgress = newProgress + 1;
            }
          }
          break;
          
        default:
          // Generic increment for other actions
          newProgress = newProgress + value;
      }
      
      // Check if achievement is completed
      let isCompleted = false;
      let pointsAwarded = 0;
      
      if (requirement.transaction_count && newProgress >= requirement.transaction_count) {
        isCompleted = true;
        pointsAwarded = achievement.pointsAwarded;
      } 
      else if (requirement.transaction_volume && newProgress >= requirement.transaction_volume) {
        isCompleted = true;
        pointsAwarded = achievement.pointsAwarded;
      }
      else if (requirement.player_count && newProgress >= requirement.player_count) {
        isCompleted = true;
        pointsAwarded = achievement.pointsAwarded;
      }
      else if (requirement.active_player_count && newProgress >= requirement.active_player_count) {
        isCompleted = true;
        pointsAwarded = achievement.pointsAwarded;
      }
      else if (requirement.consecutive_days && newProgress >= requirement.consecutive_days) {
        isCompleted = true;
        pointsAwarded = achievement.pointsAwarded;
      }
      
      // Update user achievement
      const [updatedAchievement] = await db
        .update(userAchievements)
        .set({
          progress: newProgress.toString(),
          isCompleted,
          completedAt: isCompleted ? new Date() : null,
          pointsAwarded: isCompleted ? achievement.pointsAwarded : 0,
        })
        .where(eq(userAchievements.id, userAchievement.id))
        .returning();
      
      updatedAchievements.push(updatedAchievement);
    }
    
    return updatedAchievements;
  }
  
  async getUserAchievementSummary(userId: number): Promise<{
    total: number;
    completed: number;
    inProgress: number;
    totalPoints: number;
  }> {
    // Get all achievements for the user
    const userAchievements = await this.getUserAchievements(userId);
    
    // Count totals
    const completed = userAchievements.filter(ua => ua.isCompleted).length;
    const totalPoints = userAchievements
      .filter(ua => ua.isCompleted)
      .reduce((sum, ua) => sum + ua.pointsAwarded, 0);
    
    return {
      total: userAchievements.length,
      completed,
      inProgress: userAchievements.length - completed,
      totalPoints,
    };
  }
}